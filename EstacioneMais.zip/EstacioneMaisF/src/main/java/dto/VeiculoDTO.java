package dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO (Data Transfer Object) que representa os dados completos de um veículo
 * e seu registro de estacionamento.
 * <p>
 * É usado para transferir informações de forma estruturada entre as camadas da
 * aplicação, como da camada de Serviço para a de Controle, que o envia como
* resposta da API. A utilização de 'record' no Java moderno torna a criação de
 * DTOs mais concisa e garante que os dados sejam imutáveis (não podem ser
 * alterados após a criação).
 *
 * @param nomeCliente     Nome do cliente associado ao veículo.
 * @param telefoneCliente Telefone de contato do cliente.
 * @param placa           Placa do veículo (identificador principal).
 * @param modelo          Modelo do veículo.
 * @param cor             Cor do veículo.
 * @param ano             Ano de fabricação do veículo.
 * @param horarioEntrada  Data e hora em que o veículo entrou no estacionamento.
 * @param horarioSaida    Data e hora em que o veículo saiu (pode ser nulo).
 * @param valorTotal      Valor total calculado pelo período de estacionamento.
 */
public record VeiculoDTO(
        String nomeCliente,
        String telefoneCliente,
        String placa,
        String modelo,
        String cor,
        Integer ano,
        LocalDateTime horarioEntrada,
        LocalDateTime horarioSaida,
        BigDecimal valorTotal
) {}