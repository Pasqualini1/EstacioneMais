package dto;

/**
 * DTO para transportar a configuração do total de vagas.
 *
 * @param totalVagas O número total de vagas disponíveis.
 */
public record VagasDispDTO(
        int totalVagas
) {}