package dto;

/**
 * DTO (Data Transfer Object) para transportar a configuração do total de vagas.
 * <p>
 * Representa de forma imutável o número total de vagas que o
 * estacionamento possui.
 *
 * @param totalVagas O número total de vagas disponíveis.
 */
public record VagasDispDTO(
        int totalVagas
) {}