package dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO (versão front-end) para representar o status de um único veículo
 * que está atualmente no pátio.
 */
public record VeiculoStatusDTO(
        String placa,
        String nomeCliente,
        String telefoneCliente,
        String modelo,
        String cor,
        LocalDateTime horarioEntrada,
        String tempoEstacionado,
        BigDecimal valorAtual
) {
    // Construtor explícito para o Jackson (ObjectMapper) desserializar
    @JsonCreator
    public VeiculoStatusDTO(
            @JsonProperty("placa") String placa,
            @JsonProperty("nomeCliente") String nomeCliente,
            @JsonProperty("telefoneCliente") String telefoneCliente,
            @JsonProperty("modelo") String modelo,
            @JsonProperty("cor") String cor,
            @JsonProperty("horarioEntrada") LocalDateTime horarioEntrada,
            @JsonProperty("tempoEstacionado") String tempoEstacionado,
            @JsonProperty("valorAtual") BigDecimal valorAtual) {
        
        this.placa = placa;
        this.nomeCliente = nomeCliente;
        this.telefoneCliente = telefoneCliente;
        this.modelo = modelo;
        this.cor = cor;
        this.horarioEntrada = horarioEntrada;
        this.tempoEstacionado = tempoEstacionado;
        this.valorAtual = valorAtual;
    }
}