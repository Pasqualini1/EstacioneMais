package dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO (Data Transfer Object) (versão front-end) para representar o status
 * de um único veículo que está atualmente no pátio.
 * <p>
 * Usado para exibir informações resumidas de um veículo ativo, incluindo
 * o tempo decorrido e o valor atual.
 *
 * @param placa             Placa do veículo.
 * @param nomeCliente       Nome do cliente associado.
 * @param telefoneCliente   Telefone do cliente.
 * @param modelo            Modelo do veículo.
 * @param cor               Cor do veículo.
 * @param horarioEntrada    Data e hora exata da entrada.
 * @param tempoEstacionado  Tempo formatado da estadia (ex: "2h 30m").
 * @param valorAtual        Valor calculado da estadia até o momento atual.
 */
public record VeiculoStatusDTO(
        String placa,
        String nomeCliente,
        String telefoneCliente,
        String modelo,
        String cor,
        LocalDateTime horarioEntrada,
        String tempoEstacionado,
        BigDecimal valorAtual
) {

    /**
     * Construtor explícito para desserialização JSON (via Jackson).
     * As anotações @JsonCreator e @JsonProperty garantem que o
     * ObjectMapper (ou similar) possa instanciar este 'record'
     * corretamente a partir de um JSON vindo da API.
     *
     * @param placa             Valor injetado do JSON (campo "placa").
     * @param nomeCliente       Valor injetado do JSON (campo "nomeCliente").
     * @param telefoneCliente   Valor injetado do JSON (campo "telefoneCliente").
     * @param modelo            Valor injetado do JSON (campo "modelo").
     * @param cor               Valor injetado do JSON (campo "cor").
     * @param horarioEntrada    Valor injetado do JSON (campo "horarioEntrada").
     * @param tempoEstacionado  Valor injetado do JSON (campo "tempoEstacionado").
     * @param valorAtual        Valor injetado do JSON (campo "valorAtual").
     */
    @JsonCreator
    public VeiculoStatusDTO(
            @JsonProperty("placa") String placa,
            @JsonProperty("nomeCliente") String nomeCliente,
            @JsonProperty("telefoneCliente") String telefoneCliente,
            @JsonProperty("modelo") String modelo,
            @JsonProperty("cor") String cor,
            @JsonProperty("horarioEntrada") LocalDateTime horarioEntrada,
            @JsonProperty("tempoEstacionado") String tempoEstacionado,
            @JsonProperty("valorAtual") BigDecimal valorAtual) {

        this.placa = placa;
        this.nomeCliente = nomeCliente;
        this.telefoneCliente = telefoneCliente;
        this.modelo = modelo;
        this.cor = cor;
        this.horarioEntrada = horarioEntrada;
        this.tempoEstacionado = tempoEstacionado;
        this.valorAtual = valorAtual;
    }
}