package dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * DTO (versão front-end) principal para a tela de "Status do Pátio".
 */
public record StatusPatioDTO(
        int totalVagas,
        int vagasOcupadas,
        int vagasDisponiveis,
        List<VeiculoStatusDTO> veiculosNoPatio
) {
    // Construtor explícito para o Jackson (ObjectMapper) desserializar
    @JsonCreator
    public StatusPatioDTO(
            @JsonProperty("totalVagas") int totalVagas,
            @JsonProperty("vagasOcupadas") int vagasOcupadas,
            @JsonProperty("vagasDisponiveis") int vagasDisponiveis,
            @JsonProperty("veiculosNoPatio") List<VeiculoStatusDTO> veiculosNoPatio) {
                
        this.totalVagas = totalVagas;
        this.vagasOcupadas = vagasOcupadas;
        this.vagasDisponiveis = vagasDisponiveis;
        this.veiculosNoPatio = veiculosNoPatio;
    }
}