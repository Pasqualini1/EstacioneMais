package dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * DTO (Data Transfer Object) (versão front-end) para a tela de "Status do Pátio".
 * <p>
 * Agrega os contadores de vagas (total, ocupadas, disponíveis) e a lista
 * dos veículos que estão atualmente no pátio.
 *
 * @param totalVagas       O número total de vagas configurado no sistema.
 * @param vagasOcupadas    O número de vagas atualmente ocupadas.
 * @param vagasDisponiveis O número de vagas livres (Total - Ocupadas).
 * @param veiculosNoPatio  A lista de veículos que estão no pátio (ativos).
 */
public record StatusPatioDTO(
        int totalVagas,
        int vagasOcupadas,
        int vagasDisponiveis,
        List<VeiculoStatusDTO> veiculosNoPatio
) {

    /**
     * Construtor explícito para desserialização JSON (via Jackson).
     * <p>
     * As anotações @JsonCreator e @JsonProperty garantem que o
     * ObjectMapper (ou similar) possa instanciar este 'record'
     * corretamente a partir de um JSON vindo da API.
     *
     * @param totalVagas       Valor injetado do JSON (campo "totalVagas").
     * @param vagasOcupadas    Valor injetado do JSON (campo "vagasOcupadas").
     * @param vagasDisponiveis Valor injetado do JSON (campo "vagasDisponiveis").
     * @param veiculosNoPatio  Valor injetado do JSON (campo "veiculosNoPatio").
     */
    @JsonCreator
    public StatusPatioDTO(
            @JsonProperty("totalVagas") int totalVagas,
            @JsonProperty("vagasOcupadas") int vagasOcupadas,
            @JsonProperty("vagasDisponiveis") int vagasDisponiveis,
            @JsonProperty("veiculosNoPatio") List<VeiculoStatusDTO> veiculosNoPatio) {

        this.totalVagas = totalVagas;
        this.vagasOcupadas = vagasOcupadas;
        this.vagasDisponiveis = vagasDisponiveis;
        this.veiculosNoPatio = veiculosNoPatio;
    }
}