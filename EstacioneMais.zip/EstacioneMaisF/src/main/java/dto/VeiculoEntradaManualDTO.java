package dto;

/**
 * DTO (Data Transfer Object) para registrar a entrada manual de um veículo.
 *
 * Este record encapsula os dados essenciais fornecidos pelo usuário no formulário
 * de registro manual, como a placa e as informações do cliente, para serem
 * enviados à API.
 *
 * @param placa           A placa do veículo a ser registrada.
 * @param nomeCliente     O nome do cliente/motorista.
 * @param telefoneCliente O telefone de contato do cliente.
 */
public record VeiculoEntradaManualDTO(String placa, 
        String nomeCliente, String telefoneCliente) {}