package dto;

import java.math.BigDecimal;

/**
 * DTO (Data Transfer Object) para transportar os dados de configuração de preços.
 * Esta é uma classe 'record' que representa de forma imutável a regra de
 * precificação do estacionamento.
 *
 * @param precoValor   O valor a ser cobrado (Ex: R$ 10,00) pela fração de tempo.
 * @param precoMinutos A quantidade de minutos correspondente a essa fração 
 * (Ex: 60 para 1 hora).
 */
public record PrecoDTO(
        BigDecimal precoValor,
        int precoMinutos
) {}