package service;

/**
 * Exceção customizada para encapsular erros ocorridos durante a comunicação com as APIs.
 *
 * Esta é uma exceção "checada" (checked exception) que força o tratamento de erros
 * em toda a camada de serviço. Sua principal função é traduzir exceções de baixo nível
 * (como IOException, ConnectException) em uma mensagem de erro simples e amigável,
 * que pode ser diretamente exibida na interface do usuário (UI).
 */
public class ApiException extends Exception {

    /**
     * Constrói a exceção com uma mensagem de erro para o usuário.
     *
     * @param userFriendlyMessage A mensagem clara e descritiva do erro.
     */
    public ApiException(String userFriendlyMessage) {
        super(userFriendlyMessage);
    }

    /**
     * Constrói a exceção com uma mensagem de erro e a causa original.
     * Encadear a exceção original (cause) é uma boa prática para facilitar a
     * depuração (debugging) e o registro de logs detalhados.
     *
     * @param userFriendlyMessage A mensagem clara e descritiva do erro.
     * @param cause A exceção original que foi capturada.
     */
    public ApiException(String userFriendlyMessage, Throwable cause) {
        super(userFriendlyMessage, cause);
    }
}