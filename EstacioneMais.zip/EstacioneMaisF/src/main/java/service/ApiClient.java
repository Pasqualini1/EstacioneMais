package service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import dto.PrecoDTO;
import dto.VagasDispDTO;
import dto.VeiculoDTO;
import dto.VeiculoEntradaManualDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.UUID;

public class ApiClient {

    private static final Logger logger = LoggerFactory.getLogger(ApiClient.class);
    private static final String BASE_URL_ESTACIONAMENTO = "http://localhost:8080/estacionamento";
    private static final String BASE_URL_PRECO = "http://localhost:8080/preco";
    private static final String BASE_URL_VAGAS = "http://localhost:8080/vagas";

    private static final HttpClient client = HttpClient.newBuilder()
            .version(HttpClient.Version.HTTP_1_1)
            .connectTimeout(Duration.ofSeconds(20))
            .build();
    private static final ObjectMapper mapper = new ObjectMapper()
            .registerModule(new JavaTimeModule());

    private static final Properties properties = new Properties();
    private static final Path CONFIG_PATH = Paths.get("config.properties");

    static {
        try {
            if (!Files.exists(CONFIG_PATH)) {
                Files.createFile(CONFIG_PATH);
            }
            properties.load(Files.newInputStream(CONFIG_PATH));
        } catch (IOException e) {
            logger.error("NÃO FOI POSSÍVEL LER O ARQUIVO config.properties", e);
        }
    }

    // --- MÉTODOS DE CONFIGURAÇÃO (TOKEN DO PLATE RECOGNIZER) ---

    public static String getToken() {
        return properties.getProperty("platerecognizer.token", "");
    }

    public static void saveToken(String token) throws IOException {
        properties.setProperty("platerecognizer.token", token);
        properties.store(Files.newOutputStream(CONFIG_PATH), "Configuracoes do Estacione+");
    }

    // --- MÉTODOS DE API (ESTACIONAMENTO) ---

    public static void registrarEntradaManual(String placa, String nomeCliente, String telefoneCliente) throws ApiException {
        try {
            VeiculoEntradaManualDTO entradaManualDTO = new VeiculoEntradaManualDTO(placa, nomeCliente, telefoneCliente);
            String requestBody = mapper.writeValueAsString(entradaManualDTO);
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL_ESTACIONAMENTO + "/entrada"))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                    .build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
        } catch (ConnectException e) {
            logger.error("Erro de conexão com o backend ao registrar entrada", e);
            throw new ApiException("Não foi possível conectar ao servidor. O sistema backend está offline?", e);
        } catch (IOException | InterruptedException e) {
            logger.error("Erro inesperado ao registrar entrada", e);
            throw new ApiException("Ocorreu um erro de comunicação com o servidor.", e);
        }
    }

    public static VeiculoDTO getPreviewSaida(String placa) throws ApiException {
        try {
            String placaCodificada = URLEncoder.encode(placa, StandardCharsets.UTF_8);
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL_ESTACIONAMENTO + "/saida/preview/" + placaCodificada))
                    .GET()
                    .build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
            return mapper.readValue(response.body(), VeiculoDTO.class);
        } catch (ConnectException e) {
            throw new ApiException("Não foi possível conectar ao servidor. O sistema backend está offline?", e);
        } catch (IOException | InterruptedException e) {
            throw new ApiException("Ocorreu um erro de comunicação com o servidor.", e);
        }
    }

    public static void registrarSaida(String placa) throws ApiException {
        try {
            String placaCodificada = URLEncoder.encode(placa, StandardCharsets.UTF_8);
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL_ESTACIONAMENTO + "/saida/" + placaCodificada))
                    .POST(HttpRequest.BodyPublishers.noBody())
                    .build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
        } catch (ConnectException e) {
            throw new ApiException("Não foi possível conectar ao servidor. O sistema backend está offline?", e);
        } catch (IOException | InterruptedException e) {
            throw new ApiException("Ocorreu um erro de comunicação com o servidor.", e);
        }
    }

    public static List<VeiculoDTO> listarVeiculosAtivos() throws ApiException {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL_ESTACIONAMENTO + "/ativos"))
                    .header("Accept", "application/json")
                    .GET().build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
            return mapper.readValue(response.body(), new TypeReference<>() {});
        } catch (ConnectException e) {
            logger.error("Erro de conexão com o backend ao listar veículos ativos", e);
            throw new ApiException("Não foi possível conectar ao servidor. O sistema backend está offline?", e);
        } catch (IOException | InterruptedException e) {
            logger.error("Erro inesperado ao listar veículos ativos", e);
            throw new ApiException("Ocorreu um erro ao listar os veículos.", e);
        }
    }

    public static List<VeiculoDTO> gerarRelatorioPorPlaca(String placa) throws ApiException {
        try {
            String placaCodificada = URLEncoder.encode(placa, StandardCharsets.UTF_8);
            String url = placa.isBlank() ? BASE_URL_ESTACIONAMENTO + "/historico" : BASE_URL_ESTACIONAMENTO + "/historico/" + placaCodificada;
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Accept", "application/json")
                    .GET().build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
            if (response.body() == null || response.body().trim().isEmpty() || response.body().trim().equals("[]")) {
                return Collections.emptyList();
            }
            return mapper.readValue(response.body(), new TypeReference<>() {});
        } catch (ConnectException e) {
            logger.error("Erro de conexão com o backend ao buscar histórico", e);
            throw new ApiException("Não foi possível conectar ao servidor. O sistema backend está offline?", e);
        } catch (IOException | InterruptedException e) {
            logger.error("Erro inesperado ao gerar relatório por placa", e);
            throw new ApiException("Ocorreu um erro ao gerar o relatório.", e);
        }
    }

    public static List<VeiculoDTO> listarHistoricoCompleto() throws ApiException {
        return gerarRelatorioPorPlaca("");
    }

    public static List<VeiculoDTO> buscarDadosRelatorio(LocalDateTime dataInicio, LocalDateTime dataFim) throws ApiException {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
            String url = BASE_URL_ESTACIONAMENTO + "/relatorio?dataInicio=" + dataInicio.format(formatter) + "&dataFim=" + dataFim.format(formatter);
            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).GET().build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
            return mapper.readValue(response.body(), new TypeReference<>() {});
        } catch (ConnectException e) {
            logger.error("Erro de conexão com o backend ao buscar dados do relatório", e);
            throw new ApiException("Não foi possível conectar ao servidor. O sistema backend está offline?", e);
        } catch (IOException | InterruptedException e) {
            logger.error("Erro inesperado ao buscar dados do relatório", e);
            throw new ApiException("Ocorreu um erro ao buscar dados do relatório.", e);
        }
    }

    // --- MÉTODOS DE API (PREÇO) ATUALIZADOS ---

    public static PrecoDTO getPreco() throws ApiException {
        try {
            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(BASE_URL_PRECO)).GET().build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
            return mapper.readValue(response.body(), PrecoDTO.class);
        } catch (IOException | InterruptedException e) {
            throw new ApiException("Erro ao buscar configurações de preço.", e);
        }
    }

    public static void savePreco(PrecoDTO dto) throws ApiException {
        try {
            String requestBody = mapper.writeValueAsString(dto);
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL_PRECO))
                    .header("Content-Type", "application/json")
                    .PUT(HttpRequest.BodyPublishers.ofString(requestBody))
                    .build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
        } catch (IOException | InterruptedException e) {
            throw new ApiException("Erro ao salvar configurações de preço.", e);
        }
    }

    // --- NOVOS MÉTODOS DE API (VAGAS) ---

    public static VagasDispDTO getVagas() throws ApiException {
        try {
            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(BASE_URL_VAGAS)).GET().build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
            return mapper.readValue(response.body(), VagasDispDTO.class);
        } catch (IOException | InterruptedException e) {
            throw new ApiException("Erro ao buscar a configuração de vagas.", e);
        }
    }

    public static void saveVagas(VagasDispDTO dto) throws ApiException {
        try {
            String requestBody = mapper.writeValueAsString(dto);
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL_VAGAS))
                    .header("Content-Type", "application/json")
                    .PUT(HttpRequest.BodyPublishers.ofString(requestBody))
                    .build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
        } catch (IOException | InterruptedException e) {
            throw new ApiException("Erro ao salvar a configuração de vagas.", e);
        }
    }

    // --- MÉTODO DE API (PLATE RECOGNIZER) ---

    public static String reconhecerPlacaComPlateRecognizer(BufferedImage imagem) throws ApiException {
        String token = getToken();
        if (token == null || token.isBlank()) {
            throw new ApiException("O serviço de reconhecimento de placas não está ativado.\n" +
                                   "Por favor, insira sua 'Chave de Serviço' na tela de Configurações.");
        }

        try {
            final String boundary = "Boundary-" + UUID.randomUUID().toString();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(imagem, "jpeg", baos);
            byte[] imageData = baos.toByteArray();

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://api.platerecognizer.com/v1/plate-reader/"))
                    .header("Authorization", "Token " + token)
                    .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                    .POST(ofMimeMultipartData(imageData, boundary))
                    .timeout(Duration.ofSeconds(20))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 403) {
                throw new ApiException("A Chave de Serviço fornecida é inválida ou expirou.");
            }
            if (response.statusCode() != 201) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
            
            JsonNode root = mapper.readTree(response.body());
            JsonNode results = root.path("results");
            if (results.isArray() && results.size() > 0) {
                return results.get(0).path("plate").asText().toUpperCase();
            }
            return null;

        } catch (HttpTimeoutException e) {
            logger.error("Timeout ao chamar o serviço de placas", e);
            throw new ApiException("O serviço de reconhecimento de placas demorou muito para responder.", e);
        } catch (ConnectException e) {
            logger.error("Erro de conexão com o serviço de placas", e);
            throw new ApiException("Não foi possível conectar ao serviço de placas. Verifique sua internet.", e);
        } catch (IOException | InterruptedException e) {
            logger.error("Erro inesperado ao processar a imagem", e);
            throw new ApiException("Ocorreu um erro inesperado ao processar a imagem.", e);
        }
    }

    // --- MÉTODOS AUXILIARES ---

    private static HttpRequest.BodyPublisher ofMimeMultipartData(byte[] imageData, String boundary) {
        var byteArrays = new ArrayList<byte[]>();
        String separator = "--" + boundary +
                "\r\nContent-Disposition: form-data; name=\"upload\"; "
                + "filename=\"plate.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n";
        byteArrays.add(separator.getBytes(StandardCharsets.UTF_8));
        byteArrays.add(imageData);
        byteArrays.add("\r\n".getBytes(StandardCharsets.UTF_8));
        byteArrays.add(("--" + boundary + "--").getBytes(StandardCharsets.UTF_8));
        return HttpRequest.BodyPublishers.ofByteArrays(byteArrays);
    }

    private static String extrairMensagemDeErro(HttpResponse<String> response) {
        String responseBody = response.body();

        if (responseBody == null || responseBody.isBlank()) {
            return "Ocorreu um erro desconhecido no servidor (Código: " + response.statusCode() + ").";
        }

        if (responseBody.strip().startsWith("{") &&
                (responseBody.contains("\"message\"") || responseBody.contains("\"error\""))) {
            try {
                JsonNode root = mapper.readTree(responseBody);
                if (root.has("message")) {
                     return root.path("message").asText("Não foi possível ler a mensagem de erro do servidor.");
                } else if (root.has("error")) {
                    return root.path("error").asText("Erro não especificado.");
                }
            } catch (IOException e) {
                logger.error("Erro ao parsear JSON de erro: {}", responseBody, e);
                return responseBody;
            }
        }
        return responseBody;
    }
}