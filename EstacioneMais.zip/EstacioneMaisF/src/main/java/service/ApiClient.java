package service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import dto.VeiculoDTO;
import dto.VeiculoEntradaManualDTO;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.UUID;

/**
 * Classe utilitária estática que centraliza toda a comunicação HTTP do front-end.
 * É responsável por:
 * 1. Fazer requisições para o back-end da aplicação (localhost:8080).
 * 2. Comunicar-se com a API externa do Plate Recognizer.
 * 3. Gerenciar o arquivo local 'config.properties' para armazenar a chave da API.
 * 4. Tratar erros de comunicação e converter respostas em exceções customizadas (ApiException).
 */
public class ApiClient {

    private static final Logger logger = LoggerFactory.getLogger(ApiClient.class);
    private static final String BASE_URL = "http://localhost:8080/estacionamento";
    private static final HttpClient client = HttpClient.newBuilder()
            .version(HttpClient.Version.HTTP_1_1)
            .connectTimeout(Duration.ofSeconds(20))
            .build();
    private static final ObjectMapper mapper = new ObjectMapper()
            .registerModule(new JavaTimeModule());

    private static final Properties properties = new Properties();
    private static final Path CONFIG_PATH = Paths.get("config.properties");

    // Bloco estático para carregar as configurações do arquivo .properties na inicialização.
    static {
        try {
            if (!Files.exists(CONFIG_PATH)) {
                Files.createFile(CONFIG_PATH);
            }
            properties.load(Files.newInputStream(CONFIG_PATH));
        } catch (IOException e) {
            logger.error("NÃO FOI POSSÍVEL LER O ARQUIVO config.properties", e);
        }
    }

    /**
     * Obtém o token da API do Plate Recognizer do arquivo de configuração.
     * @return O token salvo, ou uma string vazia se não houver.
     */
    public static String getToken() {
        return properties.getProperty("platerecognizer.token", "");
    }

    /**
     * Salva o token da API do Plate Recognizer no arquivo de configuração.
     * @param token O novo token a ser salvo.
     * @throws IOException Se houver um erro ao escrever no arquivo.
     */
    public static void saveToken(String token) throws IOException {
        properties.setProperty("platerecognizer.token", token);
        properties.store(Files.newOutputStream(CONFIG_PATH), 
                "Configuracoes do Estacione+");
    }

    /**
     * Registra a entrada de um veículo a partir dos dados da câmera.
     * Este método simplesmente delega a chamada para o método de registro manual.
     */
    public static void registrarEntradaCamera(String placa, String nomeCliente, 
            String telefoneCliente) throws ApiException {
        registrarEntradaManual(placa, nomeCliente, telefoneCliente);
    }
    
    /**
     * Envia uma requisição POST para o back-end para registrar a entrada manual de um veículo.
     */
    public static void registrarEntradaManual(String placa, String nomeCliente, 
            String telefoneCliente) throws ApiException {
        try {
            VeiculoEntradaManualDTO entradaManualDTO = 
                    new VeiculoEntradaManualDTO(placa, nomeCliente,
                            telefoneCliente);
            String requestBody = mapper.writeValueAsString(entradaManualDTO);
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL + "/entrada"))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                    .build();
            HttpResponse<String> response = client.send(request, HttpResponse.
                    BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
        } catch (ConnectException e) {
            logger.error("Erro de conexão com o backend ao registrar entrada", e);
            throw new ApiException("Não foi possível conectar ao servidor. "
                    + "O sistema backend está offline?", e);
        } catch (IOException | InterruptedException e) {
            logger.error("Erro inesperado ao registrar entrada", e);
            throw new ApiException("Ocorreu um erro de comunicação com "
                    + "o servidor.", e);
        }
    }

    /**
     * Envia uma requisição POST para o back-end para registrar a saída de um veículo.
     */
    public static void registrarSaida(String placa) throws ApiException {
        try {
            String placaCodificada = URLEncoder.encode(placa,
                    StandardCharsets.UTF_8);
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL + "/saida/" + placaCodificada))
                    .POST(HttpRequest.BodyPublishers.noBody())
                    .build();
            HttpResponse<String> response = client.send(request, 
                    HttpResponse.BodyHandlers.ofString());
            
            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
        } catch (ConnectException e) {
            logger.error("Erro de conexão com o backend ao registrar saída", e);
            throw new ApiException("Não foi possível conectar ao servidor. "
                    + "O sistema backend está offline?", e);
        } catch (IOException | InterruptedException e) {
            logger.error("Erro inesperado ao registrar saída", e);
            throw new ApiException("Ocorreu um erro de comunicação com o "
                    + "servidor.", e);
        }
    }
    
    /**
     * Envia uma requisição GET para o back-end para listar todos os veículos atualmente no pátio.
     * @return Uma lista de VeiculoDTO.
     */
    public static List<VeiculoDTO> listarVeiculosAtivos() throws ApiException {
        try {
            HttpRequest request = HttpRequest.newBuilder().uri(URI.create
        (BASE_URL + "/ativos")).header("Accept", "application/json").GET().build();
            HttpResponse<String> response = client.send(request, 
                    HttpResponse.BodyHandlers.ofString());
            
            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
            return mapper.readValue(response.body(), new TypeReference<>() {});
            
        } catch (ConnectException e) {
            logger.error("Erro de conexão com o backend ao listar "
                    + "veículos ativos", e);
            throw new ApiException("Não foi possível conectar ao servidor."
                    + " O sistema backend está offline?", e);
        } catch (IOException | InterruptedException e) {
            logger.error("Erro inesperado ao listar veículos ativos", e);
            throw new ApiException("Ocorreu um erro ao listar os veículos.", e);
        }
    }
    
    /**
     * Envia uma requisição GET para o back-end para buscar o histórico de um veículo por placa.
     * Se a placa for vazia, busca o histórico completo.
     */
    public static List<VeiculoDTO> gerarRelatorioPorPlaca(String placa) 
            throws ApiException {
        try {
            String placaCodificada = URLEncoder.encode(placa, 
                    StandardCharsets.UTF_8);
            String url = placa.isBlank() ? BASE_URL + "/historico" : 
                    BASE_URL + "/historico/" + placaCodificada;
            HttpRequest request = HttpRequest.newBuilder().
                    uri(URI.create(url)).header("Accept", "application/json").
                    GET().build();
            HttpResponse<String> response = client.send(request, HttpResponse.
                    BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
            if (response.body() == null || response.body().trim().isEmpty() || 
                    response.body().trim().equals("[]")) {
                return Collections.emptyList();
            }
            return mapper.readValue(response.body(), new TypeReference<>() {});
            
        } catch (ConnectException e) {
            logger.error("Erro de conexão com o backend ao buscar histórico", e);
            throw new ApiException("Não foi possível conectar ao servidor. "
                    + "O sistema backend está offline?", e);
        } catch (IOException | InterruptedException e) {
            logger.error("Erro inesperado ao gerar relatório por placa", e);
            throw new ApiException("Ocorreu um erro ao gerar o relatório.", e);
        }
    }
    
    /**
     * Método de conveniência que chama o `gerarRelatorioPorPlaca` com uma placa vazia.
     * @return O histórico completo de todos os veículos.
     */
    public static List<VeiculoDTO> listarHistoricoCompleto() throws ApiException {
        return gerarRelatorioPorPlaca("");
    }

    /**
     * Envia uma requisição GET para o back-end para buscar dados de relatório por um período.
     */
    public static List<VeiculoDTO> buscarDadosRelatorio(
            LocalDateTime dataInicio, LocalDateTime dataFim) throws ApiException {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
            String url = BASE_URL + "/relatorio?dataInicio=" + dataInicio.format(formatter) + 
                    "&dataFim=" + dataFim.format(formatter);
            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).GET().build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            
            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
            return mapper.readValue(response.body(), new TypeReference<>() {});
            
        } catch (ConnectException e) {
            logger.error("Erro de conexão com o backend ao buscar dados do relatório", e);
            throw new ApiException("Não foi possível conectar ao servidor. O sistema backend está offline?", e);
        } catch (IOException | InterruptedException e) {
            logger.error("Erro inesperado ao buscar dados do relatório", e);
            throw new ApiException("Ocorreu um erro ao buscar dados do relatório.", e);
        }
    }

    /**
     * Envia uma imagem para a API externa do Plate Recognizer para obter a placa.
     * @param imagem A imagem capturada da câmera.
     * @return A string da placa reconhecida, ou null se não for reconhecida.
     */
    public static String reconhecerPlacaComPlateRecognizer(BufferedImage imagem) throws ApiException {
        String token = getToken();
        if (token == null || token.isBlank()) {
            throw new ApiException("O serviço de reconhecimento de placas não está ativado.\n" +
                                   "Por favor, insira sua 'Chave de Serviço' na tela de Configurações.");
        }
        
        try {
            final String boundary = "Boundary-" + UUID.randomUUID().toString();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(imagem, "jpeg", baos);
            byte[] imageData = baos.toByteArray();

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://api.platerecognizer.com/v1/plate-reader/"))
                    .header("Authorization", "Token " + token)
                    .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                    .POST(ofMimeMultipartData(imageData, boundary))
                    .timeout(Duration.ofSeconds(20))
                    .build();
            
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 403) {
                throw new ApiException("A Chave de Serviço fornecida é inválida ou expirou.");
            }
            if (response.statusCode() != 201) {
                throw new ApiException(extrairMensagemDeErro(response));
            }

            // Faz o parse do JSON de resposta para extrair a placa.
            JsonNode root = mapper.readTree(response.body());
            JsonNode results = root.path("results");
            if (results.isArray() && results.size() > 0) {
                return results.get(0).path("plate").asText().toUpperCase();
            }
            return null;

        } catch (HttpTimeoutException e) {
            logger.error("Timeout ao chamar o serviço de placas", e);
            throw new ApiException("O serviço de reconhecimento de placas demorou muito para responder.", e);
        } catch (ConnectException e) {
            logger.error("Erro de conexão com o serviço de placas", e);
            throw new ApiException("Não foi possível conectar ao serviço de placas. Verifique sua internet.", e);
        } catch (IOException | InterruptedException e) {
            logger.error("Erro inesperado ao processar a imagem", e);
            throw new ApiException("Ocorreu um erro inesperado ao processar a imagem.", e);
        }
    }

    /**
     * Método auxiliar para construir o corpo de uma requisição multipart/form-data.
     * Necessário para o envio de imagens para a API do Plate Recognizer.
     */
    private static HttpRequest.BodyPublisher ofMimeMultipartData(byte[] imageData, String boundary) {
        var byteArrays = new ArrayList<byte[]>();
        String separator = "--" + boundary + 
                "\r\nContent-Disposition: form-data; name=\"upload\"; "
                + "filename=\"plate.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n";
        byteArrays.add(separator.getBytes(StandardCharsets.UTF_8));
        byteArrays.add(imageData);
        byteArrays.add("\r\n".getBytes(StandardCharsets.UTF_8));
        byteArrays.add(("--" + boundary + "--").getBytes(StandardCharsets.UTF_8));
        return HttpRequest.BodyPublishers.ofByteArrays(byteArrays);
    }
    
    /**
     * Método utilitário para extrair uma mensagem de erro amigável de uma resposta HTTP.
     * Ele tenta fazer o parse de um JSON com um campo "message" ou "error".
     * Se falhar, retorna o corpo da resposta como texto.
     */
    private static String extrairMensagemDeErro(HttpResponse<String> response) {
        String responseBody = response.body();
        
        if (responseBody == null || responseBody.isBlank()) {
            return "Ocorreu um erro desconhecido no servidor (Código: " + response.statusCode() + ").";
        }
        
        if (responseBody.strip().startsWith("{") && 
                (responseBody.contains("\"message\"") || responseBody.contains("\"error\""))) {
            try {
                JsonNode root = mapper.readTree(responseBody);
                if (root.has("message")) {
                     return root.path("message").asText("Não foi possível ler a mensagem de erro do servidor.");
                } else if (root.has("error")) {
                    return root.path("error").asText("Erro não especificado.");
                }
            } catch (IOException e) {
                logger.error("Erro ao parsear JSON de erro: {}", responseBody, e);
                return responseBody; 
            }
        }
        
        return responseBody;
    }
}