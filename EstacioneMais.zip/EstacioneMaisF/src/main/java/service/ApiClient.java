package service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import dto.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.UUID;

/**
 * Classe de cliente API central (estática) para a aplicação front-end.
 * <p>
 * Gerencia toda a comunicação HTTP (via Java 11+ HttpClient) com o
 * back-end (EstacioneMais API) e serviços externos (Plate Recognizer).
 * Inclui serialização/desserialização JSON (via Jackson) e
 * gerenciamento de chaves de API.
 */
public class ApiClient {

    private static final Logger logger = LoggerFactory.getLogger(ApiClient.class);

    // URLs base para os endpoints da API back-end
    private static final String BASE_URL_ESTACIONAMENTO = "http://localhost:8080/estacionamento";
    private static final String BASE_URL_PRECO = "http://localhost:8080/preco";
    private static final String BASE_URL_VAGAS = "http://localhost:8080/vagas";

    /**
     * Chave de API secreta (X-API-KEY) para autenticação no back-end.
     * Deve ser idêntica à definida no 'api.secret.key' do back-end.
     */
    private static final String API_KEY = "estacione+ADS6p";

    /**
     * Cliente HTTP estático, configurado para reuso, com timeout de conexão.
     */
    private static final HttpClient client = HttpClient.newBuilder()
            .version(HttpClient.Version.HTTP_1_1)
            .connectTimeout(Duration.ofSeconds(20))
            .build();

    /**
     * Serializador/Desserializador JSON (Jackson), com módulo para Java 8 Time.
     */
    private static final ObjectMapper mapper = new ObjectMapper()
            .registerModule(new JavaTimeModule());

    // Gerenciamento de configurações locais (para a chave do Plate Recognizer)
    private static final Properties properties = new Properties();
    private static final Path CONFIG_PATH = Paths.get("config.properties");

    /**
     * Bloco de inicialização estático.
     * Carrega (ou cria se não existir) o arquivo 'config.properties'
     * do disco para gerenciar o token do serviço externo.
     */
    static {
        try {
            if (!Files.exists(CONFIG_PATH)) {
                Files.createFile(CONFIG_PATH);
            }
            properties.load(Files.newInputStream(CONFIG_PATH));
        } catch (IOException e) {
            logger.error("NÃO FOI POSSÍVEL LER O ARQUIVO config.properties", e);
        }
    }

    // --- MÉTODOS DE CONFIGURAÇÃO (TOKEN DO PLATE RECOGNIZER) ---

    /**
     * Obtém o token da API Plate Recognizer salvo localmente.
     *
     * @return O token como String, ou uma string vazia se não estiver definido.
     */
    public static String getToken() {
        return properties.getProperty("platerecognizer.token", "");
    }

    /**
     * Salva o token da API Plate Recognizer no arquivo 'config.properties'.
     *
     * @param token O token a ser salvo.
     * @throws IOException Se ocorrer um erro ao escrever no arquivo.
     */
    public static void saveToken(String token) throws IOException {
        properties.setProperty("platerecognizer.token", token);
        properties.store(Files.newOutputStream(CONFIG_PATH), "Configuracoes do Estacione+");
    }

    // --- MÉTODOS DE API (ESTACIONAMENTO) ---

    /**
     * Chama o endpoint POST /estacionamento/entrada para registrar uma entrada.
     *
     * @param placa           A placa do veículo.
     * @param nomeCliente     O nome do cliente (pode ser nulo).
     * @param telefoneCliente O telefone do cliente (pode ser nulo).
     * @throws ApiException Se a API retornar um erro (ex: 4xx, 5xx) ou
     * se houver falha de conexão.
     */
    public static void registrarEntradaManual(String placa, String nomeCliente, String telefoneCliente) throws ApiException {
        try {
            VeiculoEntradaManualDTO entradaManualDTO = new VeiculoEntradaManualDTO(placa, nomeCliente, telefoneCliente);
            String requestBody = mapper.writeValueAsString(entradaManualDTO);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL_ESTACIONAMENTO + "/entrada"))
                    .header("Content-Type", "application/json")
                    .header("X-API-KEY", API_KEY) // Adiciona o header de autenticação
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                    .build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
        } catch (ConnectException e) {
            logger.error("Erro de conexão com o backend ao registrar entrada", e);
            throw new ApiException("Não foi possível conectar ao servidor. O sistema backend está offline?", e);
        } catch (IOException | InterruptedException e) {
            logger.error("Erro inesperado ao registrar entrada", e);
            throw new ApiException("Ocorreu um erro de comunicação com o servidor.", e);
        }
    }

    /**
     * Chama o endpoint GET /estacionamento/saida/preview/{placa} para
     * pré-visualizar o custo da saída.
     *
     * @param placa A placa do veículo a ser consultada.
     * @return Um VeiculoDTO com os dados da estadia e o valor calculado.
     * @throws ApiException Se a API retornar um erro ou falhar a conexão.
     */
    public static VeiculoDTO getPreviewSaida(String placa) throws ApiException {
        try {
            String placaCodificada = URLEncoder.encode(placa, StandardCharsets.UTF_8);
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL_ESTACIONAMENTO + "/saida/preview/" + placaCodificada))
                    .header("X-API-KEY", API_KEY)
                    .GET()
                    .build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
            return mapper.readValue(response.body(), VeiculoDTO.class);
        } catch (ConnectException e) {
            throw new ApiException("Não foi possível conectar ao servidor. O sistema backend está offline?", e);
        } catch (IOException | InterruptedException e) {
            throw new ApiException("Ocorreu um erro de comunicação com o servidor.", e);
        }
    }

    /**
     * Chama o endpoint POST /estacionamento/saida/{placa} para registrar
     * a saída efetiva do veículo.
     *
     * @param placa A placa do veículo que está saindo.
     * @throws ApiException Se a API retornar um erro ou falhar a conexão.
     */
    public static void registrarSaida(String placa) throws ApiException {
        try {
            String placaCodificada = URLEncoder.encode(placa, StandardCharsets.UTF_8);
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL_ESTACIONAMENTO + "/saida/" + placaCodificada))
                    .header("X-API-KEY", API_KEY)
                    .POST(HttpRequest.BodyPublishers.noBody())
                    .build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
        } catch (ConnectException e) {
            throw new ApiException("Não foi possível conectar ao servidor. O sistema backend está offline?", e);
        } catch (IOException | InterruptedException e) {
            throw new ApiException("Ocorreu um erro de comunicação com o servidor.", e);
        }
    }

    /**
     * Chama o endpoint GET /estacionamento/ativos para buscar a lista de
     * veículos atualmente no pátio.
     *
     * @return Uma lista (List) de VeiculoDTO.
     * @throws ApiException Se a API retornar um erro ou falhar a conexão.
     */
    public static List<VeiculoDTO> listarVeiculosAtivos() throws ApiException {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL_ESTACIONAMENTO + "/ativos"))
                    .header("Accept", "application/json")
                    .header("X-API-KEY", API_KEY)
                    .GET().build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
            return mapper.readValue(response.body(), new TypeReference<>() {
            });
        } catch (ConnectException e) {
            logger.error("Erro de conexão com o backend ao listar veículos ativos", e);
            throw new ApiException("Não foi possível conectar ao servidor. O sistema backend está offline?", e);
        } catch (IOException | InterruptedException e) {
            logger.error("Erro inesperado ao listar veículos ativos", e);
            throw new ApiException("Ocorreu um erro ao listar os veículos.", e);
        }
    }

    /**
     * Chama o endpoint GET /estacionamento/historico/{placa} ou /historico.
     * Se a placa for nula ou vazia, busca o histórico completo.
     *
     * @param placa A placa a ser consultada (ou "" para todos).
     * @return Uma lista (List) de VeiculoDTO com o histórico.
     * @throws ApiException Se a API retornar um erro ou falhar a conexão.
     */
    public static List<VeiculoDTO> gerarRelatorioPorPlaca(String placa) throws ApiException {
        try {
            String placaCodificada = URLEncoder.encode(placa, StandardCharsets.UTF_8);
            String url = placa.isBlank() ? BASE_URL_ESTACIONAMENTO + "/historico" : BASE_URL_ESTACIONAMENTO + "/historico/" + placaCodificada;

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Accept", "application/json")
                    .header("X-API-KEY", API_KEY)
                    .GET().build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
            if (response.body() == null || response.body().trim().isEmpty() || response.body().trim().equals("[]")) {
                return Collections.emptyList();
            }
            return mapper.readValue(response.body(), new TypeReference<>() {
            });
        } catch (ConnectException e) {
            logger.error("Erro de conexão com o backend ao buscar histórico", e);
            throw new ApiException("Não foi possível conectar ao servidor. O sistema backend está offline?", e);
        } catch (IOException | InterruptedException e) {
            logger.error("Erro inesperado ao gerar relatório por placa", e);
            throw new ApiException("Ocorreu um erro ao gerar o relatório.", e);
        }
    }

    /**
     * Método de conveniência para listar o histórico completo.
     *
     * @return Uma lista (List) de VeiculoDTO com o histórico completo.
     * @throws ApiException Se a API retornar um erro ou falhar a conexão.
     */
    public static List<VeiculoDTO> listarHistoricoCompleto() throws ApiException {
        return gerarRelatorioPorPlaca("");
    }

    /**
     * Chama o endpoint GET /estacionamento/relatorio para buscar registros
     * por período.
     *
     * @param dataInicio Data/hora inicial do filtro.
     * @param dataFim    Data/hora final do filtro.
     * @return Uma lista (List) de VeiculoDTO filtrada pelo período.
     * @throws ApiException Se a API retornar um erro ou falhar a conexão.
     */
    public static List<VeiculoDTO> buscarDadosRelatorio(LocalDateTime dataInicio, LocalDateTime dataFim) throws ApiException {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
            String url = BASE_URL_ESTACIONAMENTO + "/relatorio?dataInicio="
                    + dataInicio.format(formatter) + "&dataFim=" + dataFim.format(formatter);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("X-API-KEY", API_KEY)
                    .GET().build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
            return mapper.readValue(response.body(), new TypeReference<>() {
            });
        } catch (ConnectException e) {
            logger.error("Erro de conexão com o backend ao buscar dados do relatório", e);
            throw new ApiException("Não foi possível conectar ao servidor. O sistema backend está offline?", e);
        } catch (IOException | InterruptedException e) {
            logger.error("Erro inesperado ao buscar dados do relatório", e);
            throw new ApiException("Ocorreu um erro ao buscar dados do relatório.", e);
        }
    }

    /**
     * Chama o endpoint GET /estacionamento/status-patio para obter o
     * estado atual do pátio.
     *
     * @return Um StatusPatioDTO contendo contadores de vagas e lista de
     * veículos ativos.
     * @throws ApiException Se a API retornar um erro ou falhar a conexão.
     */
    public static StatusPatioDTO getStatusPatio() throws ApiException {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL_ESTACIONAMENTO + "/status-patio"))
                    .header("Accept", "application/json")
                    .header("X-API-KEY", API_KEY)
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }

            return mapper.readValue(response.body(), StatusPatioDTO.class);

        } catch (ConnectException e) {
            logger.error("Erro de conexão com o backend ao buscar status do pátio", e);
            throw new ApiException("Não foi possível conectar ao servidor. O sistema backend está offline?", e);
        } catch (IOException | InterruptedException e) {
            logger.error("Erro inesperado ao buscar status do pátio", e);
            throw new ApiException("Ocorreu um erro de comunicação ao buscar o status do pátio.", e);
        }
    }

    // --- MÉTODOS DE API (PREÇO) ---

    /**
     * Chama o endpoint GET /preco para buscar a configuração atual de preços.
     *
     * @return Um PrecoDTO com o valor e os minutos da regra de preço.
     * @throws ApiException Se a API retornar um erro ou falhar a conexão.
     */
    public static PrecoDTO getPreco() throws ApiException {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL_PRECO))
                    .header("X-API-KEY", API_KEY)
                    .GET().build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
            return mapper.readValue(response.body(), PrecoDTO.class);
        } catch (IOException | InterruptedException e) {
            throw new ApiException("Erro ao buscar configurações de preço.", e);
        }
    }

    /**
     * Chama o endpoint PUT /preco para atualizar a configuração de preços.
     *
     * @param dto O PrecoDTO com os novos valores.
     * @throws ApiException Se a API retornar um erro ou falhar a conexão.
     */
    public static void savePreco(PrecoDTO dto) throws ApiException {
        try {
            String requestBody = mapper.writeValueAsString(dto);
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL_PRECO))
                    .header("Content-Type", "application/json")
                    .header("X-API-KEY", API_KEY)
                    .PUT(HttpRequest.BodyPublishers.ofString(requestBody))
                    .build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
        } catch (IOException | InterruptedException e) {
            throw new ApiException("Erro ao salvar configurações de preço.", e);
        }
    }

    // --- MÉTODOS DE API (VAGAS) ---

    /**
     * Chama o endpoint GET /vagas para buscar a configuração de total de vagas.
     *
     * @return Um VagasDispDTO com o total de vagas.
     * @throws ApiException Se a API retornar um erro ou falhar a conexão.
     */
    public static VagasDispDTO getVagas() throws ApiException {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL_VAGAS))
                    .header("X-API-KEY", API_KEY)
                    .GET().build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
            return mapper.readValue(response.body(), VagasDispDTO.class);
        } catch (IOException | InterruptedException e) {
            throw new ApiException("Erro ao buscar a configuração de vagas.", e);
        }
    }

    /**
     * Chama o endpoint PUT /vagas para atualizar o total de vagas.
     *
     * @param dto O VagasDispDTO com o novo total.
     * @throws ApiException Se a API retornar um erro ou falhar a conexão.
     */
    public static void saveVagas(VagasDispDTO dto) throws ApiException {
        try {
            String requestBody = mapper.writeValueAsString(dto);
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL_VAGAS))
                    .header("Content-Type", "application/json")
                    .header("X-API-KEY", API_KEY)
                    .PUT(HttpRequest.BodyPublishers.ofString(requestBody))
                    .build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() != 200) {
                throw new ApiException(extrairMensagemDeErro(response));
            }
        } catch (IOException | InterruptedException e) {
            throw new ApiException("Erro ao salvar a configuração de vagas.", e);
        }
    }

    // --- MÉTODO DE API (PLATE RECOGNIZER) ---

    /**
     * Chama a API externa do Plate Recognizer para identificar uma placa
     * a partir de uma imagem.
     *
     * @param imagem A imagem (foto) da placa.
     * @return A string da placa (ex: "ABC1234") ou nulo se não for encontrada.
     * @throws ApiException Se o token não estiver configurado, for inválido,
     * ou se houver falha de conexão/timeout.
     */
    public static String reconhecerPlacaComPlateRecognizer(BufferedImage imagem) throws ApiException {
        String token = getToken();
        if (token == null || token.isBlank()) {
            throw new ApiException("O serviço de reconhecimento de placas não está ativado.\n" +
                    "Por favor, insira sua 'Chave de Serviço' na tela de Configurações.");
        }

        try {
            final String boundary = "Boundary-" + UUID.randomUUID().toString();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(imagem, "jpeg", baos);
            byte[] imageData = baos.toByteArray();

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://api.platerecognizer.com/v1/plate-reader/"))
                    .header("Authorization", "Token " + token) // Usa o token do usuário
                    .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                    .POST(ofMimeMultipartData(imageData, boundary))
                    .timeout(Duration.ofSeconds(20))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 403) {
                throw new ApiException("A Chave de Serviço fornecida é inválida ou expirou.");
            }
            if (response.statusCode() != 201) {
                throw new ApiException(extrairMensagemDeErro(response));
            }

            JsonNode root = mapper.readTree(response.body());
            JsonNode results = root.path("results");
            if (results.isArray() && results.size() > 0) {
                return results.get(0).path("plate").asText().toUpperCase();
            }
            return null;

        } catch (HttpTimeoutException e) {
            logger.error("Timeout ao chamar o serviço de placas", e);
            throw new ApiException("O serviço de reconhecimento de placas demorou muito para responder.", e);
        } catch (ConnectException e) {
            logger.error("Erro de conexão com o serviço de placas", e);
            throw new ApiException("Não foi possível conectar ao serviço de placas. Verifique sua internet.", e);
        } catch (IOException | InterruptedException e) {
            logger.error("Erro inesperado ao processar a imagem", e);
            throw new ApiException("Ocorreu um erro inesperado ao processar a imagem.", e);
        }
    }

    // --- MÉTODOS AUXILIARES ---

    /**
     * Método auxiliar privado para construir o corpo da requisição
     * 'multipart/form-data' para o envio da imagem.
     *
     * @param imageData Os bytes da imagem JPEG.
     * @param boundary  O delimitador 'boundary' do multipart.
     * @return Um BodyPublisher pronto para ser usado na requisição HTTP.
     */
    private static HttpRequest.BodyPublisher ofMimeMultipartData(byte[] imageData, String boundary) {
        var byteArrays = new ArrayList<byte[]>();
        String separator = "--" + boundary +
                "\r\nContent-Disposition: form-data; name=\"upload\"; "
                + "filename=\"plate.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n";

        byteArrays.add(separator.getBytes(StandardCharsets.UTF_8));
        byteArrays.add(imageData);
        byteArrays.add("\r\n".getBytes(StandardCharsets.UTF_8));
        byteArrays.add(("--" + boundary + "--").getBytes(StandardCharsets.UTF_8));

        return HttpRequest.BodyPublishers.ofByteArrays(byteArrays);
    }

    /**
     * Método auxiliar privado para extrair uma mensagem de erro amigável
     * de uma resposta HTTP de falha.
     * Tenta parsear o JSON de erro padrão do Spring Boot ("message", "error")
     * ou retorna o corpo da resposta como texto.
     *
     * @param response A resposta HTTP (com status != 2xx).
     * @return Uma string contendo a mensagem de erro formatada.
     */
    private static String extrairMensagemDeErro(HttpResponse<String> response) {
        String responseBody = response.body();

        if (responseBody == null || responseBody.isBlank()) {
            return "Ocorreu um erro desconhecido no servidor (Código: " + response.statusCode() + ").";
        }

        // Trata o erro 401 (Não Autorizado) de forma específica
        if (response.statusCode() == 401) {
            return "Não autorizado (Chave de API inválida ou ausente)";
        }

        // Tenta parsear o JSON de erro do Spring (que contém "message" ou "error")
        if (responseBody.strip().startsWith("{") &&
                (responseBody.contains("\"message\"") || responseBody.contains("\"error\""))) {
            try {
                JsonNode root = mapper.readTree(responseBody);
                if (root.has("message")) {
                    return root.path("message").asText("Não foi possível ler a mensagem de erro do servidor.");
                } else if (root.has("error")) {
                    return root.path("error").asText("Erro não especificado.");
                }
            } catch (IOException e) {
                logger.error("Erro ao parsear JSON de erro: {}", responseBody, e);
                return responseBody; // Retorna o corpo do erro se o JSON falhar
            }
        }

        // Retorna o corpo da resposta se não for um JSON de erro esperado
        return responseBody;
    }
}