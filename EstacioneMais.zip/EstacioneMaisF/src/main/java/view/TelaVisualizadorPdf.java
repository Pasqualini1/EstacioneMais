package view;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Painel (JPanel) que atua como um visualizador de PDF.
 * <p>
 * Recebe os bytes de um arquivo PDF ({@code byte[]}), renderiza cada
 * página em uma {@link BufferedImage} usando o Apache PDFBox e as
 * exibe verticalmente em um {@link JScrollPane}.
 * Oferece também a funcionalidade de salvar o PDF em disco.
 */
public class TelaVisualizadorPdf extends JPanel {

    private static final Color COLOR_BACKGROUND = new Color(34, 40, 49);
    private static final Color COLOR_TOP_BAR = new Color(57, 62, 70);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_ORANGE_ACCENT = new Color(255, 157, 8);
    private static final Color COLOR_INPUT_BG = new Color(45, 45, 45);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 18);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 14);

    private final TelaPrincipal telaPrincipal;
    private final byte[] pdfBytes;
    private final JPanel painelPaginas;
    private final JScrollPane scrollPane;
    private final String defaultFileName;

    /**
     * Constrói o painel visualizador de PDF.
     *
     * @param telaPrincipal   A referência à janela principal (JFrame) da aplicação.
     * @param pdfBytes        Os dados (bytes) do arquivo PDF a ser renderizado.
     * @param defaultFileName O nome de arquivo sugerido ao usuário
     * (ex: "Relatorio.pdf") quando ele clicar em "Salvar".
     */
    public TelaVisualizadorPdf(TelaPrincipal telaPrincipal, byte[] pdfBytes, String defaultFileName) {
        this.telaPrincipal = telaPrincipal;
        this.pdfBytes = pdfBytes;
        this.defaultFileName = defaultFileName;

        setLayout(new BorderLayout());
        setBackground(COLOR_BACKGROUND);

        painelPaginas = new JPanel();
        painelPaginas.setLayout(new BoxLayout(painelPaginas, BoxLayout.Y_AXIS));
        painelPaginas.setBackground(COLOR_BACKGROUND);

        scrollPane = new JScrollPane(painelPaginas);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        add(createTopPanel(), BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        carregarPdf();
    }

    /**
     * Acionado pelo botão "Salvar PDF".
     * <p>
     * Abre um {@link CustomFileChooser} (o seletor de arquivos customizado)
     * sugerindo o {@code defaultFileName}. Se o usuário confirmar,
     * salva os {@code pdfBytes} no local escolhido.
     * Ao final, pergunta se o usuário deseja abrir o arquivo salvo.
     */
    private void salvarPdf() {
        File fileToSave = CustomFileChooser.showSaveDialog(this, this.defaultFileName);

        if (fileToSave != null) {
            try (FileOutputStream fos = new FileOutputStream(fileToSave)) {
                fos.write(this.pdfBytes);

                boolean abrir = DialogoCustomizado.mostrarConfirmacao(
                        (Frame) SwingUtilities.getWindowAncestor(this),
                        "Sucesso",
                        "PDF salvo com sucesso! Deseja abrir o arquivo?"
                );

                if (abrir) {
                    if (Desktop.isDesktopSupported()) {
                        Desktop.getDesktop().open(fileToSave);
                    } else {
                        DialogoCustomizado.mostrarMensagemErro((Frame) SwingUtilities.getWindowAncestor(this),
                                "Aviso", "Não foi possível abrir o arquivo automaticamente.");
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
                DialogoCustomizado.mostrarMensagemErro((Frame) SwingUtilities.getWindowAncestor(this), "Erro",
                        "Ocorreu um erro ao salvar o PDF.");
            }
        }
    }

    /**
     * Carrega e renderiza as páginas do PDF de forma assíncrona.
     * <p>
     * Exibe uma mensagem de "Renderizando..." e inicia um {@link SwingWorker}
     * para carregar os {@code pdfBytes} com o PDFBox e converter cada
     * página em uma {@link BufferedImage} (com 150 DPI).
     * <p>
     * Ao concluir, substitui a mensagem de "Renderizando" pelas
     * imagens das páginas, dentro de {@link JLabel}s, no
     * {@code painelPaginas}.
     */
    private void carregarPdf() {
        JLabel lblCarregando = new JLabel("Renderizando PDF, por favor aguarde...");
        lblCarregando.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblCarregando.setForeground(Color.WHITE);
        lblCarregando.setHorizontalAlignment(SwingConstants.CENTER);
        painelPaginas.add(lblCarregando);

        SwingWorker<List<BufferedImage>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<BufferedImage> doInBackground() throws Exception {
                List<BufferedImage> paginas = new ArrayList<>();
                try (PDDocument document = PDDocument.load(pdfBytes)) {
                    PDFRenderer pdfRenderer = new PDFRenderer(document);
                    for (int i = 0; i < document.getNumberOfPages(); i++) {
                        paginas.add(pdfRenderer.renderImageWithDPI(i, 150));
                    }
                }
                return paginas;
            }

            @Override
            protected void done() {
                try {
                    List<BufferedImage> imagensPaginas = get();
                    painelPaginas.removeAll();

                    for (BufferedImage imagem : imagensPaginas) {
                        JLabel lblPagina = new JLabel(new ImageIcon(imagem));
                        lblPagina.setBorder(new EmptyBorder(0, 0, 15, 0));
                        painelPaginas.add(lblPagina);
                    }

                    painelPaginas.revalidate();
                    painelPaginas.repaint();
                    SwingUtilities.invokeLater(() -> scrollPane.getVerticalScrollBar().setValue(0));
                } catch (Exception e) {
                    e.printStackTrace();
                    painelPaginas.removeAll();
                    lblCarregando.setText("Erro ao carregar o PDF.");
                    painelPaginas.add(lblCarregando);
                    painelPaginas.revalidate();
                    painelPaginas.repaint();
                }
            }
        };
        worker.execute();
    }

    /**
     * Cria o painel de cabeçalho (barra superior) do visualizador.
     * <p>
     * Contém o título "Visualizador de Relatório" e os botões de ação
     * "Salvar PDF" e "Voltar".
     *
     * @return Um {@link JPanel} contendo o cabeçalho completo da tela.
     */
    private JPanel createTopPanel() {
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(new EmptyBorder(10, 15, 10, 15));
        topPanel.setBackground(COLOR_TOP_BAR);

        JLabel lblTitulo = new JLabel("Visualizador de Relatório");
        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        topPanel.add(lblTitulo, BorderLayout.WEST);

        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonsPanel.setOpaque(false);

        RoundedButton btnSalvar = new RoundedButton("Salvar PDF");
        btnSalvar.setBackground(COLOR_ORANGE_ACCENT);
        btnSalvar.addActionListener(e -> salvarPdf());
        buttonsPanel.add(btnSalvar);

        RoundedButton btnVoltar = new RoundedButton("Voltar");
        btnVoltar.addActionListener(e -> telaPrincipal.trocarPainelCentral(new TelaRelatorios(telaPrincipal)));
        buttonsPanel.add(btnVoltar);

        topPanel.add(buttonsPanel, BorderLayout.EAST);

        return topPanel;
    }

    /**
     * Classe interna (private) que representa um JButton customizado
     * com cantos arredondados e efeitos de "hover".
     */
    private class RoundedButton extends JButton {
        private Color defaultBg;
        private Color hoverBg;

        /**
         * Construtor do botão arredondado.
         * Configura a aparência e adiciona listeners de mouse para o efeito hover.
         *
         * @param text O texto a ser exibido no botão.
         */
        public RoundedButton(String text) {
            super(text);
            setFont(FONT_BUTTON);
            setForeground(Color.WHITE);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setFocusPainted(false);
            setBorder(new EmptyBorder(10, 20, 10, 20));
            setContentAreaFilled(false);

            this.defaultBg = COLOR_INPUT_BG;
            this.hoverBg = defaultBg.brighter();
            setBackground(defaultBg);

            addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    if (isEnabled()) {
                        setBackground(hoverBg);
                    }
                }

                public void mouseExited(java.awt.event.MouseEvent evt) {
                    setBackground(defaultBg);
                }
            });
        }

        /**
         * Sobrescrito para atualizar as cores de 'default' e 'hover'
         * quando a cor de fundo é alterada programaticamente.
         *
         * @param bg A nova cor de fundo.
         */
        @Override
        public void setBackground(Color bg) {
            if (bg != hoverBg) {
                this.defaultBg = bg;
                this.hoverBg = bg.brighter();
            }
            super.setBackground(bg);
        }

        /**
         * Sobrescreve o método de pintura para desenhar o fundo arredondado.
         * Usa Graphics2D para preencher um 'RoundRect' com antialias.
         *
         * @param g O contexto gráfico fornecido pelo Swing.
         */
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            if (getModel().isPressed()) {
                g2.setColor(getBackground().darker());
            }
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
            super.paintComponent(g2);
            g2.dispose();
        }
    }
}