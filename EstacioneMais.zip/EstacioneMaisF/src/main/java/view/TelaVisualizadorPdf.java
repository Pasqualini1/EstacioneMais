package view;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Um painel que funciona como um visualizador de PDF customizado.
 * Ele recebe os bytes de um arquivo PDF, renderiza cada página como uma imagem e
 * as exibe em uma área rolável, permitindo também que o usuário salve o arquivo.
 */
public class TelaVisualizadorPdf extends JPanel {

    // --- Constantes de Estilo ---
    private static final Color COLOR_BACKGROUND = new Color(34, 40, 49);
    private static final Color COLOR_TOP_BAR = new Color(57, 62, 70);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_ORANGE_ACCENT = new Color(255, 157, 8);
    private static final Color COLOR_INPUT_BG = new Color(45, 45, 45);
    
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 18);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 14);

    // --- Componentes ---
    private final TelaPrincipal telaPrincipal;
    private final byte[] pdfBytes;
    private final JPanel painelPaginas;
    private final JScrollPane scrollPane;

    /**
     * Construtor da tela do visualizador de PDF.
     *
     * @param telaPrincipal A referência à janela principal.
     * @param pdfBytes Os dados do arquivo PDF em um array de bytes.
     */
    public TelaVisualizadorPdf(TelaPrincipal telaPrincipal, byte[] pdfBytes) {
        this.telaPrincipal = telaPrincipal;
        this.pdfBytes = pdfBytes;

        setLayout(new BorderLayout());
        setBackground(COLOR_BACKGROUND);

        painelPaginas = new JPanel();
        painelPaginas.setLayout(new BoxLayout(painelPaginas, BoxLayout.Y_AXIS));
        painelPaginas.setBackground(COLOR_BACKGROUND);

        scrollPane = new JScrollPane(painelPaginas);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        add(createTopPanel(), BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        carregarPdf();
    }

    /**
     * Ação do botão "Salvar PDF". Abre uma janela para o usuário escolher o local,
     * salva o arquivo e pergunta se deseja abri-lo em seguida.
     */
    private void salvarPdf() {
        // Utiliza o nosso seletor de arquivos customizado.
        File fileToSave = CustomFileChooser.showSaveDialog(this, "relatorio_movimentacao.pdf");

        if (fileToSave != null) {
            try (FileOutputStream fos = new FileOutputStream(fileToSave)) {
                // Escreve os bytes do PDF (que já temos em memória) no arquivo selecionado.
                fos.write(this.pdfBytes);
                
                // Pede confirmação ao usuário para abrir o arquivo recém-salvo.
                boolean abrir = DialogoCustomizado.mostrarConfirmacao(
                    (Frame) SwingUtilities.getWindowAncestor(this),
                    "Sucesso",
                    "PDF salvo com sucesso! Deseja abrir o arquivo?"
                );
                
                if (abrir) {
                    // Tenta abrir o arquivo usando o programa padrão do sistema operacional.
                    if (Desktop.isDesktopSupported()) {
                        Desktop.getDesktop().open(fileToSave);
                    } else {
                        DialogoCustomizado.mostrarMensagemErro((Frame) 
                                SwingUtilities.getWindowAncestor(this), 
                                "Aviso", "Não foi possível abrir o arquivo automaticamente.");
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
                DialogoCustomizado.mostrarMensagemErro((Frame) 
                        SwingUtilities.getWindowAncestor(this), "Erro", 
                        "Ocorreu um erro ao salvar o PDF.");
            }
        }
    }

    /**
     * Carrega e renderiza o PDF de forma assíncrona.
     * Usa um SwingWorker para converter cada página do PDF em uma imagem (BufferedImage)
     * sem travar a interface, e então exibe as imagens na tela.
     */
    private void carregarPdf() {
        JLabel lblCarregando = new JLabel("Renderizando PDF, por favor aguarde...");
        lblCarregando.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblCarregando.setForeground(Color.WHITE);
        lblCarregando.setHorizontalAlignment(SwingConstants.CENTER);
        painelPaginas.add(lblCarregando);

        SwingWorker<List<BufferedImage>, Void> worker = new SwingWorker<>() {
            /**
             * Em uma thread de background, carrega o PDF a partir dos bytes e renderiza
             * cada página em uma imagem com 150 DPI.
             */
            @Override
            protected List<BufferedImage> doInBackground() throws Exception {
                List<BufferedImage> paginas = new ArrayList<>();
                try (PDDocument document = PDDocument.load(pdfBytes)) {
                    PDFRenderer pdfRenderer = new PDFRenderer(document);
                    for (int i = 0; i < document.getNumberOfPages(); i++) {
                        paginas.add(pdfRenderer.renderImageWithDPI(i, 150));
                    }
                }
                return paginas;
            }

            /**
             * Na thread do Swing, após a renderização, remove a mensagem de "carregando"
             * e adiciona as imagens das páginas ao painel rolável.
             */
            @Override
            protected void done() {
                try {
                    List<BufferedImage> imagensPaginas = get();
                    painelPaginas.removeAll();

                    for (BufferedImage imagem : imagensPaginas) {
                        JLabel lblPagina = new JLabel(new ImageIcon(imagem));
                        lblPagina.setBorder(new EmptyBorder(0, 0, 15, 0));
                        painelPaginas.add(lblPagina);
                    }
                    
                    painelPaginas.revalidate();
                    painelPaginas.repaint();
                    // Garante que o scroll volte para o topo após carregar as imagens.
                    SwingUtilities.invokeLater(() -> scrollPane.getVerticalScrollBar().setValue(0));

                } catch (Exception e) {
                    e.printStackTrace();
                    painelPaginas.removeAll();
                    lblCarregando.setText("Erro ao carregar o PDF.");
                    painelPaginas.add(lblCarregando);
                    painelPaginas.revalidate();
                    painelPaginas.repaint();
                }
            }
        };
        worker.execute();
    }

    private JPanel createTopPanel() {
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(new EmptyBorder(10, 15, 10, 15));
        topPanel.setBackground(COLOR_TOP_BAR);

        JLabel lblTitulo = new JLabel("Visualizador de Relatório");
        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        topPanel.add(lblTitulo, BorderLayout.WEST);

        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonsPanel.setOpaque(false);

        RoundedButton btnSalvar = new RoundedButton("Salvar PDF");
        btnSalvar.setBackground(COLOR_ORANGE_ACCENT);
        btnSalvar.addActionListener(e -> salvarPdf());
        buttonsPanel.add(btnSalvar);

        RoundedButton btnVoltar = new RoundedButton("Voltar");
        btnVoltar.addActionListener(e -> telaPrincipal.trocarPainelCentral(new TelaRelatorios(telaPrincipal)));
        buttonsPanel.add(btnVoltar);
        
        topPanel.add(buttonsPanel, BorderLayout.EAST);

        return topPanel;
    }

    /**
     * Um botão customizado com cantos arredondados e efeito de hover.
     */
    private class RoundedButton extends JButton {
        private Color defaultBg;
        private Color hoverBg;

        public RoundedButton(String text) {
            super(text);
            setFont(FONT_BUTTON);
            setForeground(Color.WHITE);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setFocusPainted(false);
            setBorder(new EmptyBorder(10, 20, 10, 20));
            setContentAreaFilled(false);
            
            this.defaultBg = COLOR_INPUT_BG;
            this.hoverBg = defaultBg.brighter();
            setBackground(defaultBg);

            addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    if (isEnabled()) {
                        setBackground(hoverBg);
                    }
                }
                public void mouseExited(java.awt.event.MouseEvent evt) {
                    setBackground(defaultBg);
                }
            });
        }
        
        @Override
        public void setBackground(Color bg) {
            if (bg != hoverBg) {
                this.defaultBg = bg;
                this.hoverBg = bg.brighter();
            }
            super.setBackground(bg);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            if (getModel().isPressed()) {
                g2.setColor(getBackground().darker());
            }
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
            super.paintComponent(g2);
            g2.dispose();
        }
    }
}