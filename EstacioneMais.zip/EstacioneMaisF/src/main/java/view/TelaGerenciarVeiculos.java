package view;

// --- NOVOS IMPORTS ---
import dto.StatusPatioDTO;
import dto.VeiculoStatusDTO;
// --- FIM DOS NOVOS IMPORTS ---

import dto.VeiculoDTO;
import service.ApiClient;
import service.ApiException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
// (Imports de JTable não são mais necessários)
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class TelaGerenciarVeiculos extends JPanel {

    // --- Estilos ---
    private static final Color COLOR_BACKGROUND = new Color(34, 40, 49);
    private static final Color COLOR_PANEL = new Color(57, 62, 70);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_ACCENT = new Color(0, 173, 181);
    private static final Color COLOR_BUTTON_SAIDA = new Color(220, 53, 69);
    private static final Color COLOR_SHADOW = new Color(0, 0, 0, 80);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private static final Font FONT_ROW = new Font("Segoe UI", Font.PLAIN, 14);

    // --- NOVOS Estilos para Vagas ---
    private static final Color COLOR_VAGA_DISPONIVEL = new Color(40, 167, 69); // Verde
    private static final Color COLOR_VAGA_OCUPADA = new Color(220, 53, 69); // Vermelho

    // --- NOVOS Componentes ---
    private final TelaPrincipal telaPrincipal;
    private JPanel painelGridVagas;
    private JLabel lblTotalVagas;
    private JLabel lblVagasOcupadas;
    private JLabel lblVagasDisponiveis;

    public TelaGerenciarVeiculos(TelaPrincipal telaPrincipal) {
        this.telaPrincipal = telaPrincipal;
        setLayout(new GridBagLayout());
        setBackground(COLOR_BACKGROUND);

        // O painel central estilizado agora é o nosso
        add(createStyledCentralPanel(), new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0,
                GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(30, 30, 30, 30), 0, 0));

        // Carrega os dados da API assim que a tela for criada
        carregarStatusPatio();
    }

    /**
     * NOVA LÓGICA: Carrega os dados do endpoint /status-patio e reconstrói a UI.
     * Substitui o antigo 'carregarVeiculosAtivos()'.
     */
    private void carregarStatusPatio() {
        // Mostra um feedback de carregamento (opcional)
        if (lblTotalVagas != null) { // Evita erro na primeira inicialização
            lblTotalVagas.setText("Total: ...");
            lblVagasOcupadas.setText("Ocupadas: ...");
            lblVagasDisponiveis.setText("Disponíveis: ...");
        }
        painelGridVagas.removeAll();

        SwingWorker<StatusPatioDTO, Void> worker = new SwingWorker<>() {
            @Override
            protected StatusPatioDTO doInBackground() throws ApiException {
                // Chama o novo método do ApiClient
                return ApiClient.getStatusPatio();
            }

            @Override
            protected void done() {
                try {
                    StatusPatioDTO status = get();

                    // 1. Atualiza os contadores
                    lblTotalVagas.setText("Total de Vagas: " + status.totalVagas());
                    lblVagasOcupadas.setText("Ocupadas: " + status.vagasOcupadas());
                    lblVagasDisponiveis.setText("Disponíveis: " + status.vagasDisponiveis());

                    // 2. Adiciona os "carrinhos vermelhos" (ocupadas)
                    for (VeiculoStatusDTO veiculo : status.veiculosNoPatio()) {
                        painelGridVagas.add(createVagaPanel(veiculo));
                    }

                    // 3. Adiciona os "carrinhos verdes" (disponíveis)
                    for (int i = 0; i < status.vagasDisponiveis(); i++) {
                        painelGridVagas.add(createVagaPanel(null));
                    }

                    // 4. Atualiza o painel do grid
                    painelGridVagas.revalidate();
                    painelGridVagas.repaint();

                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() : "Ocorreu um erro inesperado.";
                    DialogoCustomizado.mostrarMensagemErro(
                            (Frame) SwingUtilities.getWindowAncestor(TelaGerenciarVeiculos.this),
                            "Erro", "Erro ao carregar status do pátio:\n" + errorMessage
                    );
                }
            }
        };
        worker.execute();
    }

    /**
     * NOVA LÓGICA: Exibe o popup com os detalhes do veículo E o botão de registrar saída.
     */
    private void mostrarPopupVeiculo(VeiculoStatusDTO veiculo) {
        Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yy 'às' HH:mm");
        
        String mensagem = String.format(
            "Placa: %s\n" +
            "Cliente: %s\n" +
            "Telefone: %s\n" +
            "Modelo: %s (%s)\n\n" +
            "Entrada: %s\n" +
            "Tempo no Pátio: %s\n" +
            "Valor Atual: R$ %.2f\n\n" + 
            "Deseja registrar a saída deste veículo?", // Adiciona a pergunta
            veiculo.placa(),
            veiculo.nomeCliente() != null ? veiculo.nomeCliente() : "Não informado",
            veiculo.telefoneCliente() != null ? veiculo.telefoneCliente() : "Não informado",
            veiculo.modelo() != null ? veiculo.modelo() : "Não informado",
            veiculo.cor() != null ? veiculo.cor() : "N/A",
            veiculo.horarioEntrada().format(formatter),
            veiculo.tempoEstacionado(),
            veiculo.valorAtual()
        );

        // Reutiliza o seu 'DialogoCustomizado.mostrarConfirmacao'
        boolean confirm = DialogoCustomizado.mostrarConfirmacao(
            owner,
            "Registrar Saída do Veículo",
            mensagem
        );
        
        // Se o usuário clicar "Sim", chama o método de confirmação que já existia
        if (confirm) {
            confirmarRegistroSaida(veiculo.placa());
        }
    }


    /**
     * MÉTODO ANTIGO (REUTILIZADO): Confirma e registra a saída.
     * A única mudança é chamar carregarStatusPatio() no final.
     */
    private void confirmarRegistroSaida(String placa) {
        Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);

        SwingWorker<Void, Void> finalWorker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws ApiException {
                ApiClient.registrarSaida(placa);
                return null;
            }

            @Override
            protected void done() {
                try {
                    get();
                    DialogoCustomizado.mostrarMensagemSucesso(
                            owner,
                            "Sucesso",
                            "Saída do veículo " + placa + " registrada com sucesso!"
                    );
                    // --- MUDANÇA IMPORTANTE AQUI ---
                    // Recarrega o pátio, em vez da tabela antiga
                    carregarStatusPatio();
                    // --- FIM DA MUDANÇA ---
                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() : "Ocorreu um erro inesperado.";
                    DialogoCustomizado.mostrarMensagemErro(owner, "Erro", "Erro ao confirmar a saída:\n" + errorMessage);
                }
            }
        };
        finalWorker.execute();
    }
    
    // --- FORMATAR DATA (Sem mudanças) ---
    private String formatarData(LocalDateTime data) {
        if (data == null) return "N/A";
        return data.format(DateTimeFormatter.ofPattern("dd/MM/yy HH:mm"));
    }
    
    // --- LOAD ICON (Sem mudanças) ---
    private ImageIcon loadIcon(String path, int width, int height) {
        File file = new File(path);
        if (!file.exists()) {
            System.err.println("Imagem não encontrada: " + path);
            return new ImageIcon(new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB));
        }
        ImageIcon icon = new ImageIcon(path);
        if (width > 0 && height > 0) {
            Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
            icon = new ImageIcon(img);
        }
        return icon;
    }

    // --- MÉTODOS DE CONSTRUÇÃO DA UI (Atualizados) ---

    private JPanel createStyledCentralPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(COLOR_SHADOW);
                g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 20, 20);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
            }
        };
        panel.setBackground(COLOR_PANEL);
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(25, 25, 25, 25));
        
        // --- MUDANÇA AQUI ---
        // Adiciona o Título (Norte)
        panel.add(createTitlePanel(), BorderLayout.NORTH);
        // Adiciona o Conteúdo Principal (Contadores + Grid) (Centro)
        panel.add(createMainContentPanel(), BorderLayout.CENTER);
        // --- FIM DA MUDANÇA ---
        
        return panel;
    }
    
    private JPanel createTitlePanel() {
        JPanel panelTitulo = new JPanel(new BorderLayout());
        panelTitulo.setOpaque(false);
        
        JLabel lblTitulo = new JLabel("Veículos Atualmente no Pátio");
        lblTitulo.setIcon(loadIcon("src/imagens/gerenciar_icon.png", 28, 28)); // Mantém o ícone original
        lblTitulo.setIconTextGap(10);
        
        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        panelTitulo.add(lblTitulo, BorderLayout.WEST);
        
        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        painelBotoes.setOpaque(false);
        JButton btnAtualizar = createIconButton("🔄", "Atualizar Pátio");
        
        // --- MUDANÇA AQUI ---
        btnAtualizar.addActionListener(e -> carregarStatusPatio()); // Chama o novo método
        // --- FIM DA MUDANÇA ---
        
        painelBotoes.add(btnAtualizar);
        JButton btnFechar = createIconButton("X", "Fechar");
        btnFechar.addActionListener(e -> telaPrincipal.mostrarPainelInicial());
        painelBotoes.add(btnFechar);
        panelTitulo.add(painelBotoes, BorderLayout.EAST);
        return panelTitulo;
    }
    
    /**
     * NOVO MÉTODO: Cria o painel de conteúdo que agrupa os contadores e o grid de vagas.
     */
    private JPanel createMainContentPanel() {
        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setOpaque(false);
        // Adiciona os contadores (Norte)
        mainPanel.add(createCountersPanel(), BorderLayout.NORTH);
        // Adiciona o grid rolável (Centro)
        mainPanel.add(createPatioGridScrollPane(), BorderLayout.CENTER);
        return mainPanel;
    }

    /**
     * NOVO MÉTODO: Cria o painel de contadores (Total, Ocupadas, Disponíveis).
     */
    private JPanel createCountersPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 50, 10));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, COLOR_BACKGROUND.brighter()));

        // Inicializa os JLabels (eles serão preenchidos pelo carregarStatusPatio)
        lblTotalVagas = new JLabel("Total: --");
        lblVagasOcupadas = new JLabel("Ocupadas: --");
        lblVagasDisponiveis = new JLabel("Disponíveis: --");

        Font fontContador = new Font("Segoe UI", Font.BOLD, 18);
        lblTotalVagas.setFont(fontContador);
        lblTotalVagas.setForeground(COLOR_TEXT_PRIMARY);
        lblVagasOcupadas.setFont(fontContador);
        lblVagasOcupadas.setForeground(COLOR_VAGA_OCUPADA); // Cor vermelha
        lblVagasDisponiveis.setFont(fontContador);
        lblVagasDisponiveis.setForeground(COLOR_VAGA_DISPONIVEL); // Cor verde

        panel.add(lblTotalVagas);
        panel.add(lblVagasOcupadas);
        panel.add(lblVagasDisponiveis);
        return panel;
    }

    /**
     * MÉTODO ATUALIZADO: Cria o grid de vagas (antes era createTableScrollPane)
     */
    private JScrollPane createPatioGridScrollPane() {
        // Usa o GridLayout com 6 colunas, como definido anteriormente
        int numColunas = 6;
        painelGridVagas = new JPanel(new GridLayout(0, numColunas, 20, 20));
        
        painelGridVagas.setBackground(COLOR_PANEL.darker());
        painelGridVagas.setBorder(new EmptyBorder(20, 20, 20, 20));

        JScrollPane scrollPane = new JScrollPane(painelGridVagas);
        scrollPane.setBorder(BorderFactory.createLineBorder(COLOR_BACKGROUND, 1));
        scrollPane.getViewport().setBackground(COLOR_PANEL.darker());
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        return scrollPane;
    }
    
    /**
     * NOVO MÉTODO: Cria o painel individual de cada vaga (o "carrinho").
     * @param veiculo O VeiculoStatusDTO se a vaga estiver ocupada, ou null se estiver livre.
     */
    private JPanel createVagaPanel(VeiculoStatusDTO veiculo) {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        
        Dimension vagaSize = new Dimension(130, 90);
        panel.setPreferredSize(vagaSize);
        panel.setMinimumSize(vagaSize); 
        
        // Painel transparente
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createLineBorder(COLOR_BACKGROUND.brighter()));

        JLabel iconLabel = new JLabel();
        iconLabel.setHorizontalAlignment(SwingConstants.CENTER);
        iconLabel.setOpaque(false);

        if (veiculo != null) {
            // VAGA OCUPADA
            iconLabel.setIcon(loadIcon("src/imagens/car_icon_red.png", 40, 40));
            panel.setCursor(new Cursor(Cursor.HAND_CURSOR));
            panel.setToolTipText("Placa: " + veiculo.placa() + " - Clique para registrar saída");

            JLabel textLabel = new JLabel(veiculo.placa());
            textLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
            textLabel.setForeground(COLOR_VAGA_OCUPADA); // Placa com cor vermelha
            textLabel.setHorizontalAlignment(SwingConstants.CENTER);
            
            panel.add(iconLabel, BorderLayout.CENTER);
            panel.add(textLabel, BorderLayout.SOUTH);
            
            // Adiciona a ação de clique para abrir o popup
            panel.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    mostrarPopupVeiculo(veiculo);
                }
            });
        } else {
            // VAGA DISPONÍVEL
            iconLabel.setIcon(loadIcon("src/imagens/car_icon_green.png", 40, 40));
            panel.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            
            JLabel textLabel = new JLabel(" "); // Vazio para alinhar
            textLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
            panel.add(textLabel, BorderLayout.SOUTH);
            
            panel.add(iconLabel, BorderLayout.CENTER);
        }

        return panel;
    }

    // --- createIconButton (Sem mudanças) ---
    private JButton createIconButton(String icon, String tooltip) {
        JButton button = new JButton(icon);
        button.setFont(new Font("Segoe UI Symbol", Font.BOLD, 16));
        button.setForeground(COLOR_TEXT_PRIMARY);
        button.setToolTipText(tooltip);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setContentAreaFilled(false);
        button.setBorder(null);
        button.setFocusPainted(false);
        return button;
    }
    
    // --- MÉTODOS E CLASSES DA JTABLE (Removidos) ---
    // 'styleTable()', 'ButtonRenderer' e 'ButtonEditor' foram removidos.
}