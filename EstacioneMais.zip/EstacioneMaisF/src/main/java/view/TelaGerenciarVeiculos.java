package view;

import dto.VeiculoDTO;
import service.ApiClient;
import service.ApiException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Painel principal para gerenciar os veículos que estão atualmente no pátio.
 * Exibe os veículos em uma tabela interativa que permite registrar a saída
 * diretamente de um botão na linha correspondente.
 */
public class TelaGerenciarVeiculos extends JPanel {

    // --- Constantes de Estilo ---
    private static final Color COLOR_BACKGROUND = new Color(34, 40, 49);
    private static final Color COLOR_PANEL = new Color(57, 62, 70);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_ACCENT = new Color(0, 173, 181);
    private static final Color COLOR_BUTTON_SAIDA = new Color(220, 53, 69);
    private static final Color COLOR_SHADOW = new Color(0, 0, 0, 80);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private static final Font FONT_ROW = new Font("Segoe UI", Font.PLAIN, 14);

    // --- Componentes ---
    private final JTable tabela;
    private final DefaultTableModel modeloTabela;
    private final TelaPrincipal telaPrincipal;
    
    private int hoveredRow = -1; // Armazena a linha sob o cursor para o efeito de hover no botão

    /**
     * Construtor da tela. Monta a UI e, crucialmente, adiciona os listeners de mouse
     * na tabela para gerenciar o efeito de hover dos botões de ação.
     */
    public TelaGerenciarVeiculos(TelaPrincipal telaPrincipal) {
        this.telaPrincipal = telaPrincipal;
        setLayout(new GridBagLayout());
        setBackground(COLOR_BACKGROUND);

        String[] colunas = {"Placa", "Cliente", "Modelo", "Cor", "Ano", "Entrada", "Status", "Ação"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Apenas a última coluna (Ação) pode ser "editada" (clicada).
                return column == getColumnCount() - 1;
            }
        };
        tabela = new JTable(modeloTabela);

        // Listener para detectar o movimento do mouse sobre a tabela e criar o efeito de hover no botão.
        tabela.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                int row = tabela.rowAtPoint(e.getPoint());
                int col = tabela.columnAtPoint(e.getPoint());
                int acaoColumnIndex = tabela.getColumnModel().getColumnIndex("Ação");

                if (row > -1 && col == acaoColumnIndex) {
                    if (row != hoveredRow) {
                        hoveredRow = row;
                        tabela.repaint(); // Força o redesenho da tabela para mostrar o hover
                    }
                } else {
                    if (hoveredRow != -1) {
                        hoveredRow = -1;
                        tabela.repaint(); // Força o redesenho para remover o hover
                    }
                }
            }
        });
        
        // Listener para garantir que o hover seja removido se o mouse sair da área da tabela.
        tabela.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent e) {
                if (hoveredRow != -1) {
                    hoveredRow = -1;
                    tabela.repaint();
                }
            }
        });

        add(createStyledCentralPanel(), new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0, 
                GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(30, 30, 30, 30), 0, 0));

        carregarVeiculosAtivos();
    }

    /**
     * Busca os dados dos veículos ativos na API de forma assíncrona usando um SwingWorker,
     * e então popula a tabela com os resultados.
     */
    private void carregarVeiculosAtivos() {
        modeloTabela.setRowCount(0);

        SwingWorker<List<VeiculoDTO>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<VeiculoDTO> doInBackground() throws ApiException {
                return ApiClient.listarVeiculosAtivos();
            }

            @Override
            protected void done() {
                try {
                    List<VeiculoDTO> veiculos = get();
                    for (VeiculoDTO v : veiculos) {
                        String clienteInfo = v.nomeCliente() + (v.telefoneCliente() != 
                                null && !v.telefoneCliente().isBlank() ? 
                                " (" + v.telefoneCliente() + ")" : "");
                        modeloTabela.addRow(new Object[]{
                            v.placa(), clienteInfo, v.modelo(), v.cor(), v.ano(),
                            formatarData(v.horarioEntrada()), "No Pátio", "📤 Registrar Saída"
                        });
                    }
                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() : 
                            "Ocorreu um erro inesperado.";
                    DialogoCustomizado.mostrarMensagemErro(
                        (Frame) SwingUtilities.getWindowAncestor(TelaGerenciarVeiculos.this),
                        "Erro", "Erro ao carregar veículos:\n" + errorMessage
                    );
                }
            }
        };
        worker.execute();
    }

    /**
     * Lida com a lógica de registrar a saída de um veículo.
     * Pede confirmação ao usuário e, se confirmado, chama a API de forma assíncrona.
     *
     * @param row O índice da linha na tabela correspondente ao veículo.
     */
    private void registrarSaidaVeiculo(int row) {
        if (row < 0 || row >= modeloTabela.getRowCount()) return;
        String placa = (String) tabela.getValueAt(row, 0);

        boolean confirm = DialogoCustomizado.mostrarConfirmacao(
            (Frame) SwingUtilities.getWindowAncestor(this),
            "Confirmação de Saída",
            "Deseja realmente registrar a SAÍDA do veículo de placa " + placa + "?"
        );

        if (!confirm) return;

        SwingWorker<Void, Void> worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws ApiException {
                ApiClient.registrarSaida(placa);
                return null;
            }

            @Override
            protected void done() {
                try {
                    get();
                    DialogoCustomizado.mostrarMensagemSucesso(
                        (Frame) SwingUtilities.getWindowAncestor(TelaGerenciarVeiculos.this),
                        "Sucesso", "Saída do veículo " + placa + " registrada com sucesso!"
                    );
                    carregarVeiculosAtivos(); // Recarrega a lista para remover o veículo que saiu
                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() : 
                            "Ocorreu um erro inesperado.";
                    DialogoCustomizado.mostrarMensagemErro(
                        (Frame) SwingUtilities.getWindowAncestor(TelaGerenciarVeiculos.this),
                        "Erro", "Erro ao registrar saída:\n" + errorMessage
                    );
                }
            }
        };
        worker.execute();
    }
    
    /**
     * Formata um objeto LocalDateTime para uma string amigável (dd/MM/yy HH:mm).
     */
    private String formatarData(LocalDateTime data) {
        if (data == null) return "N/A";
        return data.format(DateTimeFormatter.ofPattern("dd/MM/yy HH:mm"));
    }
    
    private JPanel createStyledCentralPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(COLOR_SHADOW);
                g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 20, 20);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
            }
        };
        panel.setBackground(COLOR_PANEL);
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(25, 25, 25, 25));
        panel.add(createTitlePanel(), BorderLayout.NORTH);
        panel.add(createTableScrollPane(), BorderLayout.CENTER);
        return panel;
    }
    private JPanel createTitlePanel() {
        JPanel panelTitulo = new JPanel(new BorderLayout());
        panelTitulo.setOpaque(false);
        JLabel lblTitulo = new JLabel("🚗 Veículos Atualmente no Pátio");
        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        panelTitulo.add(lblTitulo, BorderLayout.WEST);
        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        painelBotoes.setOpaque(false);
        JButton btnAtualizar = createIconButton("🔄", "Atualizar Lista");
        btnAtualizar.addActionListener(e -> carregarVeiculosAtivos());
        painelBotoes.add(btnAtualizar);
        JButton btnFechar = createIconButton("X", "Fechar");
        btnFechar.addActionListener(e -> telaPrincipal.mostrarPainelInicial());
        painelBotoes.add(btnFechar);
        panelTitulo.add(painelBotoes, BorderLayout.EAST);
        return panelTitulo;
    }
    private JScrollPane createTableScrollPane() {
        styleTable();
        JScrollPane scrollPane = new JScrollPane(tabela);
        scrollPane.setBorder(BorderFactory.createLineBorder(COLOR_BACKGROUND, 1));
        scrollPane.getViewport().setBackground(COLOR_PANEL);
        return scrollPane;
    }
    private void styleTable() {
        tabela.setRowHeight(45);
        tabela.setFont(FONT_ROW);
        tabela.setForeground(COLOR_TEXT_PRIMARY);
        tabela.setBackground(COLOR_PANEL);
        tabela.setGridColor(COLOR_BACKGROUND);
        tabela.setSelectionBackground(COLOR_ACCENT.darker());
        tabela.setSelectionForeground(Color.WHITE);
        tabela.setFillsViewportHeight(true);
        tabela.setShowVerticalLines(false);
        JTableHeader header = tabela.getTableHeader();
        header.setBackground(COLOR_BACKGROUND);
        header.setForeground(COLOR_ACCENT);
        header.setFont(FONT_HEADER);
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(0, 50));
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        DefaultTableCellRenderer leftRenderer = new DefaultTableCellRenderer();
        leftRenderer.setHorizontalAlignment(JLabel.LEFT);
        tabela.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        tabela.getColumnModel().getColumn(1).setCellRenderer(leftRenderer);
        tabela.getColumnModel().getColumn(2).setCellRenderer(leftRenderer);
        tabela.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
        tabela.getColumnModel().getColumn(4).setCellRenderer(centerRenderer);
        tabela.getColumnModel().getColumn(5).setCellRenderer(centerRenderer);
        tabela.getColumnModel().getColumn(6).setCellRenderer(centerRenderer);
        tabela.getColumn("Ação").setCellRenderer(new ButtonRenderer());
        tabela.getColumn("Ação").setCellEditor(new ButtonEditor(new JCheckBox()));
    }
    private JButton createIconButton(String icon, String tooltip) {
        JButton button = new JButton(icon);
        button.setFont(new Font("Segoe UI Symbol", Font.BOLD, 16));
        button.setForeground(COLOR_TEXT_PRIMARY);
        button.setToolTipText(tooltip);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setContentAreaFilled(false);
        button.setBorder(null);
        button.setFocusPainted(false);
        return button;
    }

    /**
     * Classe responsável por DESENHAR o botão na célula da tabela.
     * Ela não lida com cliques, apenas com a aparência.
     */
    private class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
            setFont(new Font("Segoe UI Symbol", Font.BOLD, 12));
            setForeground(Color.WHITE);
            setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, 
                boolean isSelected, boolean hasFocus, int row, int column) {
            setText((value == null) ? "" : value.toString());
            // Altera a cor de fundo se o mouse estiver sobre esta linha (efeito hover)
            setBackground(row == hoveredRow ? COLOR_BUTTON_SAIDA.brighter() : COLOR_BUTTON_SAIDA);
            return this;
        }
    }

    /**
     * Classe responsável por LIDAR COM O CLIQUE no botão da célula da tabela.
     * Ela que efetivamente executa a ação de registrar a saída.
     */
    private class ButtonEditor extends DefaultCellEditor {
        protected JButton button;
        private int currentRow;
        private boolean isPushed;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(e -> fireEditingStopped());
            button.setFont(new Font("Segoe UI Symbol", Font.BOLD, 12));
            button.setForeground(Color.WHITE);
            button.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, 
                boolean isSelected, int row, int column) {
            this.currentRow = row;
            button.setText(value == null ? "" : value.toString());
            button.setBackground(COLOR_BUTTON_SAIDA.darker()); // Cor de "pressionado"
            isPushed = true;
            return button;
        }

        /**
         * Este método é chamado QUANDO o clique no botão é finalizado.
         * É aqui que a ação de registrar a saída é disparada.
         */
        @Override
        public Object getCellEditorValue() {
            if (isPushed) {
                registrarSaidaVeiculo(currentRow);
            }
            isPushed = false;
            return "📤 Registrar Saída"; // O valor que a célula terá após a edição
        }

        @Override
        public boolean stopCellEditing() {
            isPushed = false;
            return super.stopCellEditing();
        }
    }
}