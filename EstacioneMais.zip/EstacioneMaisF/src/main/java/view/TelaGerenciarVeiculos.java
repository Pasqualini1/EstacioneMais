package view;

import dto.StatusPatioDTO;
import dto.VeiculoStatusDTO;
import service.ApiClient;
import service.ApiException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Painel (JPanel) que exibe a tela principal "Status do Pátio".
 * <p>
 * Esta tela (anteriormente "Gerenciar Veículos") foi refatorada para
 * exibir um grid visual das vagas (ocupadas e livres), em vez de uma tabela.
 * Ela busca os dados do endpoint '/status-patio' e permite o registro
 * de saída ao clicar em uma vaga ocupada.
 */
public class TelaGerenciarVeiculos extends JPanel {

    // --- Estilos ---
    private static final Color COLOR_BACKGROUND = new Color(34, 40, 49);
    private static final Color COLOR_PANEL = new Color(57, 62, 70);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_ACCENT = new Color(0, 173, 181);
    private static final Color COLOR_BUTTON_SAIDA = new Color(220, 53, 69);
    private static final Color COLOR_SHADOW = new Color(0, 0, 0, 80);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private static final Font FONT_ROW = new Font("Segoe UI", Font.PLAIN, 14);

    // --- Estilos para Vagas ---
    private static final Color COLOR_VAGA_DISPONIVEL = new Color(40, 167, 69); // Verde
    private static final Color COLOR_VAGA_OCUPADA = new Color(220, 53, 69); // Vermelho

    // --- Componentes ---
    private final TelaPrincipal telaPrincipal;
    private JPanel painelGridVagas;
    private JLabel lblTotalVagas;
    private JLabel lblVagasOcupadas;
    private JLabel lblVagasDisponiveis;

    /**
     * Constrói a tela "Status do Pátio".
     *
     * @param telaPrincipal A referência à janela principal (JFrame) da aplicação,
     * usada para navegação e como "pai" dos diálogos.
     */
    public TelaGerenciarVeiculos(TelaPrincipal telaPrincipal) {
        this.telaPrincipal = telaPrincipal;
        setLayout(new GridBagLayout());
        setBackground(COLOR_BACKGROUND);

        add(createStyledCentralPanel(), new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0,
                GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(30, 30, 30, 30), 0, 0));

        carregarStatusPatio();
    }

    /**
     * Carrega o status completo do pátio de forma assíncrona.
     * <p>
     * Utiliza um {@link SwingWorker} para chamar o endpoint
     * {@code ApiClient.getStatusPatio()} em background.
     * Ao concluir, atualiza os contadores (total, ocupadas, disponíveis)
     * e reconstrói o {@code painelGridVagas} com os painéis
     * de vagas ({@code createVagaPanel}) correspondentes.
     */
    private void carregarStatusPatio() {
        if (lblTotalVagas != null) {
            lblTotalVagas.setText("Total: ...");
            lblVagasOcupadas.setText("Ocupadas: ...");
            lblVagasDisponiveis.setText("Disponíveis: ...");
        }
        painelGridVagas.removeAll();

        SwingWorker<StatusPatioDTO, Void> worker = new SwingWorker<>() {
            @Override
            protected StatusPatioDTO doInBackground() throws ApiException {
                return ApiClient.getStatusPatio();
            }

            @Override
            protected void done() {
                try {
                    StatusPatioDTO status = get();

                    lblTotalVagas.setText("Total de Vagas: " + status.totalVagas());
                    lblVagasOcupadas.setText("Ocupadas: " + status.vagasOcupadas());
                    lblVagasDisponiveis.setText("Disponíveis: " + status.vagasDisponiveis());

                    for (VeiculoStatusDTO veiculo : status.veiculosNoPatio()) {
                        painelGridVagas.add(createVagaPanel(veiculo));
                    }

                    for (int i = 0; i < status.vagasDisponiveis(); i++) {
                        painelGridVagas.add(createVagaPanel(null));
                    }

                    painelGridVagas.revalidate();
                    painelGridVagas.repaint();

                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() : "Ocorreu um erro inesperado.";
                    DialogoCustomizado.mostrarMensagemErro(
                            (Frame) SwingUtilities.getWindowAncestor(TelaGerenciarVeiculos.this),
                            "Erro", "Erro ao carregar status do pátio:\n" + errorMessage
                    );
                }
            }
        };
        worker.execute();
    }

    /**
     * Exibe um diálogo de confirmação para registrar a saída de um veículo.
     * <p>
     * Formata os detalhes do veículo (placa, cliente, tempo, valor) em uma
     * mensagem e utiliza o {@link DialogoCustomizado} para perguntar ao
     * usuário se deseja confirmar a saída.
     * Se o usuário confirmar, chama o método {@link #confirmarRegistroSaida}.
     *
     * @param veiculo O DTO do veículo (vaga ocupada) que foi clicado.
     */
    private void mostrarPopupVeiculo(VeiculoStatusDTO veiculo) {
        Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yy 'às' HH:mm");

        String mensagem = String.format(
                "Placa: %s\n" +
                        "Cliente: %s\n" +
                        "Telefone: %s\n" +
                        "Modelo: %s (%s)\n\n" +
                        "Entrada: %s\n" +
                        "Tempo no Pátio: %s\n" +
                        "Valor Atual: R$ %.2f\n\n" +
                        "Deseja registrar a saída deste veículo?",
                veiculo.placa(),
                veiculo.nomeCliente() != null ? veiculo.nomeCliente() : "Não informado",
                veiculo.telefoneCliente() != null ? veiculo.telefoneCliente() : "Não informado",
                veiculo.modelo() != null ? veiculo.modelo() : "Não informado",
                veiculo.cor() != null ? veiculo.cor() : "N/A",
                veiculo.horarioEntrada().format(formatter),
                veiculo.tempoEstacionado(),
                veiculo.valorAtual()
        );

        boolean confirm = DialogoCustomizado.mostrarConfirmacao(
                owner,
                "Registrar Saída do Veículo",
                mensagem
        );

        if (confirm) {
            confirmarRegistroSaida(veiculo.placa());
        }
    }


    /**
     * Executa o registro de saída de um veículo de forma assíncrona.
     * <p>
     * Utiliza um {@link SwingWorker} para chamar
     * {@code ApiClient.registrarSaida(placa)} em background.
     * Em caso de sucesso, exibe uma mensagem e chama
     * {@link #carregarStatusPatio()} para atualizar a tela.
     *
     * @param placa A placa do veículo a ser retirado do pátio.
     */
    private void confirmarRegistroSaida(String placa) {
        Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);

        SwingWorker<Void, Void> finalWorker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws ApiException {
                ApiClient.registrarSaida(placa);
                return null;
            }

            @Override
            protected void done() {
                try {
                    get();
                    DialogoCustomizado.mostrarMensagemSucesso(
                            owner,
                            "Sucesso",
                            "Saída do veículo " + placa + " registrada com sucesso!"
                    );
                    carregarStatusPatio();
                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() : "Ocorreu um erro inesperado.";
                    DialogoCustomizado.mostrarMensagemErro(owner, "Erro", "Erro ao confirmar a saída:\n" + errorMessage);
                }
            }
        };
        finalWorker.execute();
    }

    /**
     * Formata um objeto LocalDateTime para uma string legível (dd/MM/yy HH:mm).
     *
     * @param data O LocalDateTime a ser formatado.
     * @return A data formatada como String, ou "N/A" se a data for nula.
     */
    private String formatarData(LocalDateTime data) {
        if (data == null) return "N/A";
        return data.format(DateTimeFormatter.ofPattern("dd/MM/yy HH:mm"));
    }

    /**
     * Carrega um ImageIcon a partir de um caminho de arquivo, com redimensionamento.
     *
     * @param path   O caminho (relativo ou absoluto) para o arquivo de imagem.
     * @param width  A largura desejada para a imagem.
     * @param height A altura desejada para a imagem.
     * @return O ImageIcon redimensionado, ou um ícone em branco se
     * o arquivo não for encontrado.
     */
    private ImageIcon loadIcon(String path, int width, int height) {
        File file = new File(path);
        if (!file.exists()) {
            System.err.println("Imagem não encontrada: " + path);
            return new ImageIcon(new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB));
        }
        ImageIcon icon = new ImageIcon(path);
        if (width > 0 && height > 0) {
            Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
            icon = new ImageIcon(img);
        }
        return icon;
    }

    /**
     * Cria o painel central estilizado (com sombra e cantos arredondados)
     * que contém o título e o conteúdo principal (contadores e grid).
     *
     * @return O JPanel central estilizado.
     */
    private JPanel createStyledCentralPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15)) {
            /**
             * Sobrescrito para desenhar uma sombra e cantos arredondados.
             *
             * @param g O contexto gráfico.
             */
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(COLOR_SHADOW);
                g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 20, 20);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
            }
        };
        panel.setBackground(COLOR_PANEL);
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(25, 25, 25, 25));

        panel.add(createTitlePanel(), BorderLayout.NORTH);
        panel.add(createMainContentPanel(), BorderLayout.CENTER);

        return panel;
    }

    /**
     * Cria o painel de cabeçalho, que inclui o título, o ícone e os
     * botões de ação (Atualizar, Fechar).
     *
     * @return Um JPanel contendo o cabeçalho completo da tela.
     */
    private JPanel createTitlePanel() {
        JPanel panelTitulo = new JPanel(new BorderLayout());
        panelTitulo.setOpaque(false);

        JLabel lblTitulo = new JLabel("Veículos Atualmente no Pátio");
        lblTitulo.setIcon(loadIcon("src/imagens/gerenciar_icon.png", 28, 28));
        lblTitulo.setIconTextGap(10);

        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        panelTitulo.add(lblTitulo, BorderLayout.WEST);

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        painelBotoes.setOpaque(false);
        JButton btnAtualizar = createIconButton("🔄", "Atualizar Pátio");

        btnAtualizar.addActionListener(e -> carregarStatusPatio());

        painelBotoes.add(btnAtualizar);
        JButton btnFechar = createIconButton("X", "Fechar");
        btnFechar.addActionListener(e -> telaPrincipal.mostrarPainelInicial());
        painelBotoes.add(btnFechar);
        panelTitulo.add(painelBotoes, BorderLayout.EAST);
        return panelTitulo;
    }

    /**
     * Cria o painel de conteúdo principal que agrupa os contadores
     * e o grid de vagas.
     *
     * @return Um JPanel contendo os contadores (Norte) e
     * o grid rolável (Centro).
     */
    private JPanel createMainContentPanel() {
        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setOpaque(false);
        mainPanel.add(createCountersPanel(), BorderLayout.NORTH);
        mainPanel.add(createPatioGridScrollPane(), BorderLayout.CENTER);
        return mainPanel;
    }

    /**
     * Cria o painel de contadores (Total, Ocupadas, Disponíveis).
     * <p>
     * Os {@link JLabel} são inicializados aqui (com "--"), mas são
     * preenchidos pelo método {@link #carregarStatusPatio()}.
     *
     * @return Um JPanel contendo os JLabels dos contadores.
     */
    private JPanel createCountersPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 50, 10));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, COLOR_BACKGROUND.brighter()));

        lblTotalVagas = new JLabel("Total: --");
        lblVagasOcupadas = new JLabel("Ocupadas: --");
        lblVagasDisponiveis = new JLabel("Disponíveis: --");

        Font fontContador = new Font("Segoe UI", Font.BOLD, 18);
        lblTotalVagas.setFont(fontContador);
        lblTotalVagas.setForeground(COLOR_TEXT_PRIMARY);
        lblVagasOcupadas.setFont(fontContador);
        lblVagasOcupadas.setForeground(COLOR_VAGA_OCUPADA);
        lblVagasDisponiveis.setFont(fontContador);
        lblVagasDisponiveis.setForeground(COLOR_VAGA_DISPONIVEL);

        panel.add(lblTotalVagas);
        panel.add(lblVagasOcupadas);
        panel.add(lblVagasDisponiveis);
        return panel;
    }

    /**
     * Cria o {@link JScrollPane} que conterá o grid de vagas.
     * <p>
     * Inicializa o {@code painelGridVagas} com um {@link GridLayout}
     * (6 colunas) e o insere dentro de um JScrollPane estilizado.
     *
     * @return Um JScrollPane configurado para o grid.
     */
    private JScrollPane createPatioGridScrollPane() {
        int numColunas = 6;
        painelGridVagas = new JPanel(new GridLayout(0, numColunas, 20, 20));

        painelGridVagas.setBackground(COLOR_PANEL.darker());
        painelGridVagas.setBorder(new EmptyBorder(20, 20, 20, 20));

        JScrollPane scrollPane = new JScrollPane(painelGridVagas);
        scrollPane.setBorder(BorderFactory.createLineBorder(COLOR_BACKGROUND, 1));
        scrollPane.getViewport().setBackground(COLOR_PANEL.darker());
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        return scrollPane;
    }

    /**
     * Método "fábrica" que cria o painel individual de cada vaga (o "carrinho").
     * <p>
     * Se o {@code veiculo} (DTO) for nulo, cria uma vaga "Livre" (ícone verde).
     * Se o {@code veiculo} não for nulo, cria uma vaga "Ocupada" (ícone vermelho)
     * com a placa e um {@link MouseListener} para chamar
     * {@link #mostrarPopupVeiculo(VeiculoStatusDTO)}.
     *
     * @param veiculo O {@link VeiculoStatusDTO} (se ocupada) ou {@code null} (se livre).
     * @return Um {@link JPanel} estilizado representando uma vaga.
     */
    private JPanel createVagaPanel(VeiculoStatusDTO veiculo) {
        JPanel panel = new JPanel(new BorderLayout(5, 5));

        Dimension vagaSize = new Dimension(130, 90);
        panel.setPreferredSize(vagaSize);
        panel.setMinimumSize(vagaSize);

        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createLineBorder(COLOR_BACKGROUND.brighter()));

        JLabel iconLabel = new JLabel();
        iconLabel.setHorizontalAlignment(SwingConstants.CENTER);
        iconLabel.setOpaque(false);

        if (veiculo != null) {
            // VAGA OCUPADA
            iconLabel.setIcon(loadIcon("src/imagens/car_icon_red.png", 40, 40));
            panel.setCursor(new Cursor(Cursor.HAND_CURSOR));
            panel.setToolTipText("Placa: " + veiculo.placa() + " - Clique para registrar saída");

            JLabel textLabel = new JLabel(veiculo.placa());
            textLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
            textLabel.setForeground(COLOR_VAGA_OCUPADA);
            textLabel.setHorizontalAlignment(SwingConstants.CENTER);

            panel.add(iconLabel, BorderLayout.CENTER);
            panel.add(textLabel, BorderLayout.SOUTH);

            panel.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    mostrarPopupVeiculo(veiculo);
                }
            });
        } else {
            // VAGA DISPONÍVEL
            iconLabel.setIcon(loadIcon("src/imagens/car_icon_green.png", 40, 40));
            panel.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));

            JLabel textLabel = new JLabel(" ");
            textLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
            panel.add(textLabel, BorderLayout.SOUTH);

            panel.add(iconLabel, BorderLayout.CENTER);
        }

        return panel;
    }

    /**
     * Cria um botão de ícone (texto) estilizado, sem borda e com tooltip.
     *
     * @param icon    O texto/ícone (ex: "X", "🔄").
     * @param tooltip O texto a ser exibido no tooltip.
     * @return Um {@link JButton} estilizado como ícone.
     */
    private JButton createIconButton(String icon, String tooltip) {
        JButton button = new JButton(icon);
        button.setFont(new Font("Segoe UI Symbol", Font.BOLD, 16));
        button.setForeground(COLOR_TEXT_PRIMARY);
        button.setToolTipText(tooltip);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setContentAreaFilled(false);
        button.setBorder(null);
        button.setFocusPainted(false);
        return button;
    }
}