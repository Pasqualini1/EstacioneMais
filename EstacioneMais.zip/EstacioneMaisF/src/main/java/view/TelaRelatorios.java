package view;

import dto.VagasDispDTO;
import dto.VeiculoDTO;
import service.ApiClient;
import service.ApiException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

/**
 * Painel (JPanel) que exibe o "Painel de Relatórios e Métricas".
 * <p>
 * Esta tela atua como um dashboard, exibindo métricas em tempo real
 * (Veículos no Pátio, Vagas Disponíveis) em {@link DashboardCard}s.
 * Também fornece um formulário para o usuário selecionar um tipo de
 * relatório (Movimentação ou Financeiro) e um período de datas para
 * gerar relatórios detalhados.
 */
public class TelaRelatorios extends JPanel {

    private static final Color COLOR_BACKGROUND = new Color(34, 40, 49);
    private static final Color COLOR_PANEL = new Color(57, 62, 70);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_ORANGE_ACCENT = new Color(255, 157, 8);
    private static final Color COLOR_INPUT_BG = new Color(45, 45, 45);
    private static final Color COLOR_SHADOW = new Color(0, 0, 0, 80);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 16);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 14);

    private final TelaPrincipal telaPrincipal;
    private JLabel lblValorCarrosNoPatio;
    private JLabel lblValorVagasDisponiveis;
    private JSpinner spinnerDataInicio;
    private JSpinner spinnerDataFim;
    private JComboBox<String> comboTipoRelatorio;

    /**
     * Constrói a tela de Relatórios.
     * <p>
     * Inicializa a UI, define o layout e chama
     * {@link #carregarDadosDashboard()} para buscar as métricas ao vivo.
     *
     * @param telaPrincipal A referência à janela principal (JFrame) da aplicação.
     */
    public TelaRelatorios(TelaPrincipal telaPrincipal) {
        this.telaPrincipal = telaPrincipal;
        setLayout(new GridBagLayout());
        setBackground(COLOR_BACKGROUND);
        add(createStyledCentralPanel(), new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0,
                GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(30, 30, 30, 30), 0, 0));
        carregarDadosDashboard();
    }

    /**
     * Identifica o tipo de relatório selecionado no JComboBox e
     * chama o método {@link #gerarRelatorio(boolean)} correspondente.
     */
    private void gerarRelatorioSelecionado() {
        String tipoSelecionado = (String) comboTipoRelatorio.getSelectedItem();
        if (tipoSelecionado == null) return;

        if (tipoSelecionado.equals("Relatório de Movimentação")) {
            gerarRelatorio(false);
        } else if (tipoSelecionado.equals("Relatório Financeiro")) {
            gerarRelatorio(true);
        }
    }

    /**
     * Coleta as datas, exibe um diálogo de "loading" e inicia um
     * {@link SwingWorker} para buscar os dados do relatório da API.
     * <p>
     * Após a conclusão, se os dados forem recebidos, ele navega para a
     * tela de resultado apropriada (Financeiro ou Movimentação).
     *
     * @param isFinanceiro {@code true} para gerar o relatório financeiro,
     * {@code false} para o de movimentação.
     */
    private void gerarRelatorio(boolean isFinanceiro) {
        Date dataInicioUtil = (Date) spinnerDataInicio.getValue();
        Date dataFimUtil = (Date) spinnerDataFim.getValue();
        LocalDateTime dataInicio = dataInicioUtil.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().atStartOfDay();
        LocalDateTime dataFim = dataFimUtil.toInstant().atZone(ZoneId.systemDefault()).toLocalDate().atTime(23, 59, 59);

        JDialog loadingDialog = createLoadingDialog();

        SwingWorker<List<VeiculoDTO>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<VeiculoDTO> doInBackground() throws ApiException {
                return ApiClient.buscarDadosRelatorio(dataInicio, dataFim);
            }

            @Override
            protected void done() {
                loadingDialog.dispose();
                try {
                    List<VeiculoDTO> dados = get();
                    if (dados != null && !dados.isEmpty()) {
                        if (isFinanceiro) {
                            TelaRelatorioFinanceiro painelResultado = new TelaRelatorioFinanceiro(telaPrincipal, dados, dataInicio, dataFim);
                            telaPrincipal.trocarPainelCentral(painelResultado);
                        } else {
                            TelaResultadoRelatorio painelResultado = new TelaResultadoRelatorio(telaPrincipal, dados, dataInicio, dataFim);
                            telaPrincipal.trocarPainelCentral(painelResultado);
                        }
                    } else {
                        DialogoCustomizado.mostrarMensagemErro((Frame) SwingUtilities.getWindowAncestor(TelaRelatorios.this), "Sem Resultados", "Nenhum dado encontrado para o período selecionado.");
                    }
                } catch (Exception e) {
                    handleApiError(e, "Erro ao gerar relatório");
                }
            }
        };
        worker.execute();
        loadingDialog.setVisible(true);
    }

    /**
     * Carrega os dados do dashboard (métricas ao vivo) de forma assíncrona.
     * <p>
     * Utiliza um {@link SwingWorker} para buscar os veículos ativos e o
     * total de vagas da API. Ao concluir, atualiza os {@link JLabel}s
     * nos {@link DashboardCard}s.
     */
    private void carregarDadosDashboard() {
        if (lblValorCarrosNoPatio == null || lblValorVagasDisponiveis == null) return;
        lblValorCarrosNoPatio.setText("...");
        lblValorVagasDisponiveis.setText("...");

        record DashboardData(int veiculosAtivos, int totalVagas) {}

        SwingWorker<DashboardData, Void> worker = new SwingWorker<>() {
            @Override
            protected DashboardData doInBackground() throws ApiException {
                List<VeiculoDTO> veiculosAtivos = ApiClient.listarVeiculosAtivos();
                VagasDispDTO vagasDTO = ApiClient.getVagas();
                int totalVeiculos = veiculosAtivos != null ? veiculosAtivos.size() : 0;
                int totalVagas = vagasDTO != null ? vagasDTO.totalVagas() : 0;
                return new DashboardData(totalVeiculos, totalVagas);
            }

            @Override
            protected void done() {
                try {
                    DashboardData data = get();
                    int vagasDisponiveis = Math.max(0, data.totalVagas() - data.veiculosAtivos());
                    lblValorCarrosNoPatio.setText(String.valueOf(data.veiculosAtivos()));
                    lblValorVagasDisponiveis.setText(String.valueOf(vagasDisponiveis));
                } catch (Exception e) {
                    handleApiError(e, "Erro ao carregar métricas");
                    lblValorCarrosNoPatio.setFont(new Font("Segoe UI", Font.BOLD, 24));
                    lblValorCarrosNoPatio.setText("Erro!");
                    lblValorVagasDisponiveis.setFont(new Font("Segoe UI", Font.BOLD, 24));
                    lblValorVagasDisponiveis.setText("Erro!");
                }
            }
        };
        worker.execute();
    }

    /**
     * Método auxiliar para tratar exceções da API e exibir um diálogo de erro.
     *
     * @param e     A exceção capturada (geralmente do {@code SwingWorker.done()}).
     * @param title O título para a janela de diálogo de erro.
     */
    private void handleApiError(Exception e, String title) {
        Throwable cause = e.getCause();
        String errorMessage = (cause instanceof ApiException) ? cause.getMessage() : "Ocorreu um erro inesperado.";
        DialogoCustomizado.mostrarMensagemErro((Frame) SwingUtilities.getWindowAncestor(this), title, errorMessage);
    }

    /**
     * Carrega um ImageIcon a partir de um caminho de arquivo, com redimensionamento.
     *
     * @param path   O caminho (relativo ou absoluto) para o arquivo de imagem.
     * @param width  A largura desejada para a imagem.
     * @param height A altura desejada para a imagem.
     * @return O {@link ImageIcon} redimensionado, ou um ícone em branco
     * se o arquivo não for encontrado.
     */
    private ImageIcon loadIcon(String path, int width, int height) {
        File file = new File(path);
        if (!file.exists()) {
            System.err.println("Imagem não encontrada: " + path);
            return new ImageIcon(new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB));
        }
        ImageIcon icon = new ImageIcon(path);
        if (width > 0 && height > 0) {
            Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
            icon = new ImageIcon(img);
        }
        return icon;
    }

    /**
     * Cria o painel central estilizado (com sombra e cantos arredondados)
     * que contém o título e o conteúdo principal.
     *
     * @return O {@link JPanel} central estilizado.
     */
    private JPanel createStyledCentralPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 20)) {
            /**
             * Sobrescrito para desenhar uma sombra e cantos arredondados.
             *
             * @param g O contexto gráfico.
             */
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(COLOR_SHADOW);
                g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 20, 20);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
            }
        };
        panel.setBackground(COLOR_PANEL);
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(25, 25, 25, 25));
        panel.add(createTitlePanel(), BorderLayout.NORTH);
        panel.add(createMainContentPanel(), BorderLayout.CENTER);
        return panel;
    }

    /**
     * Cria o painel de cabeçalho, que inclui o título, o ícone e os
     * botões de ação (Atualizar, Fechar).
     *
     * @return Um {@link JPanel} contendo o cabeçalho completo da tela.
     */
    private JPanel createTitlePanel() {
        JPanel panelTitulo = new JPanel(new BorderLayout());
        panelTitulo.setOpaque(false);

        JLabel lblTitulo = new JLabel("Painel de Relatórios e Métricas");
        lblTitulo.setIcon(loadIcon("src/imagens/analysis.png", 28, 28));
        lblTitulo.setIconTextGap(10);

        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        panelTitulo.add(lblTitulo, BorderLayout.WEST);

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        painelBotoes.setOpaque(false);
        JButton btnAtualizar = createIconButton("🔄", "Atualizar Métricas");
        btnAtualizar.addActionListener(e -> carregarDadosDashboard());
        painelBotoes.add(btnAtualizar);
        JButton btnFechar = createIconButton("X", "Fechar");
        btnFechar.addActionListener(e -> telaPrincipal.mostrarPainelInicial());
        painelBotoes.add(btnFechar);
        panelTitulo.add(painelBotoes, BorderLayout.EAST);
        return panelTitulo;
    }

    /**
     * Cria o painel de conteúdo principal, que é dividido entre o
     * painel de métricas (cards) e o painel gerador de relatórios (formulário).
     *
     * @return Um {@link JPanel} contendo o conteúdo principal.
     */
    private JPanel createMainContentPanel() {
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();

        JPanel topPanel = new JPanel(new BorderLayout(40, 0));
        topPanel.setOpaque(false);
        topPanel.add(createMetricsPanel(), BorderLayout.WEST);
        topPanel.add(createReportGeneratorPanel(), BorderLayout.CENTER);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.NORTH;
        mainPanel.add(topPanel, gbc);

        gbc.gridy = 1;
        gbc.weighty = 1.0;
        mainPanel.add(new JPanel() {{
            setOpaque(false);
        }}, gbc);

        return mainPanel;
    }

    /**
     * Cria o painel de métricas (lado esquerdo) que exibe os
     * {@link DashboardCard}s.
     *
     * @return Um {@link JPanel} contendo os cards de métricas.
     */
    private JPanel createMetricsPanel() {
        JPanel metricsPanel = new JPanel();
        metricsPanel.setOpaque(false);
        metricsPanel.setLayout(new BoxLayout(metricsPanel, BoxLayout.Y_AXIS));
        metricsPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        DashboardCard cardCarrosNoPatio = new DashboardCard("Veículos no Pátio", "...", new Color(33, 150, 243));
        lblValorCarrosNoPatio = cardCarrosNoPatio.getValueLabel();

        metricsPanel.add(cardCarrosNoPatio);
        metricsPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        DashboardCard cardVagasDisponiveis = new DashboardCard("Vagas Disponíveis", "...", new Color(76, 175, 80));
        lblValorVagasDisponiveis = cardVagasDisponiveis.getValueLabel();

        metricsPanel.add(cardVagasDisponiveis);
        return metricsPanel;
    }

    /**
     * Cria o painel gerador de relatórios (lado direito) que
     * contém o formulário de seleção.
     *
     * @return Um {@link JPanel} contendo o formulário de geração de relatório.
     */
    private JPanel createReportGeneratorPanel() {
        JPanel reportPanel = new JPanel(new BorderLayout(15, 15));
        reportPanel.setOpaque(false);
        reportPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel lblTituloRelatorio = new JLabel("Gerar Relatório");
        lblTituloRelatorio.setFont(FONT_LABEL);
        lblTituloRelatorio.setForeground(COLOR_TEXT_PRIMARY);
        lblTituloRelatorio.setBorder(new EmptyBorder(0, 5, 10, 0));
        reportPanel.add(lblTituloRelatorio, BorderLayout.NORTH);

        JPanel fieldsPanel = new JPanel(new GridBagLayout());
        fieldsPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 5, 8, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        fieldsPanel.add(createFormLabel("Tipo:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        String[] tipos = {"Relatório de Movimentação", "Relatório Financeiro"};
        comboTipoRelatorio = new JComboBox<>(tipos);
        styleComboBox(comboTipoRelatorio);
        fieldsPanel.add(comboTipoRelatorio, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;
        fieldsPanel.add(createFormLabel("De:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        spinnerDataInicio = createDatePicker();
        fieldsPanel.add(spinnerDataInicio, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0;
        fieldsPanel.add(createFormLabel("Até:"), gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        spinnerDataFim = createDatePicker();
        fieldsPanel.add(spinnerDataFim, gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.weightx = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = new Insets(20, 5, 5, 5);
        RoundedButton btnGerar = new RoundedButton("Gerar Relatório");
        btnGerar.setBackground(COLOR_ORANGE_ACCENT);
        btnGerar.addActionListener(e -> gerarRelatorioSelecionado());
        fieldsPanel.add(btnGerar, gbc);

        reportPanel.add(fieldsPanel, BorderLayout.CENTER);
        return reportPanel;
    }

    /**
     * Método auxiliar (factory) para criar um {@link JLabel} estilizado
     * para o formulário.
     *
     * @param text O texto do rótulo.
     * @return Um {@link JLabel} estilizado.
     */
    private JLabel createFormLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(COLOR_TEXT_PRIMARY);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        return label;
    }

    /**
     * Aplica o estilo "dark theme" customizado a um {@link JComboBox}.
     *
     * @param comboBox O JComboBox a ser estilizado.
     */
    private void styleComboBox(JComboBox<String> comboBox) {
        comboBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        comboBox.setBackground(COLOR_INPUT_BG);
        comboBox.setForeground(COLOR_TEXT_PRIMARY);
        comboBox.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_PANEL.brighter()), new EmptyBorder(5, 8, 5, 8)
        ));
    }

    /**
     * Método auxiliar (factory) para criar um {@link JSpinner} de data estilizado.
     *
     * @return Um {@link JSpinner} configurado para seleção de data.
     */
    private JSpinner createDatePicker() {
        JSpinner spinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor editor = new JSpinner.DateEditor(spinner, "dd/MM/yyyy");
        spinner.setEditor(editor);
        spinner.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JFormattedTextField textField = editor.getTextField();
        textField.setBackground(COLOR_INPUT_BG);
        textField.setForeground(COLOR_TEXT_PRIMARY);
        textField.setCaretColor(COLOR_ORANGE_ACCENT);
        textField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_PANEL.brighter()), new EmptyBorder(5, 8, 5, 8)
        ));
        textField.setColumns(10);
        return spinner;
    }

    /**
     * Cria um diálogo de "loading" simples e modal.
     *
     * @return O {@link JDialog} de loading (não visível).
     */
    private JDialog createLoadingDialog() {
        JDialog dialog = new JDialog(telaPrincipal, "Aguarde...", true);
        JLabel label = new JLabel("Buscando dados do relatório, por favor aguarde...");
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setBorder(new EmptyBorder(20, 20, 20, 20));
        dialog.add(label);
        dialog.pack();
        dialog.setLocationRelativeTo(telaPrincipal);
        dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        return dialog;
    }

    /**
     * Cria um botão de ícone (texto) estilizado, sem borda e com tooltip.
     *
     * @param icon    O texto/ícone (ex: "X", "🔄").
     * @param tooltip O texto a ser exibido no tooltip.
     * @return Um {@link JButton} estilizado como ícone.
     */
    private JButton createIconButton(String icon, String tooltip) {
        JButton button = new JButton(icon);
        button.setFont(new Font("Segoe UI Symbol", Font.BOLD, 16));
        button.setForeground(COLOR_TEXT_PRIMARY);
        button.setToolTipText(tooltip);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setContentAreaFilled(false);
        button.setBorder(null);
        button.setFocusPainted(false);
        return button;
    }

    /**
     * Classe interna (private static) que representa um "card"
     * customizado do dashboard para exibir uma única métrica.
     */
    private static class DashboardCard extends JPanel {
        private final JLabel valueLabel;

        /**
         * Constrói o card do dashboard.
         *
         * @param title        O título do card (ex: "Veículos no Pátio").
         * @param initialValue O valor inicial a ser exibido (ex: "...").
         * @param accentColor  A cor da barra de destaque no topo do card.
         */
        public DashboardCard(String title, String initialValue, Color accentColor) {
            setLayout(new BorderLayout(0, 5));
            setPreferredSize(new Dimension(220, 120));
            setOpaque(false);
            setBorder(new EmptyBorder(15, 20, 15, 20));

            JLabel titleLabel = new JLabel(title);
            titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
            titleLabel.setForeground(COLOR_TEXT_PRIMARY);
            titleLabel.setHorizontalAlignment(SwingConstants.LEFT);

            valueLabel = new JLabel(initialValue);
            valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 48));
            valueLabel.setForeground(COLOR_TEXT_PRIMARY);
            valueLabel.setHorizontalAlignment(SwingConstants.LEFT);

            JPanel headerPanel = new JPanel(new BorderLayout());
            headerPanel.setOpaque(false);
            JPanel colorBar = new JPanel();
            colorBar.setBackground(accentColor);
            colorBar.setPreferredSize(new Dimension(0, 5));
            headerPanel.add(colorBar, BorderLayout.NORTH);
            headerPanel.add(titleLabel, BorderLayout.CENTER);

            add(headerPanel, BorderLayout.NORTH);
            add(valueLabel, BorderLayout.CENTER);
        }

        /**
         * Sobrescreve o método de pintura para desenhar o fundo arredondado.
         *
         * @param g O contexto gráfico fornecido pelo Swing.
         */
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(COLOR_INPUT_BG);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
            g2.dispose();
        }

        /**
         * Retorna o {@link JLabel} que exibe o valor numérico,
         * permitindo que ele seja atualizado externamente.
         *
         * @return O JLabel do valor.
         */
        public JLabel getValueLabel() {
            return valueLabel;
        }
    }

    /**
     * Classe interna (private) que representa um JButton customizado
     * com cantos arredondados e efeitos de "hover".
     */
    private class RoundedButton extends JButton {
        private Color defaultBg;
        private Color hoverBg;

        /**
         * Construtor do botão arredondado.
         *
         * @param text O texto a ser exibido no botão.
         */
        public RoundedButton(String text) {
            super(text);
            setFont(FONT_BUTTON);
            setForeground(Color.WHITE);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setFocusPainted(false);
            setBorder(new EmptyBorder(10, 20, 10, 20));
            setContentAreaFilled(false);
            this.defaultBg = COLOR_INPUT_BG;
            this.hoverBg = defaultBg.brighter();
            setBackground(defaultBg);
            addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent evt) {
                    if (isEnabled()) setBackground(hoverBg);
                }

                public void mouseExited(MouseEvent evt) {
                    setBackground(defaultBg);
                }
            });
        }

        /**
         * Sobrescrito para atualizar as cores de 'default' e 'hover'
         * quando a cor de fundo é alterada programaticamente.
         *
         * @param bg A nova cor de fundo.
         */
        @Override
        public void setBackground(Color bg) {
            if (bg != hoverBg) {
                this.defaultBg = bg;
                this.hoverBg = bg.brighter();
            }
            super.setBackground(bg);
        }

        /**
         * Sobrescreve o método de pintura para desenhar o fundo arredondado.
         *
         * @param g O contexto gráfico fornecido pelo Swing.
         */
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            if (getModel().isPressed()) {
                g2.setColor(getBackground().darker());
            }
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
            super.paintComponent(g2);
            g2.dispose();
        }
    }
}