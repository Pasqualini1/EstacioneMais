package view;

import dto.VeiculoDTO;
import service.ApiClient;
import service.ApiException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.time.format.DateTimeFormatter;

/**
 * Painel que exibe os detalhes completos de um único registro de estacionamento.
 * <p>
 * É tipicamente exibido dentro de uma janela de diálogo (JDialog).
 * Oferece a funcionalidade de "reativar" um veículo (se ele estiver
 * finalizado), criando uma nova entrada para ele.
 */
public class TelaDetalharVeiculo extends JPanel {

    private static final Color COLOR_BG_PANEL = new Color(57, 62, 70);
    private static final Color COLOR_TEXT = new Color(240, 240, 240);
    private static final Color COLOR_ACCENT = new Color(0, 173, 181);
    private static final Color COLOR_INATIVO = new Color(220, 53, 69);
    private static final Color COLOR_SHADOW = new Color(0, 0, 0, 80);
    private static final Color COLOR_BUTTON_REATIVAR = new Color(25, 135, 84);

    /**
     * Constrói o painel de detalhes.
     * <p>
     * Ele formata e exibe todas as informações do VeiculoDTO e configura as ações
     * dos botões, como o de reativar (se aplicável) e o de fechar.
     *
     * @param veiculo       O objeto DTO com os dados do veículo a serem exibidos.
     * @param telaPrincipal A referência à janela principal da aplicação.
     * @param parentDialog  A referência ao JDialog que contém este painel,
     * para poder fechá-lo.
     */
    public TelaDetalharVeiculo(VeiculoDTO veiculo, TelaPrincipal telaPrincipal, JDialog parentDialog) {
        setOpaque(false);
        setLayout(new GridBagLayout());

        JPanel centralPanel = new JPanel(new BorderLayout(10, 10)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(COLOR_SHADOW);
                g2.fillRoundRect(4, 4, getWidth() - 8, getHeight() - 8, 20, 20);
                g2.setColor(COLOR_BG_PANEL);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        centralPanel.setOpaque(false);
        centralPanel.setBorder(new EmptyBorder(20, 25, 25, 25));
        centralPanel.setPreferredSize(new Dimension(420, 400));

        JLabel titulo = new JLabel("Ficha do Veículo");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titulo.setForeground(COLOR_TEXT);
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        titulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        centralPanel.add(titulo, BorderLayout.NORTH);

        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setOpaque(false);

        boolean ativo = (veiculo.horarioSaida() == null);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        String entradaFormatada = (veiculo.horarioEntrada() != null) ?
                veiculo.horarioEntrada().format(formatter) : "N/A";
        String saidaFormatada = (veiculo.horarioSaida() != null) ?
                veiculo.horarioSaida().format(formatter) : "—";

        String clienteInfo = veiculo.nomeCliente();
        if (veiculo.telefoneCliente() != null && !veiculo.telefoneCliente().isBlank()) {
            clienteInfo += " (" + veiculo.telefoneCliente() + ")";
        }

        infoPanel.add(createInfoPanel("Placa", veiculo.placa()));
        infoPanel.add(Box.createVerticalStrut(8));
        infoPanel.add(createInfoPanel("Cliente", clienteInfo));
        infoPanel.add(Box.createVerticalStrut(8));
        infoPanel.add(createInfoPanel("Modelo", veiculo.modelo()));
        infoPanel.add(Box.createVerticalStrut(8));
        infoPanel.add(createInfoPanel("Cor", veiculo.cor()));
        infoPanel.add(Box.createVerticalStrut(8));
        infoPanel.add(createInfoPanel("Ano", (veiculo.ano() != null) ? String.valueOf(veiculo.ano()) : "N/A"));
        infoPanel.add(Box.createVerticalStrut(8));
        infoPanel.add(createInfoPanel("Entrou em", entradaFormatada));
        infoPanel.add(Box.createVerticalStrut(8));
        infoPanel.add(createInfoPanel("Saiu em", saidaFormatada));
        infoPanel.add(Box.createVerticalStrut(15));

        JLabel lblStatus = new JLabel(ativo ? "● ATIVO NO PÁTIO" : "● FINALIZADO");
        lblStatus.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblStatus.setForeground(ativo ? COLOR_ACCENT : COLOR_INATIVO);
        lblStatus.setAlignmentX(Component.CENTER_ALIGNMENT);
        infoPanel.add(lblStatus);

        centralPanel.add(infoPanel, BorderLayout.CENTER);

        JPanel botoesPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        botoesPanel.setOpaque(false);

        if (!ativo) {
            JButton btnReativar = new JButton("Reativar Veículo");
            styleButton(btnReativar, COLOR_BUTTON_REATIVAR);

            btnReativar.addActionListener(e -> {
                boolean confirm = DialogoCustomizado.mostrarConfirmacao(
                        SwingUtilities.getWindowAncestor(this),
                        "Confirmar Reativação",
                        "Deseja registrar uma NOVA ENTRADA para o veículo " + veiculo.placa() + "?"
                );

                if (confirm) {
                    reativarVeiculo(veiculo, telaPrincipal, parentDialog);
                }
            });
            botoesPanel.add(btnReativar);
        }

        JButton btnFechar = new JButton("Fechar");
        styleButton(btnFechar, new Color(108, 117, 125));
        btnFechar.addActionListener(e -> parentDialog.dispose());
        botoesPanel.add(btnFechar);

        centralPanel.add(botoesPanel, BorderLayout.SOUTH);

        add(centralPanel, new GridBagConstraints());
    }

    /**
     * Executa a lógica para registrar uma nova entrada para um veículo já cadastrado.
     * <p>
     * Utiliza um SwingWorker para fazer a chamada à API de forma assíncrona,
     * garantindo que a interface do usuário não seja bloqueada durante a
     * operação de rede.
     *
     * @param veiculo       O DTO do veículo a ser reativado.
     * @param telaPrincipal A referência à tela principal para navegação.
     * @param parentDialog  O diálogo atual, para ser fechado em caso de sucesso.
     */
    private void reativarVeiculo(VeiculoDTO veiculo,
                                 TelaPrincipal telaPrincipal,
                                 JDialog parentDialog) {
        SwingWorker<Void, Void> worker = new SwingWorker<>() {
            /**
             * Executa em background a chamada à API para registrar a nova entrada.
             *
             * @return null
             * @throws ApiException Se a chamada de API falhar.
             */
            @Override
            protected Void doInBackground() throws ApiException {
                ApiClient.registrarEntradaManual(veiculo.placa(),
                        veiculo.nomeCliente(), veiculo.telefoneCliente());
                return null;
            }

            /**
             * Executado na thread do Swing após a conclusão da chamada à API.
             * Atualiza a UI com o resultado da operação (sucesso ou erro).
             */
            @Override
            protected void done() {
                try {
                    get();
                    DialogoCustomizado.mostrarMensagemSucesso(
                            SwingUtilities.getWindowAncestor(parentDialog),
                            "Sucesso",
                            "Nova entrada para o veículo " + veiculo.placa() + " registrada com sucesso!"
                    );
                    parentDialog.dispose();
                    telaPrincipal.trocarPainelCentral(new TelaGerenciarVeiculos(telaPrincipal));
                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    String errorMessage = (cause instanceof ApiException) ?
                            cause.getMessage() : "Ocorreu um erro inesperado.";

                    DialogoCustomizado.mostrarMensagemErro(
                            SwingUtilities.getWindowAncestor(parentDialog),
                            "Erro",
                            "Erro ao reativar veículo:\n" + errorMessage
                    );
                }
            }
        };
        worker.execute();
    }

    /**
     * Método auxiliar para aplicar o estilo padrão (arredondado, fonte) a um botão.
     *
     * @param button     O JButton a ser estilizado.
     * @param background A cor de fundo principal do botão.
     */
    private void styleButton(JButton button, Color background) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setForeground(Color.WHITE);
        button.setBackground(background);
        button.setOpaque(true);
        button.setFocusPainted(false);
        button.setBorder(new EmptyBorder(8, 20, 8, 20));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    /**
     * Método auxiliar (factory) para criar um painel de "info" (Rótulo/Valor).
     * <p>
     * Cria um painel com um rótulo à esquerda e um valor em negrito à direita.
     *
     * @param label O texto do rótulo (ex: "Placa").
     * @param value O texto do valor (ex: "ABC-1234").
     * @return Um JPanel formatado contendo o rótulo e o valor.
     */
    private JPanel createInfoPanel(String label, String value) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        JLabel lblLabel = new JLabel(label + ":");
        lblLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblLabel.setForeground(new Color(180, 180, 180));
        panel.add(lblLabel, BorderLayout.WEST);

        JLabel lblValue = new JLabel(value != null ? value : "N/A");
        lblValue.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblValue.setForeground(COLOR_TEXT);
        panel.add(lblValue, BorderLayout.EAST);

        return panel;
    }
}