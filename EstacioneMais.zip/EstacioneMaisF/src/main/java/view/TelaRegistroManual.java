package view;

import dto.VeiculoDTO;
import service.ApiClient;
import service.ApiException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.time.Year;
import java.util.List;

/**
 * Painel que contém o formulário para o registro manual da entrada de um veículo.
 * <p>
 * Possui uma funcionalidade de busca automática que preenche os dados do veículo
 * (nome, modelo, etc.) se a placa digitada já for conhecida no sistema,
 * travando os campos para evitar edição desnecessária.
 */
public class TelaRegistroManual extends JPanel {

    private static final Color COLOR_PANEL = new Color(57, 62, 70);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_ORANGE_ACCENT = new Color(255, 157, 8);
    private static final Color COLOR_INPUT_BG = new Color(45, 45, 45);
    private static final Color COLOR_SHADOW = new Color(0, 0, 0, 80);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_LABEL = new Font("Segoe UI", Font.PLAIN, 16);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 14);

    private final TelaPrincipal telaPrincipal;
    private JTextField txtPlaca, txtNomeCliente, txtTelefoneCliente, txtModelo, txtCor, txtAno;
    private RoundedButton btnCadastrar;

    /**
     * Constrói a tela de registro manual. Monta a interface do formulário,
     * incluindo o título, os campos de entrada e os botões de ação.
     *
     * @param telaPrincipal A referência à janela principal (JFrame) da aplicação.
     */
    public TelaRegistroManual(TelaPrincipal telaPrincipal) {
        this.telaPrincipal = telaPrincipal;
        setLayout(new BorderLayout(15, 15));
        setOpaque(false);
        setBorder(new EmptyBorder(25, 30, 25, 30));
        add(createTitlePanel(), BorderLayout.NORTH);
        add(createFormPanel(), BorderLayout.CENTER);
        add(createButtonsPanel(), BorderLayout.SOUTH);
    }

    /**
     * Sobrescreve o método de pintura para desenhar um fundo customizado
     * com cantos arredondados e efeito de sombra.
     *
     * @param g O contexto gráfico fornecido pelo Swing.
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(COLOR_SHADOW);
        g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 20, 20);
        g2.setColor(COLOR_PANEL);
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
        g2.dispose();
    }

    /**
     * Lógica executada ao clicar no botão "Registrar Entrada".
     * <p>
     * Primeiro, valida todos os campos do formulário (placa, telefone, ano).
     * Se estiverem corretos, chama a API de forma assíncrona
     * (via {@link SwingWorker}) para registrar a entrada do veículo.
     * Exibe feedback visual (mudança de texto do botão) e
     * mensagens de sucesso ou erro.
     */
    private void onRegistrarEntrada() {
        String placa = txtPlaca.getText().trim().toUpperCase();
        String nomeCliente = txtNomeCliente.getText().trim();
        String telefoneCliente = txtTelefoneCliente.getText().trim();
        String anoStr = txtAno.getText().trim();

        String placaLimpa = placa.replace("-", "");
        if (!placaLimpa.matches("[A-Z]{3}[0-9]{4}") && !placaLimpa.matches(
                "[A-Z]{3}[0-9][A-Z][0-9]{2}")) {
            DialogoCustomizado.mostrarMensagemErro((Frame) SwingUtilities.getWindowAncestor(this),
                    "Erro de Validação", "Formato de placa inválido.\nUse o padrão AAA-1234 ou AAA1B23.");
            return;
        }

        if (!telefoneCliente.isEmpty() && !telefoneCliente.matches("[0-9]+")) {
            DialogoCustomizado.mostrarMensagemErro((Frame) SwingUtilities.getWindowAncestor(this),
                    "Erro de Validação", "O campo 'Telefone' deve conter apenas números.");
            return;
        }

        if (!anoStr.isEmpty()) {
            try {
                int ano = Integer.parseInt(anoStr);
                int anoAtual = Year.now().getValue();
                if (ano < 1950 || ano > anoAtual + 1) {
                    DialogoCustomizado.mostrarMensagemErro((Frame) SwingUtilities.getWindowAncestor(this),
                            "Erro de Validação", "Por favor, insira um ano de fabricação válido.");
                    return;
                }
            } catch (NumberFormatException ex) {
                DialogoCustomizado.mostrarMensagemErro((Frame) SwingUtilities.getWindowAncestor(this),
                        "Erro de Validação", "O campo 'Ano' deve conter apenas números.");
                return;
            }
        }

        btnCadastrar.setEnabled(false);
        btnCadastrar.setText("Registrando...");

        SwingWorker<Void, Void> worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws ApiException {
                ApiClient.registrarEntradaManual(placaLimpa, nomeCliente, telefoneCliente);
                return null;
            }

            @Override
            protected void done() {
                try {
                    get();
                    DialogoCustomizado.mostrarMensagemSucesso((Frame) SwingUtilities.
                                    getWindowAncestor(TelaRegistroManual.this), "Sucesso",
                            "Entrada registrada com sucesso!");
                    telaPrincipal.trocarPainelCentral(new TelaGerenciarVeiculos(telaPrincipal));
                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() :
                            "Ocorreu um erro inesperado.";

                    DialogoCustomizado.mostrarMensagemErro((Frame) SwingUtilities.getWindowAncestor(
                                    TelaRegistroManual.this), "Erro ao Registrar",
                            "Não foi possível registrar a entrada:\n" + errorMessage);
                } finally {
                    btnCadastrar.setEnabled(true);
                    btnCadastrar.setText("✔ Registrar Entrada");
                }
            }
        };
        worker.execute();
    }

    /**
     * Busca os dados de um veículo na API com base na placa digitada.
     * <p>
     * Esta função é chamada quando o campo de placa perde o foco
     * ({@link FocusListener}), criando um efeito de auto-preenchimento
     * para veículos já conhecidos. Se o veículo é encontrado, preenche
     * o formulário e o trava ({@link #setFieldsEditable(boolean false)}).
     * Se não for encontrado, limpa e libera os campos.
     */
    private void buscarVeiculoPorPlaca() {
        String placa = txtPlaca.getText().trim().toUpperCase();
        if (placa.isEmpty() || placa.length() < 7) return;

        SwingWorker<List<VeiculoDTO>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<VeiculoDTO> doInBackground() throws ApiException {
                return ApiClient.gerarRelatorioPorPlaca(placa);
            }

            @Override
            protected void done() {
                try {
                    List<VeiculoDTO> historico = get();
                    if (historico != null && !historico.isEmpty()) {
                        VeiculoDTO ultimoRegistro = historico.get(0);
                        txtNomeCliente.setText(ultimoRegistro.nomeCliente());
                        txtTelefoneCliente.setText(ultimoRegistro.telefoneCliente());
                        txtModelo.setText(ultimoRegistro.modelo());
                        txtCor.setText(ultimoRegistro.cor());
                        txtAno.setText(ultimoRegistro.ano() != null ? String.valueOf(ultimoRegistro.ano()) : "");
                        setFieldsEditable(false);
                    } else {
                        limparCampos(false);
                        setFieldsEditable(true);
                    }
                } catch (Exception e) {
                    limparCampos(false);
                    setFieldsEditable(true);

                    Throwable cause = e.getCause();
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() :
                            "Ocorreu um erro inesperado.";

                    DialogoCustomizado.mostrarMensagemErro((Frame) SwingUtilities.
                                    getWindowAncestor(TelaRegistroManual.this),
                            "Aviso de Busca", "Não foi possível buscar os dados da placa (" +
                                    errorMessage + ").\n" + "Por favor, preencha os dados manualmente.");
                }
            }
        };
        worker.execute();
    }

    /**
     * Habilita ou desabilita a edição dos campos do formulário (exceto a placa).
     * <p>
     * Também altera a cor de fundo para dar um feedback visual de
     * travado/liberado.
     *
     * @param editable {@code true} para tornar os campos editáveis,
     * {@code false} para travá-los.
     */
    private void setFieldsEditable(boolean editable) {
        txtNomeCliente.setEditable(editable);
        txtTelefoneCliente.setEditable(editable);
        txtModelo.setEditable(editable);
        txtCor.setEditable(editable);
        txtAno.setEditable(editable);
        Color bgColor = editable ? COLOR_INPUT_BG : new Color(35, 35, 35);
        txtNomeCliente.setBackground(bgColor);
        txtTelefoneCliente.setBackground(bgColor);
        txtModelo.setBackground(bgColor);
        txtCor.setBackground(bgColor);
        txtAno.setBackground(bgColor);
    }

    /**
     * Limpa o texto de todos os campos do formulário.
     *
     * @param limparPlaca Se {@code true}, o campo da placa também será limpo.
     * Se {@code false}, a placa é mantida.
     */
    private void limparCampos(boolean limparPlaca) {
        if (limparPlaca) txtPlaca.setText("");
        txtNomeCliente.setText("");
        txtTelefoneCliente.setText("");
        txtModelo.setText("");
        txtCor.setText("");
        txtAno.setText("");
    }

    /**
     * Cria o painel de cabeçalho, que inclui o título e o botão de fechar.
     *
     * @return Um {@link JPanel} contendo o cabeçalho da tela.
     */
    private JPanel createTitlePanel() {
        JPanel panelTitulo = new JPanel(new BorderLayout());
        panelTitulo.setOpaque(false);
        panelTitulo.setBorder(new EmptyBorder(0, 0, 10, 0));
        JLabel lblTitulo = new JLabel("Registrar Entrada Manual");
        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        panelTitulo.add(lblTitulo, BorderLayout.WEST);
        JButton btnFechar = createIconButton("X", "Fechar");
        btnFechar.addActionListener(e -> telaPrincipal.mostrarPainelInicial());
        panelTitulo.add(btnFechar, BorderLayout.EAST);
        return panelTitulo;
    }

    /**
     * Cria o painel central do formulário usando {@link GridBagLayout}.
     * <p>
     * Este método é responsável por instanciar os {@link JTextField}s,
     * atribuí-los às variáveis de classe ({@code txtPlaca}, etc.) e
     * adicionar o {@link FocusListener} de auto-busca ao campo da placa.
     *
     * @return Um {@link JPanel} contendo os rótulos e campos do formulário.
     */
    private JPanel createFormPanel() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.CENTER;
        String[] labels = {"Placa:", "Nome Cliente:", "Nº Telefone:", "Modelo:", "Cor:", "Ano:"};
        JTextField[] fields = new JTextField[labels.length];
        for (int i = 0; i < labels.length; i++) {
            JLabel lbl = new JLabel(labels[i]);
            lbl.setForeground(COLOR_TEXT_PRIMARY);
            lbl.setFont(FONT_LABEL);
            gbc.gridx = 0;
            gbc.gridy = i;
            gbc.weightx = 0.3;
            gbc.insets = new Insets(5, 0, 5, 10);
            gbc.anchor = GridBagConstraints.LINE_END;
            formPanel.add(lbl, gbc);
            fields[i] = new StyledTextField();
            gbc.gridx = 1;
            gbc.weightx = 0.7;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.insets = new Insets(5, 0, 5, 0);
            gbc.anchor = GridBagConstraints.LINE_START;
            formPanel.add(fields[i], gbc);
        }
        txtPlaca = fields[0];
        txtNomeCliente = fields[1];
        txtTelefoneCliente = fields[2];
        txtModelo = fields[3];
        txtCor = fields[4];
        txtAno = fields[5];

        txtPlaca.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                buscarVeiculoPorPlaca();
            }
        });
        return formPanel;
    }

    /**
     * Cria o painel de botões de ação na parte inferior da tela.
     *
     * @return Um {@link JPanel} contendo o botão "Registrar Entrada".
     */
    private JPanel createButtonsPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 10));
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(10, 0, 0, 0));
        btnCadastrar = new RoundedButton("Registrar Entrada");
        btnCadastrar.setBackground(COLOR_ORANGE_ACCENT);
        btnCadastrar.addActionListener(e -> onRegistrarEntrada());
        panel.add(btnCadastrar);
        return panel;
    }

    /**
     * Cria um botão de ícone (texto) estilizado, sem borda e com tooltip.
     *
     * @param icon    O texto/ícone (ex: "X", "🔄").
     * @param tooltip O texto a ser exibido no tooltip.
     * @return Um {@link JButton} estilizado como ícone.
     */
    private JButton createIconButton(String icon, String tooltip) {
        JButton button = new JButton(icon);
        button.setFont(new Font("Segoe UI Symbol", Font.BOLD, 16));
        button.setForeground(COLOR_TEXT_PRIMARY);
        button.setToolTipText(tooltip);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setContentAreaFilled(false);
        button.setBorder(null);
        button.setFocusPainted(false);
        return button;
    }

    /**
     * Classe interna (private) que representa um JTextField com o
     * estilo "dark" padrão da aplicação.
     */
    private class StyledTextField extends JTextField {
        /**
         * Construtor do StyledTextField.
         * Aplica as cores, fontes e bordas do tema.
         */
        public StyledTextField() {
            super(20);
            setBackground(COLOR_INPUT_BG);
            setForeground(COLOR_TEXT_PRIMARY);
            setCaretColor(COLOR_ORANGE_ACCENT);
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(COLOR_PANEL.brighter()), new EmptyBorder(8, 10, 8, 10)
            ));
            setFont(new Font("Segoe UI", Font.PLAIN, 16));
        }
    }

    /**
     * Classe interna (private) que representa um JButton customizado
     * com cantos arredondados e efeitos de "hover".
     */
    private class RoundedButton extends JButton {
        private Color defaultBg;
        private Color hoverBg;

        /**
         * Construtor do botão arredondado.
         * Configura a aparência e adiciona listeners de mouse para o efeito hover.
         *
         * @param text O texto a ser exibido no botão.
         */
        public RoundedButton(String text) {
            super(text);
            setFont(FONT_BUTTON);
            setForeground(Color.WHITE);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setFocusPainted(false);
            setBorder(new EmptyBorder(12, 25, 12, 25));
            setContentAreaFilled(false);
            this.defaultBg = COLOR_INPUT_BG;
            this.hoverBg = defaultBg.brighter();
            setBackground(defaultBg);
            addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    if (isEnabled())
                        setBackground(hoverBg);
                }

                public void mouseExited(java.awt.event.MouseEvent evt) {
                    setBackground(defaultBg);
                }
            });
        }

        /**
         * Sobrescrito para atualizar as cores de 'default' e 'hover'
         * quando a cor de fundo é alterada programaticamente.
         *
         * @param bg A nova cor de fundo.
         */
        @Override
        public void setBackground(Color bg) {
            if (bg != hoverBg) {
                this.defaultBg = bg;
                this.hoverBg = bg.brighter();
            }
            super.setBackground(bg);
        }

        /**
         * Sobrescreve o método de pintura para desenhar o fundo arredondado.
         * Usa Graphics2D para preencher um 'RoundRect' com antialias.
         *
         * @param g O contexto gráfico fornecido pelo Swing.
         */
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            if (getModel().isPressed()) {
                g2.setColor(getBackground().darker());
            }
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
            super.paintComponent(g2);
            g2.dispose();
        }
    }
}