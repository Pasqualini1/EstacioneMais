package view;

import dto.VeiculoDTO;
import service.ApiClient;
import service.ApiException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.time.Year;
import java.util.List;

/**
 * Painel que contém o formulário para o registro manual da entrada de um veículo.
 * Possui uma funcionalidade de busca automática que preenche os dados do veículo
 * se a placa digitada já for conhecida no sistema.
 */
public class TelaRegistroManual extends JPanel {

    // --- Constantes de Estilo ---
    private static final Color COLOR_PANEL = new Color(57, 62, 70);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_ORANGE_ACCENT = new Color(255, 157, 8);
    private static final Color COLOR_INPUT_BG = new Color(45, 45, 45);
    private static final Color COLOR_SHADOW = new Color(0, 0, 0, 80);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_LABEL = new Font("Segoe UI", Font.PLAIN, 16);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 14);

    // --- Componentes ---
    private final TelaPrincipal telaPrincipal;
    private JTextField txtPlaca, txtNomeCliente, txtTelefoneCliente, txtModelo, txtCor, txtAno;
    private RoundedButton btnCadastrar;

    /**
     * Construtor da tela de registro manual. Monta a interface do formulário.
     */
    public TelaRegistroManual(TelaPrincipal telaPrincipal) {
        this.telaPrincipal = telaPrincipal;
        setLayout(new BorderLayout(15, 15));
        setOpaque(false);
        setBorder(new EmptyBorder(25, 30, 25, 30));
        add(createTitlePanel(), BorderLayout.NORTH);
        add(createFormPanel(), BorderLayout.CENTER);
        add(createButtonsPanel(), BorderLayout.SOUTH);
    }

    /**
     * Sobrescreve o método de pintura para desenhar um fundo customizado com sombra.
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(COLOR_SHADOW);
        g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 20, 20);
        g2.setColor(COLOR_PANEL);
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
        g2.dispose();
    }

    /**
     * Lógica executada ao clicar no botão "Registrar Entrada".
     * Primeiro, valida todos os campos do formulário e, se estiverem corretos,
     * chama a API de forma assíncrona para registrar a entrada do veículo.
     */
    private void onRegistrarEntrada() {
        String placa = txtPlaca.getText().trim().toUpperCase();
        String nomeCliente = txtNomeCliente.getText().trim();
        String telefoneCliente = txtTelefoneCliente.getText().trim();
        String anoStr = txtAno.getText().trim();

        // Realiza uma série de validações nos dados de entrada antes de prosseguir.
        String placaLimpa = placa.replace("-", "");
        if (!placaLimpa.matches("[A-Z]{3}[0-9]{4}") && !placaLimpa.matches(
                "[A-Z]{3}[0-9][A-Z][0-9]{2}")) {
            DialogoCustomizado.mostrarMensagemErro((Frame) SwingUtilities.getWindowAncestor(this), 
                    "Erro de Validação", "Formato de placa inválido.\nUse o padrão AAA-1234 ou AAA1B23.");
            return;
        }

        if (!telefoneCliente.isEmpty() && !telefoneCliente.matches("[0-9]+")) {
            DialogoCustomizado.mostrarMensagemErro((Frame) SwingUtilities.getWindowAncestor(this), 
                    "Erro de Validação", "O campo 'Telefone' deve conter apenas números.");
            return;
        }

        if (!anoStr.isEmpty()) {
            try {
                int ano = Integer.parseInt(anoStr);
                int anoAtual = Year.now().getValue();
                if (ano < 1950 || ano > anoAtual + 1) {
                    DialogoCustomizado.mostrarMensagemErro((Frame) SwingUtilities.getWindowAncestor(this), 
                            "Erro de Validação", "Por favor, insira um ano de fabricação válido.");
                    return;
                }
            } catch (NumberFormatException ex) {
                DialogoCustomizado.mostrarMensagemErro((Frame) SwingUtilities.getWindowAncestor(this), 
                        "Erro de Validação", "O campo 'Ano' deve conter apenas números.");
                return;
            }
        }

        btnCadastrar.setEnabled(false);
        btnCadastrar.setText("Registrando...");

        SwingWorker<Void, Void> worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws ApiException {
                ApiClient.registrarEntradaManual(placaLimpa, nomeCliente, telefoneCliente);
                return null;
            }
            @Override
            protected void done() {
                try {
                    get();
                    DialogoCustomizado.mostrarMensagemSucesso((Frame) SwingUtilities.
                            getWindowAncestor(TelaRegistroManual.this), "Sucesso", "Entrada registrada com sucesso!");
                    telaPrincipal.trocarPainelCentral(new TelaGerenciarVeiculos(telaPrincipal));
                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() : 
                            "Ocorreu um erro inesperado.";
                    
                    DialogoCustomizado.mostrarMensagemErro((Frame) SwingUtilities.getWindowAncestor(
                            TelaRegistroManual.this), "Erro ao Registrar", 
                            "Não foi possível registrar a entrada:\n" + errorMessage);
                } finally {
                    btnCadastrar.setEnabled(true);
                    btnCadastrar.setText("✔ Registrar Entrada");
                }
            }
        };
        worker.execute();
    }

    /**
     * Busca os dados de um veículo na API com base na placa digitada.
     * Esta função é chamada quando o campo de placa perde o foco, criando
     * um efeito de auto-preenchimento para veículos já conhecidos.
     */
    private void buscarVeiculoPorPlaca() {
        String placa = txtPlaca.getText().trim().toUpperCase();
        if (placa.isEmpty() || placa.length() < 7) return;

        SwingWorker<List<VeiculoDTO>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<VeiculoDTO> doInBackground() throws ApiException {
                return ApiClient.gerarRelatorioPorPlaca(placa);
            }

            @Override
            protected void done() {
                try {
                    List<VeiculoDTO> historico = get();
                    if (historico != null && !historico.isEmpty()) {
                        // Se encontrou, pega o registro mais recente e preenche o formulário.
                        VeiculoDTO ultimoRegistro = historico.get(0);
                        txtNomeCliente.setText(ultimoRegistro.nomeCliente());
                        txtTelefoneCliente.setText(ultimoRegistro.telefoneCliente());
                        txtModelo.setText(ultimoRegistro.modelo());
                        txtCor.setText(ultimoRegistro.cor());
                        txtAno.setText(ultimoRegistro.ano() != null ? String.valueOf(ultimoRegistro.ano()) : "");
                        setFieldsEditable(false); // Trava os campos para evitar edição
                    } else {
                        // Se não encontrou, limpa e libera os campos para um novo cadastro.
                        limparCampos(false);
                        setFieldsEditable(true);
                    }
                } catch (Exception e) {
                    // Se a busca falhar, libera os campos para preenchimento manual.
                    limparCampos(false);
                    setFieldsEditable(true);
                    
                    Throwable cause = e.getCause();
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() : 
                            "Ocorreu um erro inesperado.";

                    DialogoCustomizado.mostrarMensagemErro((Frame) SwingUtilities.
                            getWindowAncestor(TelaRegistroManual.this), 
                            "Aviso de Busca", "Não foi possível buscar os dados da placa (" + 
                                    errorMessage + ").\n" + "Por favor, preencha os dados manualmente.");
                }
            }
        };
        worker.execute();
    }
    
    /**
     * Habilita ou desabilita a edição dos campos do formulário (exceto a placa).
     * Também altera a cor de fundo para dar um feedback visual de travado/liberado.
     */
    private void setFieldsEditable(boolean editable) {
        txtNomeCliente.setEditable(editable);
        txtTelefoneCliente.setEditable(editable);
        txtModelo.setEditable(editable);
        txtCor.setEditable(editable);
        txtAno.setEditable(editable);
        Color bgColor = editable ? COLOR_INPUT_BG : new Color(35, 35, 35);
        txtNomeCliente.setBackground(bgColor);
        txtTelefoneCliente.setBackground(bgColor);
        txtModelo.setBackground(bgColor);
        txtCor.setBackground(bgColor);
        txtAno.setBackground(bgColor);
    }

    /**
     * Limpa o texto de todos os campos do formulário.
     * @param limparPlaca Se true, o campo da placa também será limpo.
     */
    private void limparCampos(boolean limparPlaca) {
        if (limparPlaca) txtPlaca.setText("");
        txtNomeCliente.setText("");
        txtTelefoneCliente.setText("");
        txtModelo.setText("");
        txtCor.setText("");
        txtAno.setText("");
    }

    private JPanel createTitlePanel() {
        JPanel panelTitulo = new JPanel(new BorderLayout());
        panelTitulo.setOpaque(false);
        panelTitulo.setBorder(new EmptyBorder(0, 0, 10, 0));
        JLabel lblTitulo = new JLabel("📝 Registrar Entrada Manual");
        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        panelTitulo.add(lblTitulo, BorderLayout.WEST);
        JButton btnFechar = createIconButton("X", "Fechar");
        btnFechar.addActionListener(e -> telaPrincipal.mostrarPainelInicial());
        panelTitulo.add(btnFechar, BorderLayout.EAST);
        return panelTitulo;
    }

    private JPanel createFormPanel() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.CENTER;
        String[] labels = {"Placa:", "Nome Cliente:", "Nº Telefone:", "Modelo:", "Cor:", "Ano:"};
        JTextField[] fields = new JTextField[labels.length];
        for (int i = 0; i < labels.length; i++) {
            JLabel lbl = new JLabel(labels[i]);
            lbl.setForeground(COLOR_TEXT_PRIMARY);
            lbl.setFont(FONT_LABEL);
            gbc.gridx = 0; gbc.gridy = i; gbc.weightx = 0.3;
            gbc.insets = new Insets(5, 0, 5, 10);
            gbc.anchor = GridBagConstraints.LINE_END;
            formPanel.add(lbl, gbc);
            fields[i] = new StyledTextField();
            gbc.gridx = 1; gbc.weightx = 0.7;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.insets = new Insets(5, 0, 5, 0);
            gbc.anchor = GridBagConstraints.LINE_START;
            formPanel.add(fields[i], gbc);
        }
        txtPlaca = fields[0];
        txtNomeCliente = fields[1];
        txtTelefoneCliente = fields[2];
        txtModelo = fields[3];
        txtCor = fields[4];
        txtAno = fields[5];
        // Adiciona o listener que dispara a busca automática ao sair do campo da placa.
        txtPlaca.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                buscarVeiculoPorPlaca();
            }
        });
        return formPanel;
    }

    private JPanel createButtonsPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 10));
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(10, 0, 0, 0));
        btnCadastrar = new RoundedButton("✔ Registrar Entrada");
        btnCadastrar.setBackground(COLOR_ORANGE_ACCENT);
        btnCadastrar.addActionListener(e -> onRegistrarEntrada());
        panel.add(btnCadastrar);
        return panel;
    }

    private JButton createIconButton(String icon, String tooltip) {
        JButton button = new JButton(icon);
        button.setFont(new Font("Segoe UI Symbol", Font.BOLD, 16));
        button.setForeground(COLOR_TEXT_PRIMARY);
        button.setToolTipText(tooltip);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setContentAreaFilled(false);
        button.setBorder(null);
        button.setFocusPainted(false);
        return button;
    }

    private class StyledTextField extends JTextField {
        public StyledTextField() {
            super(20);
            setBackground(COLOR_INPUT_BG);
            setForeground(COLOR_TEXT_PRIMARY);
            setCaretColor(COLOR_ORANGE_ACCENT);
            setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_PANEL.brighter()), new EmptyBorder(8, 10, 8, 10)
            ));
            setFont(new Font("Segoe UI", Font.PLAIN, 16));
        }
    }

    private class RoundedButton extends JButton {
        private Color defaultBg;
        private Color hoverBg;
        public RoundedButton(String text) {
            super(text);
            setFont(FONT_BUTTON);
            setForeground(Color.WHITE);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setFocusPainted(false);
            setBorder(new EmptyBorder(12, 25, 12, 25));
            setContentAreaFilled(false);
            this.defaultBg = COLOR_INPUT_BG;
            this.hoverBg = defaultBg.brighter();
            setBackground(defaultBg);
            addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) { if (isEnabled()) 
                    setBackground(hoverBg); }
                public void mouseExited(java.awt.event.MouseEvent evt) { 
                    setBackground(defaultBg); }
            });
        }
        @Override
        public void setBackground(Color bg) {
            if (bg != hoverBg) {
                this.defaultBg = bg;
                this.hoverBg = bg.brighter();
            }
            super.setBackground(bg);
        }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            if (getModel().isPressed()) { g2.setColor(getBackground().darker()); }
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
            super.paintComponent(g2);
            g2.dispose();
        }
    }
}