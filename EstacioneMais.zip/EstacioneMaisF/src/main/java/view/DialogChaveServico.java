package view;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import service.ApiClient;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

/**
 * Janela de diálogo (JDialog) para que o usuário possa configurar a chave (token)
 * de serviço da API de reconhecimento de placas (Plate Recognizer).
 */
public class DialogChaveServico extends JDialog {

    private static final Logger logger = LoggerFactory.getLogger(DialogChaveServico.class);

    private static final Color COLOR_CARD_BG = new Color(45, 45, 45);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_TEXT_SECONDARY = new Color(150, 150, 150);
    private static final Color COLOR_ORANGE_ACCENT = new Color(255, 157, 8);
    private static final Color COLOR_GRAY_BUTTON = new Color(108, 117, 125);
    private static final Color COLOR_INPUT_BG = new Color(34, 40, 49);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 20);
    private static final Font FONT_LABEL = new Font("Segoe UI", Font.PLAIN, 14);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 14);

    private final JTextField txtChave;
    private final Frame owner;

    /**
     * Constrói a janela de diálogo modal para configurar a chave de serviço.
     *
     * @param owner O 'Frame' (janela principal) que "possui" este diálogo,
     * usado para centralização e modalidade.
     */
    public DialogChaveServico(Frame owner) {
        super(owner, "Configurar Chave de Serviço", true);
        this.owner = owner;

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);

        JPanel mainPanel = new JPanel(new BorderLayout(0, 25));
        mainPanel.setBackground(COLOR_CARD_BG);
        mainPanel.setBorder(new EmptyBorder(25, 30, 25, 30));

        JPanel titlePanel = new JPanel();
        titlePanel.setOpaque(false);
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));

        JLabel lblTitulo = new JLabel("Chave do Serviço de Reconhecimento");
        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        lblTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblSubtitulo = new JLabel("Insira sua Chave de Serviço (API Key) do Plate Recognizer.");
        lblSubtitulo.setFont(FONT_LABEL);
        lblSubtitulo.setForeground(COLOR_TEXT_SECONDARY);
        lblSubtitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

        titlePanel.add(lblTitulo);
        titlePanel.add(Box.createRigidArea(new Dimension(0, 5)));
        titlePanel.add(lblSubtitulo);
        mainPanel.add(titlePanel, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel();
        inputPanel.setOpaque(false);
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.Y_AXIS));

        txtChave = new JTextField(30);
        styleTextField(txtChave);
        inputPanel.add(txtChave);

        mainPanel.add(inputPanel, BorderLayout.CENTER);

        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonsPanel.setOpaque(false);

        RoundedDialogButton btnCancelar = new RoundedDialogButton("Cancelar", COLOR_GRAY_BUTTON);
        btnCancelar.addActionListener(e -> dispose());

        RoundedDialogButton btnSalvar = new RoundedDialogButton("Salvar", COLOR_ORANGE_ACCENT);
        btnSalvar.addActionListener(e -> salvarConfiguracoes());

        buttonsPanel.add(btnCancelar);
        buttonsPanel.add(btnSalvar);
        mainPanel.add(buttonsPanel, BorderLayout.SOUTH);

        getContentPane().setBackground(COLOR_CARD_BG);
        add(mainPanel);

        pack();
        setLocationRelativeTo(owner);

        carregarConfiguracoes();
    }

    /**
     * Carrega as configurações existentes.
     * Busca o token salvo (via ApiClient) e o exibe no campo de texto.
     */
    private void carregarConfiguracoes() {
        txtChave.setText(ApiClient.getToken());
    }

    /**
     * Salva a nova chave de serviço.
     * Pega o texto do campo, salva-o (via ApiClient) e, em caso de
     * sucesso, exibe uma mensagem e fecha o diálogo. Em caso de
     * falha, exibe uma mensagem de erro.
     */
    private void salvarConfiguracoes() {
        try {
            ApiClient.saveToken(txtChave.getText().trim());
            DialogoCustomizado.mostrarMensagemSucesso(this.owner, "Sucesso", "Chave de Serviço salva com sucesso!");
            dispose();
        } catch (IOException e) {
            logger.error("Erro ao salvar a Chave de Serviço", e);
            DialogoCustomizado.mostrarMensagemErro(this.owner, "Erro", "Não foi possível salvar a chave no arquivo de configurações.");
        }
    }

    /**
     * Aplica o estilo "dark theme" customizado a um campo de texto (JTextField).
     * Define cores de fundo, texto, borda, fonte e cursor.
     *
     * @param field O JTextField a ser estilizado.
     */
    private void styleTextField(JTextField field) {
        field.setFont(FONT_LABEL);
        field.setBackground(COLOR_INPUT_BG);
        field.setForeground(COLOR_TEXT_PRIMARY);
        field.setCaretColor(COLOR_ORANGE_ACCENT);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(80, 80, 80)),
                new EmptyBorder(10, 10, 10, 10)
        ));
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, field.getPreferredSize().height));
        field.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    /**
     * Classe interna (private static) que representa um JButton customizado
     * com cantos arredondados e efeitos de "hover".
     */
    private static class RoundedDialogButton extends JButton {

        private final Color baseBg;
        private final Color hoverBg;

        /**
         * Construtor do botão arredondado.
         * Configura a aparência e adiciona listeners de mouse para o efeito hover.
         *
         * @param text    O texto a ser exibido no botão.
         * @param bgColor A cor de fundo base do botão.
         */
        public RoundedDialogButton(String text, Color bgColor) {
            super(text);
            this.baseBg = bgColor;
            this.hoverBg = bgColor.brighter();
            setFont(FONT_BUTTON);
            setForeground(Color.WHITE);
            setBackground(baseBg);
            setFocusPainted(false);
            setBorder(new EmptyBorder(10, 20, 10, 20));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setContentAreaFilled(false);

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    setBackground(hoverBg);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    setBackground(baseBg);
                }
            });
        }

        /**
         * Sobrescreve o método de pintura para desenhar o fundo arredondado.
         * Usa Graphics2D para preencher um 'RoundRect' com antialias.
         *
         * @param g O contexto gráfico fornecido pelo Swing.
         */
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
            super.paintComponent(g2);
            g2.dispose();
        }
    }
}