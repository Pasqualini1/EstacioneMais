package view;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import service.ApiClient;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

/**
 * Janela de diálogo (modal) para que o usuário possa configurar a chave (token)
 * de serviço da API de reconhecimento de placas (Plate Recognizer).
 */
public class DialogChaveServico extends JDialog {

    private static final Logger logger = LoggerFactory.getLogger(DialogChaveServico.class);
    
    // --- Definições de Estilo ---
    private static final Color COLOR_PRIMARY_BG = new Color(23, 23, 23);
    private static final Color COLOR_CARD_BG = new Color(32, 32, 32);
    private static final Color COLOR_TEXT_PRIMARY = new Color(240, 240, 240);
    private static final Color COLOR_ORANGE_ACCENT = new Color(255, 157, 8);
    private static final Color COLOR_GRAY_BUTTON = new Color(108, 117, 125);
    private static final Color COLOR_INPUT_BG = new Color(45, 45, 45);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 18);
    private static final Font FONT_LABEL = new Font("Segoe UI", Font.PLAIN, 14);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 13);

    private final JTextField txtChave;

    /**
     * Construtor que inicializa e monta todos os componentes visuais da janela,
     * define os listeners de eventos para os botões e carrega a configuração inicial.
     *
     * @param owner O Frame "pai" desta janela de diálogo.
     */
    public DialogChaveServico(Frame owner) {
        super(owner, "Configurar Chave de Serviço", true); 
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        
        setUndecorated(false);
        getContentPane().setBackground(COLOR_PRIMARY_BG);
        getRootPane().setBorder(BorderFactory.createLineBorder(COLOR_ORANGE_ACCENT.darker(), 2));

        JPanel mainPanel = new JPanel(new BorderLayout(20, 20));
        mainPanel.setBackground(COLOR_CARD_BG);
        mainPanel.setBorder(new EmptyBorder(25, 30, 25, 30));

        JLabel lblTitulo = new JLabel("Chave do Serviço de Reconhecimento");
        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        mainPanel.add(lblTitulo, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel(new BorderLayout(0, 8));
        inputPanel.setOpaque(false);

        JLabel lblChave = new JLabel("Insira aqui a sua Chave de Serviço (do Plate Recognizer):");
        lblChave.setFont(FONT_LABEL);
        lblChave.setForeground(COLOR_TEXT_PRIMARY);
        inputPanel.add(lblChave, BorderLayout.NORTH);

        txtChave = new JTextField(30);
        txtChave.setFont(FONT_LABEL);
        txtChave.setBackground(COLOR_INPUT_BG);
        txtChave.setForeground(COLOR_TEXT_PRIMARY);
        txtChave.setCaretColor(COLOR_ORANGE_ACCENT);
        txtChave.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_INPUT_BG.darker(), 1),
            new EmptyBorder(8, 8, 8, 8)
        ));
        inputPanel.add(txtChave, BorderLayout.CENTER);

        mainPanel.add(inputPanel, BorderLayout.CENTER);

        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonsPanel.setOpaque(false);

        RoundedDialogButton btnCancelar = new RoundedDialogButton("Cancelar", COLOR_GRAY_BUTTON);
        btnCancelar.addActionListener(e -> dispose());

        RoundedDialogButton btnSalvar = new RoundedDialogButton("Salvar", COLOR_ORANGE_ACCENT);
        btnSalvar.addActionListener(e -> salvarConfiguracoes());

        buttonsPanel.add(btnCancelar);
        buttonsPanel.add(btnSalvar);
        mainPanel.add(buttonsPanel, BorderLayout.SOUTH);

        add(mainPanel);
        
        pack(); 
        setLocationRelativeTo(owner); 
        
        carregarConfiguracoes();
    }
    
    /**
     * Carrega a chave de serviço (token) atualmente salva no sistema
     * e a exibe no campo de texto da janela.
     */
    private void carregarConfiguracoes() {
        txtChave.setText(ApiClient.getToken());
    }
    
    /**
     * Pega o valor do campo de texto, salva a nova chave de serviço através do ApiClient,
     * exibe uma mensagem de sucesso ou erro, e fecha a janela.
     */
    private void salvarConfiguracoes() {
        try {
            ApiClient.saveToken(txtChave.getText().trim());
            JOptionPane.showMessageDialog(this, "Chave de Serviço salva com sucesso!", "Sucesso", 
                    JOptionPane.INFORMATION_MESSAGE);
            dispose(); 
        } catch (IOException e) {
            logger.error("Erro ao salvar a Chave de Serviço", e);
            JOptionPane.showMessageDialog(this, "Erro ao salvar a chave no arquivo de configurações.", 
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Classe interna que representa um botão customizado com cantos arredondados
     * e um efeito visual de "hover" (mudança de cor ao passar o mouse).
     */
    private static class RoundedDialogButton extends JButton {
        private final Color baseBg;
        private final Color baseFg = Color.WHITE;
        private final Color hoverBg;

        /**
         * Construtor que define a aparência do botão e adiciona os listeners de mouse
         * para controlar o efeito de hover.
         *
         * @param text O texto a ser exibido no botão.
         * @param bgColor A cor de fundo base do botão.
         */
        public RoundedDialogButton(String text, Color bgColor) {
            super(text);
            this.baseBg = bgColor;
            this.hoverBg = bgColor.brighter();

            setFont(FONT_BUTTON);
            setForeground(baseFg);
            setBackground(baseBg);
            setFocusPainted(false);
            setBorder(new EmptyBorder(8, 18, 8, 18));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setContentAreaFilled(false);

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    setBackground(hoverBg);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    setBackground(baseBg);
                }
            });
        }

        /**
         * Sobrescreve o método de pintura do componente para desenhar um retângulo
         * com cantos arredondados como fundo do botão, antes de desenhar o texto.
         */
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16);

            super.paintComponent(g2);
            g2.dispose();
        }
    }
}