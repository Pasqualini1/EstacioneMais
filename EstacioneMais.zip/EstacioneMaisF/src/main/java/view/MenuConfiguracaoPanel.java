package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Um painel que serve como um menu de configurações flutuante (popup).
 * Ele contém botões que dão acesso a diferentes janelas de configuração da aplicação.
 */
public class MenuConfiguracaoPanel extends JPanel {

    /**
     * Constrói o painel do menu, inicializando os botões e definindo as ações
     * que eles executam ao serem clicados.
     *
     * @param telaPrincipal A janela principal da aplicação, usada como "pai" para os diálogos.
     * @param parentWindow A janela flutuante (JWindow) que contém este painel, para que possa ser fechada.
     */
    public MenuConfiguracaoPanel(TelaPrincipal telaPrincipal, JWindow parentWindow) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(new Color(32, 32, 32));
        setBorder(BorderFactory.createLineBorder(new Color(50, 50, 50), 1));

        JButton btnToken = new MenuButton("Configurar Token");
        // Lógica do botão de Token: fecha o menu e abre a janela de diálogo para configurar a chave de serviço.
        btnToken.addActionListener(e -> {
            parentWindow.dispose(); 
            DialogChaveServico dialog = new DialogChaveServico(telaPrincipal);
            dialog.setVisible(true);
        });

        JButton btnPrecos = new MenuButton("Configurar Preços");
        // Lógica do botão de Preços: fecha o menu e exibe uma mensagem de funcionalidade a ser implementada.
        btnPrecos.addActionListener(e -> {
            parentWindow.dispose(); 
            JOptionPane.showMessageDialog(telaPrincipal, "Janela de configuração de preços será implementada aqui.");
        });

        add(btnToken);
        add(btnPrecos);
    }

    /**
     * Classe interna que representa um botão com o estilo de um item de menu,
     * com alinhamento à esquerda e efeito de hover.
     */
    private static class MenuButton extends JButton {
        private final Color defaultBg = new Color(32, 32, 32);
        private final Color hoverBg = new Color(50, 50, 50);

        /**
         * Construtor que estiliza o botão e adiciona a lógica para o efeito
         * de hover, que troca a cor de fundo quando o mouse passa sobre ele.
         */
        public MenuButton(String text) {
            super(text);
            setFont(new Font("Segoe UI", Font.BOLD, 14));
            setForeground(new Color(240, 240, 240));
            setBackground(defaultBg);
            setOpaque(true);
            setBorder(new EmptyBorder(10, 15, 10, 60)); 
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setFocusPainted(false);
            setHorizontalAlignment(SwingConstants.LEFT); 
            setContentAreaFilled(false); 

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    setBackground(hoverBg);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    setBackground(defaultBg);
                }
            });
        }
        
        /**
         * Sobrescreve o método de pintura para desenhar manualmente o fundo do botão.
         * Isso é necessário pois a área de conteúdo padrão foi desativada para
         * permitir um controle mais fino sobre a aparência do botão.
         */
        @Override
        protected void paintComponent(Graphics g) {
            g.setColor(getBackground());
            g.fillRect(0, 0, getWidth(), getHeight());
            super.paintComponent(g);
        }
    }
}