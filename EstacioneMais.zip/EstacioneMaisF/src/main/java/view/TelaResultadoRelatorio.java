package view;

import dto.VeiculoDTO;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Painel para exibir os resultados de um relatório gerado.
 * Apresenta os dados em uma tabela e oferece a funcionalidade de gerar e
 * visualizar um relatório formatado em PDF a partir desses mesmos dados.
 */
public class TelaResultadoRelatorio extends JPanel {

    // --- Constantes de Estilo ---
    private static final Color COLOR_BACKGROUND = new Color(34, 40, 49);
    private static final Color COLOR_PANEL = new Color(57, 62, 70);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_ORANGE_ACCENT = new Color(255, 157, 8);
    private static final Color COLOR_INPUT_BG = new Color(45, 45, 45);
    private static final Color COLOR_SHADOW = new Color(0, 0, 0, 80);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 14);

    // --- Componentes e Dados ---
    private final TelaPrincipal telaPrincipal;
    private final List<VeiculoDTO> dados;
    private final LocalDateTime dataInicioFiltro;
    private final LocalDateTime dataFimFiltro;
    private JTable tabela;
    private DefaultTableModel modeloTabela;

    /**
     * Construtor da tela de resultados. Recebe os dados já filtrados e
     * monta a interface para exibi-los.
     *
     * @param telaPrincipal Referência à janela principal.
     * @param dados A lista de VeiculoDTOs que compõem o relatório.
     * @param dataInicio A data de início do filtro do relatório.
     * @param dataFim A data de fim do filtro do relatório.
     */
    public TelaResultadoRelatorio(TelaPrincipal telaPrincipal, 
            List<VeiculoDTO> dados, LocalDateTime dataInicio, LocalDateTime dataFim) {
        this.telaPrincipal = telaPrincipal;
        this.dados = dados;
        this.dataInicioFiltro = dataInicio;
        this.dataFimFiltro = dataFim;

        setLayout(new GridBagLayout());
        setBackground(COLOR_BACKGROUND);
        add(createStyledCentralPanel(), new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0, 
                GridBagConstraints.CENTER, GridBagConstraints.BOTH, 
                new Insets(30, 30, 30, 30), 0, 0));
    }

    /**
     * Gera o conteúdo do relatório em formato PDF na memória.
     * Utiliza a biblioteca Apache PDFBox para desenhar o cabeçalho, a tabela de dados
     * e lidar com a paginação automaticamente.
     *
     * @return Um array de bytes representando o arquivo PDF.
     * @throws IOException Se ocorrer um erro durante a criação do PDF.
     */
    private byte[] gerarPdfBytes(List<VeiculoDTO> dados, 
            LocalDateTime dataInicio, 
            LocalDateTime dataFim) 
            throws IOException {
        try (PDDocument document = new PDDocument(); ByteArrayOutputStream outputStream = 
                new ByteArrayOutputStream()) {
            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);
            PDPageContentStream contentStream = new PDPageContentStream(document, page);

            // Tenta carregar o logo da empresa a partir dos recursos do projeto.
            PDImageXObject logoImage = null;
            try (InputStream in = getClass().getResourceAsStream("/Logo Estacione+ Preta.png")) {
                if (in != null) {
                    logoImage = PDImageXObject.createFromByteArray(document, in.readAllBytes(), "logo");
                }
            } catch (Exception e) {
                System.err.println("Erro ao carregar a imagem da logo: " + e.getMessage());
            }

            float margin = 50;
            float yStart = page.getMediaBox().getHeight() - margin;
            float yPosition = yStart;
            float pageWidth = page.getMediaBox().getWidth();
            
            // Desenha o cabeçalho do relatório (logo, título, período).
            if (logoImage != null) {
                contentStream.drawImage(logoImage, margin, yPosition - 60, 80, 80);
            }
            
            contentStream.beginText();
            contentStream.setFont(PDType1Font.HELVETICA_BOLD, 16);
            contentStream.newLineAtOffset((pageWidth - 300) / 2 + 100, yStart - 5);
            contentStream.showText("Relatório de Movimentação de Veículos");
            contentStream.endText();

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            String textPeriodo = "Período: " + dataInicio.format(formatter) + " até " + dataFim.format(formatter);
            contentStream.beginText();
            contentStream.setFont(PDType1Font.HELVETICA, 12);
            contentStream.newLineAtOffset((pageWidth - 250) / 2 + 100, yStart - 25);
            contentStream.showText(textPeriodo);
            contentStream.endText();

            yPosition = yStart - 80; // Posição inicial da tabela.
            int pageNum = 1;
            
            // Define os cabeçalhos e larguras das colunas da tabela.
            final String[] headers = {"Placa", "Cliente", "Modelo", "Entrada", "Saída"};
            final float[] colWidths = {80, 150, 120, 90, 90};

            drawTableHeader(contentStream, yPosition, margin, colWidths, headers);
            yPosition -= 30;

            // Itera sobre os dados para desenhar as linhas da tabela.
            for (VeiculoDTO veiculo : dados) {
                // Lógica de paginação: se a próxima linha ultrapassar a margem inferior,
                // cria uma nova página e desenha o cabeçalho da tabela novamente.
                if (yPosition < margin + 30) {
                    contentStream.close();
                    drawPageNumber(document, page, pageNum++);
                    page = new PDPage(PDRectangle.A4);
                    document.addPage(page);
                    contentStream = new PDPageContentStream(document, page);
                    yPosition = yStart; // Reinicia a posição Y no topo da nova página
                    drawTableHeader(contentStream, yPosition, margin, colWidths, headers);
                    yPosition -= 30;
                }
                
                DateTimeFormatter dataFormatter = DateTimeFormatter.ofPattern("dd/MM/yy HH:mm");
                String[] rowData = {
                    veiculo.placa(), veiculo.nomeCliente(), veiculo.modelo(),
                    veiculo.horarioEntrada().format(dataFormatter),
                    veiculo.horarioSaida() != null ? veiculo.horarioSaida().format(dataFormatter) : "No pátio"
                };
                drawTableRow(contentStream, yPosition, margin, colWidths, rowData);
                yPosition -= 20; // Move para a próxima linha
            }
            
            drawPageNumber(document, page, pageNum);
            contentStream.close();
            
            document.save(outputStream);
            return outputStream.toByteArray();
        }
    }

    /**
     * Ação do botão "Visualizar em PDF". Gera o PDF de forma assíncrona e
     * navega para a tela de visualização do PDF.
     */
    private void visualizarComoPdf() {
        JDialog loadingDialog = createLoadingDialog("Gerando PDF...");
        SwingWorker<byte[], Void> worker = new SwingWorker<>() {
            @Override
            protected byte[] doInBackground() throws Exception {
                return gerarPdfBytes(dados, dataInicioFiltro, dataFimFiltro);
            }
            @Override
            protected void done() {
                loadingDialog.dispose();
                try {
                    byte[] pdfBytes = get();
                    TelaVisualizadorPdf pdfViewer = new TelaVisualizadorPdf(telaPrincipal, pdfBytes);
                    telaPrincipal.trocarPainelCentral(pdfViewer);
                } catch (Exception e) {
                    e.printStackTrace();
                    DialogoCustomizado.mostrarMensagemErro((Frame) 
                            SwingUtilities.getWindowAncestor(TelaResultadoRelatorio.this), 
                            "Erro", "Ocorreu um erro ao gerar o PDF.");
                }
            }
        };
        worker.execute();
        loadingDialog.setVisible(true);
    }
    
    /**
     * Preenche a JTable da interface com os dados do relatório.
     */
    private void preencherTabela() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        for (VeiculoDTO dto : dados) {
            String saida = (dto.horarioSaida() != null) ? dto.horarioSaida().format(formatter) : "No pátio";
            modeloTabela.addRow(new Object[]{ dto.placa(), dto.nomeCliente(), 
                dto.modelo(), dto.cor(), dto.horarioEntrada().format(formatter), saida });
        }
    }
    
    /**
     * Método auxiliar para desenhar o cabeçalho da tabela no PDF.
     */
    private void drawTableHeader(PDPageContentStream contentStream, 
            float y, float margin, float[] colWidths, String[] headers) throws IOException {
        contentStream.setStrokingColor(Color.DARK_GRAY);
        contentStream.setNonStrokingColor(new Color(230, 230, 230));
        float tableWidth = 0;
        for (float width : colWidths) { tableWidth += width; }
        float tableX = (PDRectangle.A4.getWidth() - tableWidth) / 2;
        contentStream.addRect(tableX, y - 15, tableWidth, 20);
        contentStream.fillAndStroke();
        
        contentStream.setNonStrokingColor(Color.BLACK);
        contentStream.setFont(PDType1Font.HELVETICA_BOLD, 10);
        float x = tableX + 5;
        for (int i = 0; i < headers.length; i++) {
            contentStream.beginText();
            contentStream.newLineAtOffset(x, y - 10);
            contentStream.showText(headers[i]);
            contentStream.endText();
            x += colWidths[i];
        }
    }
    
    /**
     * Método auxiliar para desenhar uma linha de dados da tabela no PDF.
     */
    private void drawTableRow(PDPageContentStream contentStream, float y, float margin, 
            float[] colWidths, String[] rowData) throws IOException {
        contentStream.setNonStrokingColor(Color.BLACK);
        contentStream.setFont(PDType1Font.HELVETICA, 9);
        float tableWidth = 0;
        for (float width : colWidths) { tableWidth += width; }
        float tableX = (PDRectangle.A4.getWidth() - tableWidth) / 2;
        float x = tableX + 5;

        for (int i = 0; i < rowData.length; i++) {
            String text = rowData[i];
            if(text == null) text = "";
            if (text.length() > 25) text = text.substring(0, 24) + "...";
            contentStream.beginText();
            contentStream.newLineAtOffset(x, y);
            contentStream.showText(text);
            contentStream.endText();
            x += colWidths[i];
        }
    }

    /**
     * Método auxiliar para desenhar o número da página no rodapé do PDF.
     */
    private void drawPageNumber(PDDocument doc, PDPage page, int pageNum) throws IOException {
        try (PDPageContentStream contentStream = new PDPageContentStream(
                doc, page, PDPageContentStream.AppendMode.APPEND, true)) {
            contentStream.beginText();
            contentStream.setFont(PDType1Font.HELVETICA, 10);
            contentStream.newLineAtOffset(page.getMediaBox().getWidth() / 2 - 30, 30);
            contentStream.showText("Página " + pageNum);
            contentStream.endText();
        }
    }

    private JPanel createStyledCentralPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 20)) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(COLOR_SHADOW);
                g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 20, 20);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
            }
        };
        panel.setBackground(COLOR_PANEL);
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(25, 25, 25, 25));
        panel.add(createTopPanel(), BorderLayout.NORTH);
        panel.add(createTablePanel(), BorderLayout.CENTER);
        return panel;
    }
    
    private JPanel createTopPanel() {
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        topPanel.setBorder(new EmptyBorder(0, 0, 15, 0));
        JLabel lblTitulo = new JLabel("📜 Resultado do Relatório");
        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        topPanel.add(lblTitulo, BorderLayout.WEST);
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonsPanel.setOpaque(false);
        RoundedButton btnVisualizarPdf = new RoundedButton("Visualizar em PDF");
        btnVisualizarPdf.setBackground(COLOR_ORANGE_ACCENT);
        btnVisualizarPdf.addActionListener(e -> visualizarComoPdf());
        buttonsPanel.add(btnVisualizarPdf);
        RoundedButton btnVoltar = new RoundedButton("Voltar");
        btnVoltar.addActionListener(e -> telaPrincipal.trocarPainelCentral(new TelaRelatorios(telaPrincipal)));
        buttonsPanel.add(btnVoltar);
        topPanel.add(buttonsPanel, BorderLayout.EAST);
        return topPanel;
    }
    
    private JScrollPane createTablePanel() {
        String[] colunas = {"Placa", "Cliente", "Modelo", "Cor", "Entrada", "Saída"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
             @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        tabela = new JTable(modeloTabela);
        styleTable();
        preencherTabela();
        JScrollPane scrollPane = new JScrollPane(tabela);
        scrollPane.getViewport().setBackground(COLOR_INPUT_BG);
        scrollPane.setBorder(BorderFactory.createLineBorder(COLOR_PANEL.brighter()));
        return scrollPane;
    }
    
    private void styleTable() {
        tabela.setRowHeight(30);
        tabela.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tabela.setBackground(COLOR_INPUT_BG);
        tabela.setForeground(COLOR_TEXT_PRIMARY);
        tabela.setGridColor(COLOR_PANEL);
        tabela.setSelectionBackground(COLOR_ORANGE_ACCENT);
        tabela.setSelectionForeground(Color.WHITE);
        JTableHeader header = tabela.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 15));
        header.setBackground(new Color(25, 25, 25));
        header.setForeground(COLOR_ORANGE_ACCENT);
        header.setReorderingAllowed(false);
        header.setBorder(BorderFactory.createLineBorder(COLOR_PANEL));
    }
    
    private JDialog createLoadingDialog(String message) {
        JDialog dialog = new JDialog(telaPrincipal, "Aguarde...", true);
        JLabel label = new JLabel(message);
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setBorder(new EmptyBorder(20, 20, 20, 20));
        dialog.add(label);
        dialog.pack();
        dialog.setLocationRelativeTo(telaPrincipal);
        dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        return dialog;
    }

    private class RoundedButton extends JButton {
        private Color defaultBg;
        private Color hoverBg;
        public RoundedButton(String text) {
            super(text);
            setFont(FONT_BUTTON);
            setForeground(Color.WHITE);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setFocusPainted(false);
            setBorder(new EmptyBorder(10, 20, 10, 20));
            setContentAreaFilled(false);
            this.defaultBg = COLOR_INPUT_BG;
            this.hoverBg = defaultBg.brighter();
            setBackground(defaultBg);
            addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) { 
                    if (isEnabled()) setBackground(hoverBg); }
                public void mouseExited(java.awt.event.MouseEvent evt) { 
                    setBackground(defaultBg); }
            });
        }
        @Override
        public void setBackground(Color bg) {
            if (bg != hoverBg) {
                this.defaultBg = bg;
                this.hoverBg = bg.brighter();
            }
            super.setBackground(bg);
        }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            if (getModel().isPressed()) { g2.setColor(getBackground().darker()); }
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
            super.paintComponent(g2);
            g2.dispose();
        }
    }
}