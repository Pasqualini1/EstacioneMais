package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.text.Caret;
import javax.swing.text.DefaultCaret;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Uma janela de diálogo customizada que substitui o JOptionPane padrão.
 * <p>
 * Oferece mensagens estilizadas de sucesso, erro e confirmação.
 * O uso é feito através dos métodos estáticos públicos (ex: mostrarMensagemSucesso).
 */
public class DialogoCustomizado extends JDialog {

    private static final Color COLOR_CARD_BG = new Color(32, 32, 32);
    private static final Color COLOR_TEXT_PRIMARY = new Color(240, 240, 240);
    private static final Color COLOR_SUCCESS = new Color(39, 174, 96);
    private static final Color COLOR_ERROR = new Color(231, 76, 60);
    private static final Color COLOR_QUESTION = new Color(52, 152, 219);
    private static final Color COLOR_ORANGE_ACCENT = new Color(255, 157, 8);
    private static final Font FONT_MESSAGE = new Font("Segoe UI", Font.PLAIN, 16);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 13);

    /**
     * Enum para definir o tipo de diálogo a ser exibido.
     */
    public enum Tipo {SUCESSO, ERRO, CONFIRMACAO}

    private boolean confirmado = false;

    /**
     * Uma classe de Caret (cursor de texto) customizada que não desenha nada.
     * Usada para remover o cursor piscante de JTextAreas não editáveis.
     */
    private static class CursorFantasma extends DefaultCaret {
        /**
         * Sobrescrito para não desenhar o cursor.
         *
         * @param g O contexto gráfico.
         */
        @Override
        public void paint(Graphics g) {
            // Intencionalmente vazio.
        }

        /**
         * Sobrescrito para não solicitar repintura da área do cursor.
         *
         * @param r A área a ser "danificada" (marcada para repintar).
         */
        @Override
        protected synchronized void damage(Rectangle r) {
            // Intencionalmente vazio.
        }
    }

    /**
     * Construtor privado que monta a janela de diálogo.
     * <p>
     * Por ser privado, força o uso dos métodos estáticos (mostrarMensagemSucesso, etc.),
     * o que torna a API de uso mais limpa e controlada.
     *
     * @param owner    A janela "dona" (pai) deste diálogo.
     * @param titulo   O título a ser exibido (embora a janela seja 'undecorated').
     * @param mensagem O texto principal a ser exibido no diálogo.
     * @param tipo     O tipo (SUCESSO, ERRO, CONFIRMACAO) que define o ícone e botões.
     */
    private DialogoCustomizado(Window owner, String titulo, String mensagem, Tipo tipo) {
        super(owner, titulo, ModalityType.APPLICATION_MODAL);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setUndecorated(true);
        setBackground(new Color(0, 0, 0, 0));

        JPanel shadowPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0, 0, 0, 80));
                g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 20, 20);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        shadowPanel.setOpaque(false);
        shadowPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel contentPanel = new JPanel(new BorderLayout(15, 20));
        contentPanel.setBackground(COLOR_CARD_BG);
        contentPanel.setBorder(new EmptyBorder(25, 30, 20, 30));

        JLabel iconLabel = createIconLabel(tipo);
        contentPanel.add(iconLabel, BorderLayout.WEST);

        JPanel messageWrapper = new JPanel(new BorderLayout());
        messageWrapper.setOpaque(false);

        JTextArea messageArea = new JTextArea(mensagem);
        messageArea.setFont(FONT_MESSAGE);
        messageArea.setForeground(COLOR_TEXT_PRIMARY);
        messageArea.setOpaque(false);
        messageArea.setEditable(false);
        messageArea.setLineWrap(true);
        messageArea.setWrapStyleWord(true);
        messageArea.setBorder(null);
        messageArea.setCaret(new CursorFantasma());
        messageArea.setSize(new Dimension(400, Short.MAX_VALUE));

        messageWrapper.add(messageArea, BorderLayout.CENTER);
        contentPanel.add(messageWrapper, BorderLayout.CENTER);

        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonsPanel.setOpaque(false);

        if (tipo == Tipo.CONFIRMACAO) {
            RoundedDialogButton btnNao = new RoundedDialogButton("Não", new Color(108, 117, 125));
            btnNao.addActionListener(e -> {
                confirmado = false;
                dispose();
            });
            RoundedDialogButton btnSim = new RoundedDialogButton("Sim", COLOR_ORANGE_ACCENT);
            btnSim.addActionListener(e -> {
                confirmado = true;
                dispose();
            });
            buttonsPanel.add(btnNao);
            buttonsPanel.add(btnSim);
        } else {
            RoundedDialogButton btnOk = new RoundedDialogButton("OK", COLOR_ORANGE_ACCENT);
            btnOk.addActionListener(e -> dispose());
            buttonsPanel.add(btnOk);
        }
        contentPanel.add(buttonsPanel, BorderLayout.SOUTH);

        shadowPanel.add(contentPanel, BorderLayout.CENTER);
        setContentPane(shadowPanel);

        pack();
        setMinimumSize(new Dimension(480, 180));
        setLocationRelativeTo(owner);
    }

    /**
     * Método auxiliar que cria e retorna o JLabel do ícone (✔, ❌, ?)
     * com base no tipo de diálogo solicitado.
     *
     * @param tipo O tipo de diálogo (SUCESSO, ERRO, CONFIRMACAO).
     * @return Um JLabel configurado com o ícone e a cor apropriados.
     */
    private JLabel createIconLabel(Tipo tipo) {
        String iconText;
        Color iconColor;
        switch (tipo) {
            case SUCESSO:
                iconText = "✔";
                iconColor = COLOR_SUCCESS;
                break;
            case ERRO:
                iconText = "❌";
                iconColor = COLOR_ERROR;
                break;
            case CONFIRMACAO:
                iconText = "?";
                iconColor = COLOR_QUESTION;
                break;
            default:
                iconText = "";
                iconColor = COLOR_TEXT_PRIMARY;
                break;
        }
        JLabel label = new JLabel(iconText);
        label.setFont(new Font("Segoe UI Symbol", Font.BOLD, 36));
        label.setForeground(iconColor);
        label.setBorder(new EmptyBorder(0, 0, 0, 15));
        return label;
    }

    /**
     * Exibe um diálogo de sucesso.
     *
     * @param owner    A janela "dona" (pai) do diálogo.
     * @param titulo   O título do diálogo.
     * @param mensagem O texto a ser exibido.
     */
    public static void mostrarMensagemSucesso(Window owner, String titulo, String mensagem) {
        new DialogoCustomizado(owner, titulo, mensagem, Tipo.SUCESSO).setVisible(true);
    }

    /**
     * Exibe um diálogo de erro.
     *
     * @param owner    A janela "dona" (pai) do diálogo.
     * @param titulo   O título do diálogo.
     * @param mensagem O texto a ser exibido.
     */
    public static void mostrarMensagemErro(Window owner, String titulo, String mensagem) {
        new DialogoCustomizado(owner, titulo, mensagem, Tipo.ERRO).setVisible(true);
    }

    /**
     * Exibe um diálogo de confirmação (Sim/Não) e aguarda a resposta do usuário.
     * <p>
     * Como o diálogo é "modal", a execução do código que chamou este método
     * fica pausada até que o usuário clique em um dos botões.
     *
     * @param owner    A janela "dona" (pai) do diálogo.
     * @param titulo   O título do diálogo.
     * @param mensagem O texto da pergunta.
     * @return {@code true} se o usuário clicar em "Sim", {@code false} caso contrário.
     */
    public static boolean mostrarConfirmacao(Window owner, String titulo, String mensagem) {
        DialogoCustomizado dialogo = new DialogoCustomizado(owner, titulo, mensagem, Tipo.CONFIRMACAO);
        dialogo.setVisible(true);
        return dialogo.confirmado;
    }

    /**
     * Classe interna que representa um botão customizado com cantos arredondados
     * e um efeito visual de "hover" (mudança de cor ao passar o mouse).
     */
    private static class RoundedDialogButton extends JButton {
        private final Color baseBg;
        private final Color hoverBg;

        /**
         * Construtor que define a aparência do botão e adiciona os listeners de mouse
         * para controlar o efeito de hover.
         *
         * @param text    O texto a ser exibido no botão.
         * @param bgColor A cor de fundo base do botão.
         */
        public RoundedDialogButton(String text, Color bgColor) {
            super(text);
            this.baseBg = bgColor;
            this.hoverBg = bgColor.brighter();
            setFont(FONT_BUTTON);
            setForeground(Color.WHITE);
            setBackground(baseBg);
            setFocusPainted(false);
            setBorder(new EmptyBorder(8, 18, 8, 18));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setContentAreaFilled(false);
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    setBackground(hoverBg);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    setBackground(baseBg);
                }
            });
        }

        /**
         * Sobrescreve o método de pintura do componente para desenhar um retângulo
         * com cantos arredondados como fundo do botão.
         *
         * @param g O contexto gráfico fornecido pelo Swing.
         */
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16);
            super.paintComponent(g2);
            g2.dispose();
        }
    }
}