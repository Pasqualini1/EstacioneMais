package view;

import dto.VeiculoDTO;
import service.ApiClient;
import service.ApiException;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Painel (JPanel) que exibe a tela de consulta ao histórico de veículos.
 * <p>
 * Permite ao usuário filtrar o histórico por placa ou ver todos os registros,
 * exibindo os resultados em uma tabela. Permite também abrir uma tela de
 * detalhes ao clicar duas vezes em um registro.
 */
public class TelaConsultarVeiculo extends JPanel {

    private static final Color COLOR_BACKGROUND = new Color(34, 40, 49);
    private static final Color COLOR_PANEL = new Color(57, 62, 70);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_ORANGE_ACCENT = new Color(255, 157, 8);
    private static final Color COLOR_INPUT_BG = new Color(45, 45, 45);
    private static final Color COLOR_SHADOW = new Color(0, 0, 0, 80);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 14);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 14);

    private final JTextField txtPlaca;
    private final JTable tabela;
    private final DefaultTableModel modeloTabela;
    private final TelaPrincipal telaPrincipal;

    private List<VeiculoDTO> listaHistorico;

    /**
     * Constrói a tela de consulta de veículos.
     *
     * @param telaPrincipal A referência à janela principal (JFrame) da aplicação,
     * usada para navegação e como "pai" dos diálogos.
     */
    public TelaConsultarVeiculo(TelaPrincipal telaPrincipal) {
        this.telaPrincipal = telaPrincipal;

        setLayout(new GridBagLayout());
        setBackground(COLOR_BACKGROUND);

        txtPlaca = new JTextField(20);
        String[] colunas = {"Placa", "Cliente", "Modelo", "Entrada", "Saída", "Status"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tabela = new JTable(modeloTabela);

        tabela.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int selectedRow = tabela.getSelectedRow();
                    if (selectedRow >= 0 && listaHistorico != null && selectedRow < listaHistorico.size()) {
                        VeiculoDTO veiculoSelecionado = listaHistorico.get(selectedRow);
                        abrirTelaDeDetalhes(veiculoSelecionado);
                    }
                }
            }
        });

        add(createStyledCentralPanel(), new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0,
                GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(30, 30, 30, 30), 0, 0));

        buscarHistorico();
    }

    /**
     * Abre um diálogo modal exibindo os detalhes de um veículo selecionado.
     *
     * @param veiculo O VeiculoDTO contendo os dados do registro a ser detalhado.
     */
    private void abrirTelaDeDetalhes(VeiculoDTO veiculo) {
        JDialog dialog = new JDialog(telaPrincipal, "Detalhes do Veículo", true);
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

        TelaDetalharVeiculo painelDetalhes = new TelaDetalharVeiculo(veiculo, telaPrincipal, dialog);

        dialog.add(painelDetalhes);
        dialog.pack();
        dialog.setLocationRelativeTo(telaPrincipal);
        dialog.setVisible(true);
    }

    /**
     * Busca o histórico de estacionamento de forma assíncrona.
     * <p>
     * Utiliza um SwingWorker para chamar a API (ApiClient) em background,
     * filtrando pela placa (se preenchida) ou buscando todos.
     * Ao concluir, atualiza a JTable na Event Dispatch Thread (EDT)
     * ou exibe um diálogo de erro.
     */
    private void buscarHistorico() {
        String placaBusca = txtPlaca.getText().trim().toUpperCase();

        SwingWorker<List<VeiculoDTO>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<VeiculoDTO> doInBackground() throws ApiException {
                return ApiClient.gerarRelatorioPorPlaca(placaBusca);
            }

            @Override
            protected void done() {
                try {
                    listaHistorico = get();
                    modeloTabela.setRowCount(0);

                    if (listaHistorico == null || listaHistorico.isEmpty()) {
                        String mensagem = placaBusca.isEmpty() ?
                                "Nenhum registro encontrado no histórico." :
                                "Nenhum histórico para a placa: " +
                                        placaBusca;
                        DialogoCustomizado.mostrarMensagemErro(
                                (Frame) SwingUtilities.getWindowAncestor(TelaConsultarVeiculo.this),
                                "Sem Resultados",
                                mensagem
                        );
                        return;
                    }

                    for (VeiculoDTO registro : listaHistorico) {
                        String clienteInfo = registro.nomeCliente();
                        if (registro.telefoneCliente() != null && !registro.telefoneCliente().isBlank()) {
                            clienteInfo += " (" + registro.telefoneCliente() + ")";
                        }
                        String status = (registro.horarioSaida() == null) ? "Estacionado" : "Finalizado";
                        modeloTabela.addRow(new Object[]{
                                registro.placa(), clienteInfo, registro.modelo(),
                                formatarData(registro.horarioEntrada()), formatarData(registro.horarioSaida()), status
                        });
                    }
                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() :
                            "Ocorreu um erro inesperado.";

                    DialogoCustomizado.mostrarMensagemErro(
                            (Frame) SwingUtilities.getWindowAncestor(TelaConsultarVeiculo.this),
                            "Erro ao Consultar",
                            "Não foi possível consultar o histórico:\n" + errorMessage
                    );
                }
            }
        };
        worker.execute();
    }

    /**
     * Limpa o campo de filtro de placa e dispara uma nova busca
     * (que trará o histórico completo).
     */
    private void limparBusca() {
        txtPlaca.setText("");
        buscarHistorico();
    }

    /**
     * Formata um objeto LocalDateTime para uma string legível (dd/MM/yyyy HH:mm).
     *
     * @param data O LocalDateTime a ser formatado.
     * @return A data formatada como String, ou "—" se a data for nula.
     */
    private String formatarData(LocalDateTime data) {
        if (data == null) {
            return "—";
        }
        return data.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
    }

    /**
     * Carrega um ImageIcon a partir de um caminho de arquivo, com redimensionamento.
     *
     * @param path   O caminho (relativo ou absoluto) para o arquivo de imagem.
     * @param width  A largura desejada para a imagem.
     * @param height A altura desejada para a imagem.
     * @return O ImageIcon redimensionado, ou um ícone em branco se
     * o arquivo não for encontrado.
     */
    private ImageIcon loadIcon(String path, int width, int height) {
        File file = new File(path);
        if (!file.exists()) {
            System.err.println("Imagem não encontrada: " + path);
            return new ImageIcon(new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB));
        }
        ImageIcon icon = new ImageIcon(path);
        if (width > 0 && height > 0) {
            Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
            icon = new ImageIcon(img);
        }
        return icon;
    }

    /**
     * Cria o painel central estilizado (com sombra e cantos arredondados)
     * que contém o cabeçalho e a tabela.
     *
     * @return O JPanel central estilizado.
     */
    private JPanel createStyledCentralPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 20)) {
            /**
             * Sobrescrito para desenhar uma sombra e cantos arredondados.
             *
             * @param g O contexto gráfico.
             */
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(COLOR_SHADOW);
                g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 20, 20);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
            }
        };
        panel.setBackground(COLOR_PANEL);
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(25, 25, 25, 25));
        panel.add(createHeaderPanel(), BorderLayout.NORTH);
        styleTable();
        JScrollPane scrollTabela = new JScrollPane(tabela);
        scrollTabela.getViewport().setBackground(COLOR_INPUT_BG);
        scrollTabela.setBorder(BorderFactory.createLineBorder(COLOR_PANEL.brighter()));
        panel.add(scrollTabela, BorderLayout.CENTER);
        return panel;
    }

    /**
     * Cria o painel de cabeçalho, que inclui o título, o campo de busca
     * e os botões de ação (Consultar, Limpar, Atualizar, Fechar).
     *
     * @return Um JPanel contendo o cabeçalho completo da tela.
     */
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout(10, 15));
        headerPanel.setOpaque(false);
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setOpaque(false);

        JLabel lblTitulo = new JLabel("Histórico de Estacionamento");
        lblTitulo.setIcon(loadIcon("src/imagens/search_car.png", 28, 28));
        lblTitulo.setIconTextGap(10);
        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        titlePanel.add(lblTitulo, BorderLayout.WEST);

        JPanel iconButtonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        iconButtonsPanel.setOpaque(false);
        JButton btnAtualizar = createIconButton("🔄", "Atualizar Lista");
        btnAtualizar.addActionListener(e -> buscarHistorico());
        iconButtonsPanel.add(btnAtualizar);
        JButton btnFechar = createIconButton("X", "Fechar");
        btnFechar.addActionListener(e -> telaPrincipal.mostrarPainelInicial());
        iconButtonsPanel.add(btnFechar);
        titlePanel.add(iconButtonsPanel, BorderLayout.EAST);
        headerPanel.add(titlePanel, BorderLayout.NORTH);

        JPanel searchPanel = new JPanel(new GridBagLayout());
        searchPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 0, 5, 5);
        JLabel lblPlaca = new JLabel("Filtrar por Placa:");
        lblPlaca.setForeground(COLOR_TEXT_PRIMARY);
        lblPlaca.setFont(FONT_LABEL);
        gbc.gridx = 0;
        gbc.gridy = 0;
        searchPanel.add(lblPlaca, gbc);

        txtPlaca.setFont(FONT_LABEL);
        txtPlaca.setBackground(COLOR_INPUT_BG);
        txtPlaca.setForeground(COLOR_TEXT_PRIMARY);
        txtPlaca.setCaretColor(COLOR_ORANGE_ACCENT);
        txtPlaca.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_PANEL.brighter()), new EmptyBorder(8, 8, 8, 8)
        ));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        searchPanel.add(txtPlaca, gbc);

        JPanel actionButtonsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        actionButtonsPanel.setOpaque(false);
        RoundedButton btnConsultar = new RoundedButton("Consultar");
        btnConsultar.setBackground(COLOR_ORANGE_ACCENT);
        btnConsultar.addActionListener(e -> buscarHistorico());
        RoundedButton btnLimpar = new RoundedButton("Limpar");
        btnLimpar.addActionListener(e -> limparBusca());
        actionButtonsPanel.add(btnConsultar);
        actionButtonsPanel.add(btnLimpar);
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.weightx = 0;
        gbc.fill = GridBagConstraints.NONE;
        searchPanel.add(actionButtonsPanel, gbc);

        headerPanel.add(searchPanel, BorderLayout.CENTER);
        return headerPanel;
    }

    /**
     * Cria um botão de ícone (texto) estilizado, sem borda e com tooltip.
     *
     * @param icon    O texto/ícone (ex: "X", "🔄").
     * @param tooltip O texto a ser exibido no tooltip.
     * @return Um JButton estilizado como ícone.
     */
    private JButton createIconButton(String icon, String tooltip) {
        JButton button = new JButton(icon);
        button.setFont(new Font("Segoe UI Symbol", Font.BOLD, 16));
        button.setForeground(COLOR_TEXT_PRIMARY);
        button.setToolTipText(tooltip);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setContentAreaFilled(false);
        button.setBorder(null);
        button.setFocusPainted(false);
        return button;
    }

    /**
     * Aplica o estilo "dark theme" customizado à JTable e seu cabeçalho.
     */
    private void styleTable() {
        tabela.setRowHeight(30);
        tabela.setBackground(COLOR_INPUT_BG);
        tabela.setForeground(COLOR_TEXT_PRIMARY);
        tabela.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tabela.setGridColor(COLOR_PANEL);
        tabela.setSelectionBackground(COLOR_ORANGE_ACCENT);
        tabela.setSelectionForeground(Color.WHITE);
        JTableHeader header = tabela.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 15));
        header.setBackground(new Color(25, 25, 25));
        header.setForeground(COLOR_ORANGE_ACCENT);
        header.setReorderingAllowed(false);
        header.setBorder(BorderFactory.createLineBorder(COLOR_PANEL));
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < tabela.getColumnCount(); i++) {
            tabela.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
    }

    /**
     * Classe interna (private) que representa um JButton customizado
     * com cantos arredondados e efeitos de "hover".
     */
    private class RoundedButton extends JButton {
        private Color defaultBg;
        private Color hoverBg;

        /**
         * Construtor do botão arredondado.
         * Configura a aparência e adiciona listeners de mouse para o efeito hover.
         *
         * @param text O texto a ser exibido no botão.
         */
        public RoundedButton(String text) {
            super(text);
            setFont(FONT_BUTTON);
            setForeground(Color.WHITE);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setFocusPainted(false);
            setBorder(new EmptyBorder(10, 20, 10, 20));
            setContentAreaFilled(false);
            this.defaultBg = COLOR_INPUT_BG;
            this.hoverBg = defaultBg.brighter();
            setBackground(defaultBg);
            addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    if (isEnabled()) setBackground(hoverBg);
                }

                public void mouseExited(java.awt.event.MouseEvent evt) {
                    setBackground(defaultBg);
                }
            });
        }

        /**
         * Sobrescrito para atualizar as cores de 'default' e 'hover'
         * quando a cor de fundo é alterada programaticamente.
         *
         * @param bg A nova cor de fundo.
         */
        @Override
        public void setBackground(Color bg) {
            if (bg != hoverBg) {
                this.defaultBg = bg;
                this.hoverBg = bg.brighter();
            }
            super.setBackground(bg);
        }

        /**
         * Sobrescreve o método de pintura para desenhar o fundo arredondado.
         * Usa Graphics2D para preencher um 'RoundRect' com antialias.
         *
         * @param g O contexto gráfico fornecido pelo Swing.
         */
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            if (getModel().isPressed()) {
                g2.setColor(getBackground().darker());
            }
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
            super.paintComponent(g2);
            g2.dispose();
        }
    }
}