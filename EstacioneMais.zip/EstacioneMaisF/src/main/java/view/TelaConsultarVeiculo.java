package view;

import dto.VeiculoDTO;
import service.ApiClient;
import service.ApiException;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Painel que representa a tela de consulta ao histórico de veículos.
 * Permite ao usuário filtrar os registros por placa e visualizar os resultados
 * em uma tabela. Um duplo-clique em um registro abre uma tela de detalhes.
 */
public class TelaConsultarVeiculo extends JPanel {

    // --- Constantes de Estilo ---
    private static final Color COLOR_BACKGROUND = new Color(34, 40, 49);
    private static final Color COLOR_PANEL = new Color(57, 62, 70);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_ORANGE_ACCENT = new Color(255, 157, 8);
    private static final Color COLOR_INPUT_BG = new Color(45, 45, 45);
    private static final Color COLOR_SHADOW = new Color(0, 0, 0, 80);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 14);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 14);

    // --- Componentes ---
    private final JTextField txtPlaca;
    private final JTable tabela;
    private final DefaultTableModel modeloTabela;
    private final TelaPrincipal telaPrincipal;
    
    private List<VeiculoDTO> listaHistorico; // Cache dos dados da tabela

    /**
     * Construtor da tela. Inicializa os componentes da UI, define os listeners de eventos
     * (como o duplo-clique na tabela) e dispara a busca inicial do histórico.
     *
     * @param telaPrincipal A referência à janela principal da aplicação.
     */
    public TelaConsultarVeiculo(TelaPrincipal telaPrincipal) {
        this.telaPrincipal = telaPrincipal;

        setLayout(new GridBagLayout());
        setBackground(COLOR_BACKGROUND);

        txtPlaca = new JTextField(20);
        String[] colunas = {"Placa", "Cliente", "Modelo", "Entrada", "Saída", "Status"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tabela = new JTable(modeloTabela);

        // Lógica de evento para o duplo-clique na tabela.
        tabela.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int selectedRow = tabela.getSelectedRow();
                    if (selectedRow >= 0 && listaHistorico != null && selectedRow < listaHistorico.size()) {
                        VeiculoDTO veiculoSelecionado = listaHistorico.get(selectedRow);
                        abrirTelaDeDetalhes(veiculoSelecionado);
                    }
                }
            }
        });

        add(createStyledCentralPanel(), new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0, 
                GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(30, 30, 30, 30), 0, 0));

        buscarHistorico();
    }
    
    /**
     * Abre uma janela de diálogo modal com os detalhes completos do veículo selecionado.
     *
     * @param veiculo O DTO do veículo cujos detalhes serão exibidos.
     */
    private void abrirTelaDeDetalhes(VeiculoDTO veiculo) {
        JDialog dialog = new JDialog(telaPrincipal, "Detalhes do Veículo", true);
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        
        TelaDetalharVeiculo painelDetalhes = new TelaDetalharVeiculo(veiculo, telaPrincipal, dialog);
        
        dialog.add(painelDetalhes);
        dialog.pack();
        dialog.setLocationRelativeTo(telaPrincipal);
        dialog.setVisible(true);
    }
    
    /**
     * Realiza a busca do histórico de veículos de forma assíncrona para não travar a UI.
     * Utiliza um SwingWorker para executar a chamada de API em uma thread separada e,
     * ao finalizar, atualiza a tabela na thread de eventos do Swing.
     */
    private void buscarHistorico() {
        String placaBusca = txtPlaca.getText().trim().toUpperCase();

        SwingWorker<List<VeiculoDTO>, Void> worker = new SwingWorker<>() {
            /**
             * Este método executa em uma thread de background.
             * Realiza a chamada à API para buscar os dados.
             */
            @Override
            protected List<VeiculoDTO> doInBackground() throws ApiException {
                return ApiClient.gerarRelatorioPorPlaca(placaBusca);
            }

            /**
             * Este método executa na thread do Swing (EDT) após o fim do doInBackground.
             * É seguro para atualizar os componentes da UI com o resultado da busca.
             */
            @Override
            protected void done() {
                try {
                    listaHistorico = get(); // Pega o resultado da busca
                    modeloTabela.setRowCount(0); // Limpa a tabela

                    if (listaHistorico == null || listaHistorico.isEmpty()) {
                        String mensagem = placaBusca.isEmpty() ? 
                                "Nenhum registro encontrado no histórico." : 
                                "Nenhum histórico para a placa: " + 
                                placaBusca;
                        DialogoCustomizado.mostrarMensagemErro(
                            (Frame) SwingUtilities.getWindowAncestor(TelaConsultarVeiculo.this), 
                            "Sem Resultados", 
                            mensagem
                        );
                        return;
                    }
                    
                    // Preenche a tabela com os dados retornados
                    for (VeiculoDTO registro : listaHistorico) {
                        String clienteInfo = registro.nomeCliente();
                        if (registro.telefoneCliente() != null && !registro.telefoneCliente().isBlank()) {
                            clienteInfo += " (" + registro.telefoneCliente() + ")";
                        }
                        String status = (registro.horarioSaida() == null) ? "Estacionado" : "Finalizado";
                        modeloTabela.addRow(new Object[]{
                            registro.placa(), clienteInfo, registro.modelo(),
                            formatarData(registro.horarioEntrada()), formatarData(registro.horarioSaida()), status
                        });
                    }
                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() : 
                            "Ocorreu um erro inesperado.";
                    
                    DialogoCustomizado.mostrarMensagemErro(
                        (Frame) SwingUtilities.getWindowAncestor(TelaConsultarVeiculo.this), 
                        "Erro ao Consultar", 
                        "Não foi possível consultar o histórico:\n" + errorMessage
                    );
                }
            }
        };
        worker.execute();
    }
    
    /**
     * Limpa o campo de busca de placa e executa uma nova busca para
     * carregar o histórico completo novamente.
     */
    private void limparBusca() {
        txtPlaca.setText("");
        buscarHistorico();
    }
    
    /**
     * Formata um objeto LocalDateTime para uma string amigável (dd/MM/yyyy HH:mm).
     * Retorna "—" se a data for nula.
     */
    private String formatarData(LocalDateTime data) {
        if (data == null) {
            return "—";
        }
        return data.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
    }

    // O restante da classe contém apenas a montagem da UI, que não será comentada.
    private JPanel createStyledCentralPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 20)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(COLOR_SHADOW);
                g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 20, 20);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
            }
        };
        panel.setBackground(COLOR_PANEL);
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(25, 25, 25, 25));
        panel.add(createHeaderPanel(), BorderLayout.NORTH);
        styleTable();
        JScrollPane scrollTabela = new JScrollPane(tabela);
        scrollTabela.getViewport().setBackground(COLOR_INPUT_BG);
        scrollTabela.setBorder(BorderFactory.createLineBorder(COLOR_PANEL.brighter()));
        panel.add(scrollTabela, BorderLayout.CENTER);
        return panel;
    }
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout(10, 15));
        headerPanel.setOpaque(false);
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setOpaque(false);
        JLabel lblTitulo = new JLabel("🔎 Histórico de Estacionamento");
        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        titlePanel.add(lblTitulo, BorderLayout.WEST);
        JPanel iconButtonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        iconButtonsPanel.setOpaque(false);
        JButton btnAtualizar = createIconButton("🔄", "Atualizar Lista");
        btnAtualizar.addActionListener(e -> buscarHistorico());
        iconButtonsPanel.add(btnAtualizar);
        JButton btnFechar = createIconButton("X", "Fechar");
        btnFechar.addActionListener(e -> telaPrincipal.mostrarPainelInicial());
        iconButtonsPanel.add(btnFechar);
        titlePanel.add(iconButtonsPanel, BorderLayout.EAST);
        headerPanel.add(titlePanel, BorderLayout.NORTH);
        JPanel searchPanel = new JPanel(new GridBagLayout());
        searchPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 0, 5, 5);
        JLabel lblPlaca = new JLabel("Filtrar por Placa:");
        lblPlaca.setForeground(COLOR_TEXT_PRIMARY);
        lblPlaca.setFont(FONT_LABEL);
        gbc.gridx = 0; gbc.gridy = 0;
        searchPanel.add(lblPlaca, gbc);
        txtPlaca.setFont(FONT_LABEL);
        txtPlaca.setBackground(COLOR_INPUT_BG);
        txtPlaca.setForeground(COLOR_TEXT_PRIMARY);
        txtPlaca.setCaretColor(COLOR_ORANGE_ACCENT);
        txtPlaca.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_PANEL.brighter()), new EmptyBorder(8, 8, 8, 8)
        ));
        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 1.0; gbc.fill = GridBagConstraints.HORIZONTAL;
        searchPanel.add(txtPlaca, gbc);
        JPanel actionButtonsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        actionButtonsPanel.setOpaque(false);
        RoundedButton btnConsultar = new RoundedButton("Consultar");
        btnConsultar.setBackground(COLOR_ORANGE_ACCENT);
        btnConsultar.addActionListener(e -> buscarHistorico());
        RoundedButton btnLimpar = new RoundedButton("Limpar");
        btnLimpar.addActionListener(e -> limparBusca());
        actionButtonsPanel.add(btnConsultar);
        actionButtonsPanel.add(btnLimpar);
        gbc.gridx = 2; gbc.gridy = 0; gbc.weightx = 0; gbc.fill = GridBagConstraints.NONE;
        searchPanel.add(actionButtonsPanel, gbc);
        headerPanel.add(searchPanel, BorderLayout.CENTER);
        return headerPanel;
    }
    private JButton createIconButton(String icon, String tooltip) {
        JButton button = new JButton(icon);
        button.setFont(new Font("Segoe UI Symbol", Font.BOLD, 16));
        button.setForeground(COLOR_TEXT_PRIMARY);
        button.setToolTipText(tooltip);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setContentAreaFilled(false);
        button.setBorder(null);
        button.setFocusPainted(false);
        return button;
    }
    private void styleTable() {
        tabela.setRowHeight(30);
        tabela.setBackground(COLOR_INPUT_BG);
        tabela.setForeground(COLOR_TEXT_PRIMARY);
        tabela.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tabela.setGridColor(COLOR_PANEL);
        tabela.setSelectionBackground(COLOR_ORANGE_ACCENT);
        tabela.setSelectionForeground(Color.WHITE);
        JTableHeader header = tabela.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 15));
        header.setBackground(new Color(25, 25, 25));
        header.setForeground(COLOR_ORANGE_ACCENT);
        header.setReorderingAllowed(false);
        header.setBorder(BorderFactory.createLineBorder(COLOR_PANEL));
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < tabela.getColumnCount(); i++) {
            tabela.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
    }

    private class RoundedButton extends JButton {
        private Color defaultBg;
        private Color hoverBg;
        public RoundedButton(String text) {
            super(text);
            setFont(FONT_BUTTON);
            setForeground(Color.WHITE);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setFocusPainted(false);
            setBorder(new EmptyBorder(10, 20, 10, 20));
            setContentAreaFilled(false);
            this.defaultBg = COLOR_INPUT_BG;
            this.hoverBg = defaultBg.brighter();
            setBackground(defaultBg);
            addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) { if (isEnabled()) setBackground(hoverBg); }
                public void mouseExited(java.awt.event.MouseEvent evt) { setBackground(defaultBg); }
            });
        }
        @Override
        public void setBackground(Color bg) {
            if (bg != hoverBg) {
                this.defaultBg = bg;
                this.hoverBg = bg.brighter();
            }
            super.setBackground(bg);
        }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            if (getModel().isPressed()) { g2.setColor(getBackground().darker()); }
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
            super.paintComponent(g2);
            g2.dispose();
        }
    }
}