package view;

import javax.swing.*;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;
import java.awt.*;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * Uma classe customizada que estende JFileChooser para aplicar um tema "dark"
 * temporariamente, apenas durante a exibição da janela de seleção de arquivo.
 * <p>
 * O principal método de uso é o utilitário estático 'showSaveDialog'.
 */
public class CustomFileChooser extends JFileChooser {

    private static final Color BG_COLOR = new Color(32, 32, 32);
    private static final Color TEXT_COLOR = new Color(240, 240, 240);
    private static final Color SELECTION_BG_COLOR = new Color(50, 50, 50);
    private static final Color ORANGE_ACCENT = new Color(255, 157, 8);
    private static final Font FONT_UI = new Font("Segoe UI", Font.PLAIN, 12);

    private final Map<String, Object> originalUIDefaults = new HashMap<>();

    private final String[] uiKeysToChange = {
            "FileChooser.background", "Panel.background", "List.background", "TextField.background",
            "FileChooser.foreground", "Label.foreground", "List.foreground", "TextField.foreground",
            "List.selectionBackground", "List.selectionForeground",
            "FileChooser.font", "Label.font", "List.font", "TextField.font"
    };

    /**
     * Construtor padrão do JFileChooser.
     */
    public CustomFileChooser() {
        super();
    }

    /**
     * Sobrescreve o método para exibir a janela de "Salvar".
     * <p>
     * Antes de exibir, aplica a UI customizada e, ao final (independente da ação
     * do usuário), restaura a UI original para não afetar outros componentes da aplicação.
     *
     * @param parent O componente pai sobre o qual a caixa de diálogo é exibida.
     * @return O estado (int) da seleção do usuário (ex: APPROVE_OPTION).
     */
    @Override
    public int showSaveDialog(Component parent) {
        setupCustomUI();
        int result = -1;
        try {
            result = super.showSaveDialog(parent);
        } finally {
            restoreOriginalUI();
        }
        return result;
    }

    /**
     * Sobrescreve o método para exibir a janela de "Abrir".
     * <p>
     * Assim como o 'showSaveDialog', garante que a UI customizada seja aplicada
     * e posteriormente removida de forma segura.
     *
     * @param parent O componente pai sobre o qual a caixa de diálogo é exibida.
     * @return O estado (int) da seleção do usuário (ex: APPROVE_OPTION).
     */
    @Override
    public int showOpenDialog(Component parent) {
        setupCustomUI();
        int result = -1;
        try {
            result = super.showOpenDialog(parent);
        } finally {
            restoreOriginalUI();
        }
        return result;
    }

    /**
     * Aplica as configurações de estilo customizadas (tema dark).
     * <p>
     * Este método primeiro salva as configurações de UI originais do Java Swing e,
     * em seguida, aplica as novas cores e fontes definidas para o tema.
     */
    private void setupCustomUI() {
        for (String key : uiKeysToChange) {
            originalUIDefaults.put(key, UIManager.get(key));
        }

        UIManager.put("FileChooser.background", new ColorUIResource(BG_COLOR));
        UIManager.put("Panel.background", new ColorUIResource(BG_COLOR));
        UIManager.put("List.background", new ColorUIResource(SELECTION_BG_COLOR));
        UIManager.put("TextField.background", new ColorUIResource(SELECTION_BG_COLOR));

        UIManager.put("FileChooser.foreground", new ColorUIResource(TEXT_COLOR));
        UIManager.put("Label.foreground", new ColorUIResource(TEXT_COLOR));
        UIManager.put("List.foreground", new ColorUIResource(TEXT_COLOR));
        UIManager.put("TextField.foreground", new ColorUIResource(TEXT_COLOR));

        UIManager.put("List.selectionBackground", new ColorUIResource(ORANGE_ACCENT));
        UIManager.put("List.selectionForeground", new ColorUIResource(Color.WHITE));

        UIManager.put("FileChooser.font", new FontUIResource(FONT_UI));
        UIManager.put("Label.font", new FontUIResource(FONT_UI));
        UIManager.put("List.font", new FontUIResource(FONT_UI));
        UIManager.put("TextField.font", new FontUIResource(FONT_UI));

        SwingUtilities.updateComponentTreeUI(this);
    }

    /**
     * Restaura as configurações de UI originais do Java Swing.
     * <p>
     * Este método é crucial para garantir que o tema dark customizado não "vaze"
     * para outras partes da aplicação após o fechamento do FileChooser.
     */
    private void restoreOriginalUI() {
        for (Map.Entry<String, Object> entry : originalUIDefaults.entrySet()) {
            UIManager.put(entry.getKey(), entry.getValue());
        }
        originalUIDefaults.clear();
    }

    /**
     * Método utilitário estático para exibir a janela de salvar arquivo.
     * Encapsula a criação e configuração do CustomFileChooser, facilitando seu uso
     * a partir de outras classes da view.
     *
     * @param parent          O componente pai sobre o qual a janela será exibida.
     * @param defaultFileName O nome de arquivo sugerido ao usuário.
     * @return O objeto File selecionado pelo usuário com a extensão .pdf garantida,
     * ou null se o usuário cancelar a operação.
     */
    public static File showSaveDialog(Component parent, String defaultFileName) {
        CustomFileChooser fileChooser = new CustomFileChooser();
        fileChooser.setDialogTitle("Salvar Relatório em PDF");
        fileChooser.setSelectedFile(new File(defaultFileName));

        int userSelection = fileChooser.showSaveDialog(parent);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            
            if (!fileToSave.getAbsolutePath().endsWith(".pdf")) {
                fileToSave = new File(fileToSave.getAbsolutePath() + ".pdf");
            }
            return fileToSave;
        }
        return null;
    }
}