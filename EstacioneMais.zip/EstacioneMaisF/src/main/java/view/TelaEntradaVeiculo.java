package view;

import service.ApiClient;
import service.ApiException;
import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamResolution;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File; // Import necessário

public class TelaEntradaVeiculo extends JPanel {

    // --- Estilos ---
    private static final Color COLOR_BACKGROUND = new Color(34, 40, 49);
    private static final Color COLOR_PANEL = new Color(57, 62, 70);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_ORANGE_ACCENT = new Color(255, 157, 8);
    private static final Color COLOR_INPUT_BG = new Color(45, 45, 45);
    private static final Color COLOR_SHADOW = new Color(0, 0, 0, 80);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_LABEL = new Font("Segoe UI", Font.PLAIN, 14);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 14);

    // --- Componentes ---
    private final TelaPrincipal telaPrincipal;
    private CameraPanel cameraPanel;
    private JTextField txtNomeCliente;
    private JTextField txtTelefoneCliente;
    private RoundedButton btnManual;
    private RoundedButton btnVeiculo;
    
    public TelaEntradaVeiculo(TelaPrincipal telaPrincipal) {
        this.telaPrincipal = telaPrincipal;
        setLayout(new GridBagLayout());
        setBackground(COLOR_BACKGROUND);
        JPanel painelCentralEstilizado = createStyledCentralPanel();
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(30, 30, 30, 30);
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        add(painelCentralEstilizado, gbc);
    }
    
    private void onCadastrarVeiculo() {
        if (cameraPanel.captureImage() == null) {
            DialogoCustomizado.mostrarMensagemErro(
                (Frame) SwingUtilities.getWindowAncestor(this),
                "Erro de Câmera",
                "Não foi possível capturar a imagem da placa."
            );
            return;
        }

        String nome = txtNomeCliente.getText();
        String telefone = txtTelefoneCliente.getText();
        
        setButtonsEnabled(false);
        btnVeiculo.setText("Processando...");

        SwingWorker<String, Void> worker = new SwingWorker<>() {
            @Override
            protected String doInBackground() throws ApiException {
                BufferedImage imagemOriginal = cameraPanel.captureImage();
                String placaReconhecida = ApiClient.reconhecerPlacaComPlateRecognizer(imagemOriginal);
                
                if (placaReconhecida == null || placaReconhecida.isBlank()) {
                    throw new ApiException("Nenhuma placa foi reconhecida pela API.");
                }
                
                String placaLimpa = placaReconhecida.trim().toUpperCase();
                
                if (!placaLimpa.matches("[A-Z]{3}[0-9]{4}") && !placaLimpa.matches("[A-Z]{3}[0-9][A-Z][0-9]{2}")) {
                    throw new ApiException("A placa reconhecida ('" + placaLimpa + "') tem um formato inválido.");
                }
                
                ApiClient.registrarEntradaManual(placaLimpa, nome, telefone);
                return placaLimpa;
            }

            @Override
            protected void done() {
                try {
                    String placaRegistrada = get();
                    DialogoCustomizado.mostrarMensagemSucesso(
                        (Frame) SwingUtilities.getWindowAncestor(TelaEntradaVeiculo.this),
                        "Sucesso",
                        "Entrada do veículo " + placaRegistrada + " registrada com sucesso!"
                    );
                    stopCamera();
                    telaPrincipal.trocarPainelCentral(new TelaGerenciarVeiculos(telaPrincipal));
                
                } catch (Exception e) {
                    Throwable cause = e.getCause(); 
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() : 
                            "Ocorreu um erro inesperado.";
                    
                    DialogoCustomizado.mostrarMensagemErro(
                        (Frame) SwingUtilities.getWindowAncestor(TelaEntradaVeiculo.this),
                        "Erro",
                        "Falha ao registrar entrada:\n" + errorMessage
                    );
                } finally {
                    setButtonsEnabled(true);
                    btnVeiculo.setText("Registrar por Imagem");
                }
            }
        };
        worker.execute();
    }
    
    private void setButtonsEnabled(boolean enabled) {
        btnManual.setEnabled(enabled);
        btnVeiculo.setEnabled(enabled);
    }

    public void stopCamera() {
        if (cameraPanel != null) {
            cameraPanel.stopCamera();
        }
    }
    
    /**
     * --- NOVO MÉTODO ---
     * Adicionado o mesmo método `loadIcon` da TelaPrincipal para carregar imagens.
     */
    private ImageIcon loadIcon(String path, int width, int height) {
        File file = new File(path);
        if (!file.exists()) {
            System.err.println("Imagem não encontrada: " + path);
            // Retorna um ícone vazio para não quebrar a UI
            return new ImageIcon(new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB));
        }
        ImageIcon icon = new ImageIcon(path);
        if (width > 0 && height > 0) {
            Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
            icon = new ImageIcon(img);
        }
        return icon;
    }

    private JPanel createStyledCentralPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(COLOR_SHADOW);
                g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 20, 20);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
            }
        };
        panel.setBackground(COLOR_PANEL);
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(25, 25, 25, 25));
        panel.add(createTitlePanel(), BorderLayout.NORTH);
        panel.add(createContentPanel(), BorderLayout.CENTER);
        panel.add(createButtonsPanel(), BorderLayout.SOUTH);
        return panel;
    }
    
    private JPanel createTitlePanel() {
        JPanel panelTitulo = new JPanel(new BorderLayout());
        panelTitulo.setOpaque(false);
        
        // --- CORREÇÃO APLICADA AQUI ---
        JLabel lblTitulo = new JLabel("Registrar Entrada de Veículo");
        lblTitulo.setIcon(loadIcon("src/imagens/add_car.png", 28, 28)); // Usa o ícone
        lblTitulo.setIconTextGap(10); // Espaço entre o ícone e o texto
        
        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        panelTitulo.add(lblTitulo, BorderLayout.WEST);
        
        JButton btnFechar = createIconButton("X", "Fechar");
        btnFechar.addActionListener(e -> {
            stopCamera();
            telaPrincipal.mostrarPainelInicial();
        });
        panelTitulo.add(btnFechar, BorderLayout.EAST);
        return panelTitulo;
    }
    
    private JPanel createContentPanel() {
        cameraPanel = new CameraPanel();
        JPanel formPanel = createFormPanel();
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, 
                cameraPanel, formPanel);
        splitPane.setOpaque(false);
        splitPane.setBorder(null);
        splitPane.setResizeWeight(0.70);
        splitPane.setDividerSize(6);
        splitPane.setEnabled(false);
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setOpaque(false);
        contentPanel.add(splitPane, BorderLayout.CENTER);
        return contentPanel;
    }
    
    private JPanel createFormPanel() {
        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));
        JLabel lblNome = new JLabel("Nome do Cliente");
        lblNome.setForeground(COLOR_TEXT_PRIMARY);
        lblNome.setFont(FONT_LABEL);
        lblNome.setAlignmentX(Component.LEFT_ALIGNMENT);
        txtNomeCliente = new StyledTextField();
        txtNomeCliente.setAlignmentX(Component.LEFT_ALIGNMENT);
        txtNomeCliente.setMaximumSize(new Dimension(Integer.MAX_VALUE, 
                txtNomeCliente.getPreferredSize().height + 10));
        JLabel lblTelefone = new JLabel("Telefone");
        lblTelefone.setForeground(COLOR_TEXT_PRIMARY);
        lblTelefone.setFont(FONT_LABEL);
        lblTelefone.setAlignmentX(Component.LEFT_ALIGNMENT);
        txtTelefoneCliente = new StyledTextField();
        txtTelefoneCliente.setAlignmentX(Component.LEFT_ALIGNMENT);
        txtTelefoneCliente.setMaximumSize(new Dimension(Integer.MAX_VALUE, 
                txtTelefoneCliente.getPreferredSize().height + 10));
        panel.add(lblNome);
        panel.add(Box.createRigidArea(new Dimension(0, 8)));
        panel.add(txtNomeCliente);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(lblTelefone);
        panel.add(Box.createRigidArea(new Dimension(0, 8)));
        panel.add(txtTelefoneCliente);
        panel.add(Box.createVerticalGlue());
        return panel;
    }
    
    private JPanel createButtonsPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panel.setOpaque(false);
        btnManual = new RoundedButton("Cadastrar Manualmente");
        btnManual.addActionListener(e -> {
            stopCamera();
            telaPrincipal.trocarPainelCentral(new TelaRegistroManual(telaPrincipal));
        });
        btnVeiculo = new RoundedButton("Registrar por Imagem");
        btnVeiculo.setBackground(COLOR_ORANGE_ACCENT);
        btnVeiculo.addActionListener(e -> onCadastrarVeiculo());
        panel.add(btnManual);
        panel.add(btnVeiculo);
        return panel;
    }
    
    private JButton createIconButton(String icon, String tooltip) {
        JButton button = new JButton(icon);
        button.setFont(new Font("Segoe UI Symbol", Font.BOLD, 16));
        button.setForeground(COLOR_TEXT_PRIMARY);
        button.setToolTipText(tooltip);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setContentAreaFilled(false);
        button.setBorder(null);
        button.setFocusPainted(false);
        return button;
    }
    
    private class StyledTextField extends JTextField {
        public StyledTextField() {
            super(20);
            setBackground(COLOR_INPUT_BG);
            setForeground(COLOR_TEXT_PRIMARY);
            setCaretColor(COLOR_TEXT_PRIMARY);
            setBorder(BorderFactory.createCompoundBorder(BorderFactory.
                    createLineBorder(COLOR_PANEL.brighter()), new EmptyBorder(8, 10, 8, 10)));
            setFont(new Font("Segoe UI", Font.PLAIN, 16));
        }
    }
    
    private class RoundedButton extends JButton {
        private Color defaultBg;
        private Color hoverBg;
        public RoundedButton(String text) {
            super(text);
            setFont(FONT_BUTTON);
            setForeground(Color.WHITE);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setFocusPainted(false);
            setBorder(new EmptyBorder(12, 25, 12, 25));
            setContentAreaFilled(false);
            this.defaultBg = COLOR_INPUT_BG;
            this.hoverBg = defaultBg.brighter();
            setBackground(defaultBg);
            addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    if (isEnabled()) {
                        setBackground(hoverBg);
                    }
                }
                public void mouseExited(java.awt.event.MouseEvent evt) {
                    setBackground(defaultBg);
                }
            });
        }
        @Override
        public void setBackground(Color bg) {
            if (bg != hoverBg) {
                this.defaultBg = bg;
                this.hoverBg = bg.brighter();
            }
            super.setBackground(bg);
        }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            if (getModel().isPressed()) {
                g2.setColor(getBackground().darker());
            }
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
            super.paintComponent(g2);
            g2.dispose();
        }
    }

    private class CameraPanel extends JPanel {
        private Webcam webcam;
        private volatile boolean running = true;
        private BufferedImage currentImage;
        private String statusMessage = "Iniciando câmera...";

        public CameraPanel() {
            setBackground(Color.BLACK);
            setBorder(BorderFactory.createLineBorder(COLOR_PANEL.brighter(), 2));
            new Thread(() -> {
                try {
                    Webcam webcamSelecionada = Webcam.getDefault();
                    if (webcamSelecionada == null) {
                        statusMessage = "Nenhuma câmera encontrada";
                        repaint();
                        return;
                    }
                    this.webcam = webcamSelecionada;
                    webcam.setViewSize(WebcamResolution.VGA.getSize());
                    webcam.open();
                    while (running) {
                        currentImage = webcam.getImage();
                        repaint();
                        try {
                            Thread.sleep(30);
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt(); 
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    statusMessage = "Erro ao iniciar câmera";
                    repaint();
                } finally {
                    if (webcam != null && webcam.isOpen()) {
                        webcam.close();
                    }
                }
            }).start();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setColor(Color.BLACK);
            g2d.fillRect(0, 0, getWidth(), getHeight());
            if (currentImage != null) {
                g2d.drawImage(currentImage, 0, 0, getWidth(), getHeight(), null);
            } else {
                g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2d.setColor(COLOR_TEXT_PRIMARY);
                g2d.setFont(new Font("Segoe UI", Font.BOLD, 14));
                FontMetrics fm = g2d.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(statusMessage)) / 2;
                int y = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
                g2d.drawString(statusMessage, x, y);
            }
            g2d.dispose();
        }

        public void stopCamera() {
            running = false;
        }

        public BufferedImage captureImage() {
            return currentImage;
        }
    }
}