package view;

import service.ApiClient;
import service.ApiException;
import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamResolution;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

/**
 * Painel (JPanel) que exibe a tela de registro de entrada de veículo.
 * <p>
 * Esta tela é responsável por capturar a imagem da webcam (via {@link CameraPanel}),
 * permitir a inserção de dados do cliente e, ao confirmar, enviar a imagem
 * para a API de reconhecimento (Plate Recognizer) e, em seguida, registrar
 * a entrada na API do sistema.
 */
public class TelaEntradaVeiculo extends JPanel {

    private static final Color COLOR_BACKGROUND = new Color(34, 40, 49);
    private static final Color COLOR_PANEL = new Color(57, 62, 70);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_ORANGE_ACCENT = new Color(255, 157, 8);
    private static final Color COLOR_INPUT_BG = new Color(45, 45, 45);
    private static final Color COLOR_SHADOW = new Color(0, 0, 0, 80);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_LABEL = new Font("Segoe UI", Font.PLAIN, 14);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 14);

    private final TelaPrincipal telaPrincipal;
    private CameraPanel cameraPanel;
    private JTextField txtNomeCliente;
    private JTextField txtTelefoneCliente;
    private RoundedButton btnManual;
    private RoundedButton btnVeiculo;

    /**
     * Constrói a tela de entrada de veículo.
     *
     * @param telaPrincipal A referência à janela principal (JFrame) da aplicação,
     * usada para navegação e como "pai" dos diálogos.
     */
    public TelaEntradaVeiculo(TelaPrincipal telaPrincipal) {
        this.telaPrincipal = telaPrincipal;
        setLayout(new GridBagLayout());
        setBackground(COLOR_BACKGROUND);
        JPanel painelCentralEstilizado = createStyledCentralPanel();
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(30, 30, 30, 30);
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        add(painelCentralEstilizado, gbc);
    }

    /**
     * Acionado pelo botão 'Registrar por Imagem'.
     * <p>
     * Este método inicia um {@link SwingWorker} para executar a
     * operação de reconhecimento e registro em background, evitando
     * que a UI trave.
     * <p>
     * 1. Captura a imagem da câmera.
     * 2. Envia para a API externa (Plate Recognizer).
     * 3. Valida o formato da placa recebida.
     * 4. Envia a placa validada e os dados do cliente para a API
     * do sistema (ApiClient.registrarEntradaManual).
     * 5. Exibe mensagens de sucesso ou erro.
     */
    private void onCadastrarVeiculo() {
        if (cameraPanel.captureImage() == null) {
            DialogoCustomizado.mostrarMensagemErro(
                    (Frame) SwingUtilities.getWindowAncestor(this),
                    "Erro de Câmera",
                    "Não foi possível capturar a imagem da placa."
            );
            return;
        }

        String nome = txtNomeCliente.getText();
        String telefone = txtTelefoneCliente.getText();

        setButtonsEnabled(false);
        btnVeiculo.setText("Processando...");

        SwingWorker<String, Void> worker = new SwingWorker<>() {
            @Override
            protected String doInBackground() throws ApiException {
                BufferedImage imagemOriginal = cameraPanel.captureImage();
                String placaReconhecida = ApiClient.reconhecerPlacaComPlateRecognizer(imagemOriginal);

                if (placaReconhecida == null || placaReconhecida.isBlank()) {
                    throw new ApiException("Nenhuma placa foi reconhecida pela API.");
                }

                String placaLimpa = placaReconhecida.trim().toUpperCase();

                if (!placaLimpa.matches("[A-Z]{3}[0-9]{4}") && !placaLimpa.matches("[A-Z]{3}[0-9][A-Z][0-9]{2}")) {
                    throw new ApiException("A placa reconhecida ('" + placaLimpa + "') tem um formato inválido.");
                }

                ApiClient.registrarEntradaManual(placaLimpa, nome, telefone);
                return placaLimpa;
            }

            @Override
            protected void done() {
                try {
                    String placaRegistrada = get();
                    DialogoCustomizado.mostrarMensagemSucesso(
                            (Frame) SwingUtilities.getWindowAncestor(TelaEntradaVeiculo.this),
                            "Sucesso",
                            "Entrada do veículo " + placaRegistrada + " registrada com sucesso!"
                    );
                    stopCamera();
                    telaPrincipal.trocarPainelCentral(new TelaGerenciarVeiculos(telaPrincipal));

                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() :
                            "Ocorreu um erro inesperado.";

                    DialogoCustomizado.mostrarMensagemErro(
                            (Frame) SwingUtilities.getWindowAncestor(TelaEntradaVeiculo.this),
                            "Erro",
                            "Falha ao registrar entrada:\n" + errorMessage
                    );
                } finally {
                    setButtonsEnabled(true);
                    btnVeiculo.setText("Registrar por Imagem");
                }
            }
        };
        worker.execute();
    }

    /**
     * Habilita ou desabilita os botões de ação ('Cadastrar Manualmente'
     * e 'Registrar por Imagem') durante o processamento.
     *
     * @param enabled {@code true} para habilitar, {@code false} para desabilitar.
     */
    private void setButtonsEnabled(boolean enabled) {
        btnManual.setEnabled(enabled);
        btnVeiculo.setEnabled(enabled);
    }

    /**
     * Para o feed da câmera e libera o recurso.
     * Este método é chamado ao fechar a tela ou trocar de painel.
     */
    public void stopCamera() {
        if (cameraPanel != null) {
            cameraPanel.stopCamera();
        }
    }

    /**
     * Carrega um ImageIcon a partir de um caminho de arquivo, com redimensionamento.
     *
     * @param path   O caminho (relativo ou absoluto) para o arquivo de imagem.
     * @param width  A largura desejada para a imagem.
     * @param height A altura desejada para a imagem.
     * @return O ImageIcon redimensionado, ou um ícone em branco se
     * o arquivo não for encontrado.
     */
    private ImageIcon loadIcon(String path, int width, int height) {
        File file = new File(path);
        if (!file.exists()) {
            System.err.println("Imagem não encontrada: " + path);
            return new ImageIcon(new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB));
        }
        ImageIcon icon = new ImageIcon(path);
        if (width > 0 && height > 0) {
            Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
            icon = new ImageIcon(img);
        }
        return icon;
    }

    /**
     * Cria o painel central estilizado (com sombra e cantos arredondados)
     * que contém o título, o conteúdo (câmera e formulário) e os botões.
     *
     * @return O JPanel central estilizado.
     */
    private JPanel createStyledCentralPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15)) {
            /**
             * Sobrescrito para desenhar uma sombra e cantos arredondados.
             *
             * @param g O contexto gráfico.
             */
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(COLOR_SHADOW);
                g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 20, 20);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
            }
        };
        panel.setBackground(COLOR_PANEL);
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(25, 25, 25, 25));
        panel.add(createTitlePanel(), BorderLayout.NORTH);
        panel.add(createContentPanel(), BorderLayout.CENTER);
        panel.add(createButtonsPanel(), BorderLayout.SOUTH);
        return panel;
    }

    /**
     * Cria o painel de cabeçalho, que inclui o título com ícone e
     * o botão de fechar.
     *
     * @return Um JPanel contendo o cabeçalho da tela.
     */
    private JPanel createTitlePanel() {
        JPanel panelTitulo = new JPanel(new BorderLayout());
        panelTitulo.setOpaque(false);

        JLabel lblTitulo = new JLabel("Registrar Entrada de Veículo");
        lblTitulo.setIcon(loadIcon("src/imagens/add_car.png", 28, 28));
        lblTitulo.setIconTextGap(10);

        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        panelTitulo.add(lblTitulo, BorderLayout.WEST);

        JButton btnFechar = createIconButton("X", "Fechar");
        btnFechar.addActionListener(e -> {
            stopCamera();
            telaPrincipal.mostrarPainelInicial();
        });
        panelTitulo.add(btnFechar, BorderLayout.EAST);
        return panelTitulo;
    }

    /**
     * Cria o painel de conteúdo principal.
     * Utiliza um {@link JSplitPane} para dividir a tela entre
     * o {@link CameraPanel} e o formulário de dados do cliente.
     *
     * @return Um JPanel contendo o JSplitPane.
     */
    private JPanel createContentPanel() {
        cameraPanel = new CameraPanel();
        JPanel formPanel = createFormPanel();
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                cameraPanel, formPanel);
        splitPane.setOpaque(false);
        splitPane.setBorder(null);
        splitPane.setResizeWeight(0.70);
        splitPane.setDividerSize(6);
        splitPane.setEnabled(false);
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setOpaque(false);
        contentPanel.add(splitPane, BorderLayout.CENTER);
        return contentPanel;
    }

    /**
     * Cria o painel de formulário lateral para inserção de dados
     * (Nome do Cliente e Telefone).
     *
     * @return Um JPanel contendo o formulário.
     */
    private JPanel createFormPanel() {
        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));
        JLabel lblNome = new JLabel("Nome do Cliente");
        lblNome.setForeground(COLOR_TEXT_PRIMARY);
        lblNome.setFont(FONT_LABEL);
        lblNome.setAlignmentX(Component.LEFT_ALIGNMENT);
        txtNomeCliente = new StyledTextField();
        txtNomeCliente.setAlignmentX(Component.LEFT_ALIGNMENT);
        txtNomeCliente.setMaximumSize(new Dimension(Integer.MAX_VALUE,
                txtNomeCliente.getPreferredSize().height + 10));
        JLabel lblTelefone = new JLabel("Telefone");
        lblTelefone.setForeground(COLOR_TEXT_PRIMARY);
        lblTelefone.setFont(FONT_LABEL);
        lblTelefone.setAlignmentX(Component.LEFT_ALIGNMENT);
        txtTelefoneCliente = new StyledTextField();
        txtTelefoneCliente.setAlignmentX(Component.LEFT_ALIGNMENT);
        txtTelefoneCliente.setMaximumSize(new Dimension(Integer.MAX_VALUE,
                txtTelefoneCliente.getPreferredSize().height + 10));
        panel.add(lblNome);
        panel.add(Box.createRigidArea(new Dimension(0, 8)));
        panel.add(txtNomeCliente);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(lblTelefone);
        panel.add(Box.createRigidArea(new Dimension(0, 8)));
        panel.add(txtTelefoneCliente);
        panel.add(Box.createVerticalGlue());
        return panel;
    }

    /**
     * Cria o painel de botões de ação na parte inferior da tela.
     *
     * @return Um JPanel contendo os botões de ação.
     */
    private JPanel createButtonsPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panel.setOpaque(false);
        btnManual = new RoundedButton("Cadastrar Manualmente");
        btnManual.addActionListener(e -> {
            stopCamera();
            telaPrincipal.trocarPainelCentral(new TelaRegistroManual(telaPrincipal));
        });
        btnVeiculo = new RoundedButton("Registrar por Imagem");
        btnVeiculo.setBackground(COLOR_ORANGE_ACCENT);
        btnVeiculo.addActionListener(e -> onCadastrarVeiculo());
        panel.add(btnManual);
        panel.add(btnVeiculo);
        return panel;
    }

    /**
     * Cria um botão de ícone (texto) estilizado, sem borda e com tooltip.
     *
     * @param icon    O texto/ícone (ex: "X", "🔄").
     * @param tooltip O texto a ser exibido no tooltip.
     * @return Um JButton estilizado como ícone.
     */
    private JButton createIconButton(String icon, String tooltip) {
        JButton button = new JButton(icon);
        button.setFont(new Font("Segoe UI Symbol", Font.BOLD, 16));
        button.setForeground(COLOR_TEXT_PRIMARY);
        button.setToolTipText(tooltip);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setContentAreaFilled(false);
        button.setBorder(null);
        button.setFocusPainted(false);
        return button;
    }

    /**
     * Classe interna (private) que representa um JTextField com o
     * estilo "dark" padrão da aplicação.
     */
    private class StyledTextField extends JTextField {
        /**
         * Construtor do StyledTextField.
         * Aplica as cores, fontes e bordas do tema.
         */
        public StyledTextField() {
            super(20);
            setBackground(COLOR_INPUT_BG);
            setForeground(COLOR_TEXT_PRIMARY);
            setCaretColor(COLOR_TEXT_PRIMARY);
            setBorder(BorderFactory.createCompoundBorder(BorderFactory.
                    createLineBorder(COLOR_PANEL.brighter()), new EmptyBorder(8, 10, 8, 10)));
            setFont(new Font("Segoe UI", Font.PLAIN, 16));
        }
    }

    /**
     * Classe interna (private) que representa um JButton customizado
     * com cantos arredondados e efeitos de "hover".
     */
    private class RoundedButton extends JButton {
        private Color defaultBg;
        private Color hoverBg;

        /**
         * Construtor do botão arredondado.
         * Configura a aparência e adiciona listeners de mouse para o efeito hover.
         *
         * @param text O texto a ser exibido no botão.
         */
        public RoundedButton(String text) {
            super(text);
            setFont(FONT_BUTTON);
            setForeground(Color.WHITE);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setFocusPainted(false);
            setBorder(new EmptyBorder(12, 25, 12, 25));
            setContentAreaFilled(false);
            this.defaultBg = COLOR_INPUT_BG;
            this.hoverBg = defaultBg.brighter();
            setBackground(defaultBg);
            addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    if (isEnabled()) {
                        setBackground(hoverBg);
                    }
                }

                public void mouseExited(java.awt.event.MouseEvent evt) {
                    setBackground(defaultBg);
                }
            });
        }

        /**
         * Sobrescrito para atualizar as cores de 'default' e 'hover'
         * quando a cor de fundo é alterada programaticamente.
         *
         * @param bg A nova cor de fundo.
         */
        @Override
        public void setBackground(Color bg) {
            if (bg != hoverBg) {
                this.defaultBg = bg;
                this.hoverBg = bg.brighter();
            }
            super.setBackground(bg);
        }

        /**
         * Sobrescreve o método de pintura para desenhar o fundo arredondado.
         * Usa Graphics2D para preencher um 'RoundRect' com antialias.
         *
         * @param g O contexto gráfico fornecido pelo Swing.
         */
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            if (getModel().isPressed()) {
                g2.setColor(getBackground().darker());
            }
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
            super.paintComponent(g2);
            g2.dispose();
        }
    }

    /**
     * Classe interna (private) que gerencia o feed da webcam.
     * <p>
     * Inicializa a webcam em uma thread separada e atualiza continuamente
     * a imagem a ser exibida, desenhando-a no método {@link #paintComponent}.
     */
    private class CameraPanel extends JPanel {
        private Webcam webcam;
        private volatile boolean running = true;
        private BufferedImage currentImage;
        private String statusMessage = "Iniciando câmera...";

        /**
         * Construtor do painel da câmera.
         * <p>
         * Busca a webcam padrão, a inicializa em uma nova thread e
         * inicia o loop de captura de imagem. Exibe mensagens de
         * status ("Iniciando...", "Nenhuma câmera encontrada", etc.).
         */
        public CameraPanel() {
            setBackground(Color.BLACK);
            setBorder(BorderFactory.createLineBorder(COLOR_PANEL.brighter(), 2));
            new Thread(() -> {
                try {
                    Webcam webcamSelecionada = Webcam.getDefault();
                    if (webcamSelecionada == null) {
                        statusMessage = "Nenhuma câmera encontrada";
                        repaint();
                        return;
                    }
                    this.webcam = webcamSelecionada;
                    webcam.setViewSize(WebcamResolution.VGA.getSize());
                    webcam.open();
                    while (running) {
                        currentImage = webcam.getImage();
                        repaint();
                        try {
                            Thread.sleep(30);
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    statusMessage = "Erro ao iniciar câmera";
                    repaint();
                } finally {
                    if (webcam != null && webcam.isOpen()) {
                        webcam.close();
                    }
                }
            }).start();
        }

        /**
         * Sobrescreve o método de pintura para desenhar o feed da câmera.
         * <p>
         * Desenha a imagem mais recente capturada pela webcam ({@code currentImage})
         * ou, se a imagem não estiver disponível, desenha a
         * {@code statusMessage} centralizada.
         *
         * @param g O contexto gráfico fornecido pelo Swing.
         */
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setColor(Color.BLACK);
            g2d.fillRect(0, 0, getWidth(), getHeight());
            if (currentImage != null) {
                g2d.drawImage(currentImage, 0, 0, getWidth(), getHeight(), null);
            } else {
                g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2d.setColor(COLOR_TEXT_PRIMARY);
                g2d.setFont(new Font("Segoe UI", Font.BOLD, 14));
                FontMetrics fm = g2d.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(statusMessage)) / 2;
                int y = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
                g2d.drawString(statusMessage, x, y);
            }
            g2d.dispose();
        }

        /**
         * Sinaliza para a thread da câmera parar (alterando a flag 'running')
         * e, assim, fechar a webcam e encerrar a thread.
         */
        public void stopCamera() {
            running = false;
        }

        /**
         * Retorna a imagem mais recente capturada pela câmera.
         *
         * @return A {@link BufferedImage} mais recente, ou {@code null}
         * se a câmera não estiver pronta.
         */
        public BufferedImage captureImage() {
            return currentImage;
        }
    }
}