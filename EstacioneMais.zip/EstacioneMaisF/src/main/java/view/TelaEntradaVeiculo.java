package view;

import service.ApiClient;
import service.ApiException;
import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamResolution;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * Painel para registrar a entrada de veículos utilizando uma webcam para
 * reconhecimento automático de placas.
 */
public class TelaEntradaVeiculo extends JPanel {

    // --- Constantes de Estilo ---
    private static final Color COLOR_BACKGROUND = new Color(34, 40, 49);
    private static final Color COLOR_PANEL = new Color(57, 62, 70);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_ORANGE_ACCENT = new Color(255, 157, 8);
    private static final Color COLOR_INPUT_BG = new Color(45, 45, 45);
    private static final Color COLOR_SHADOW = new Color(0, 0, 0, 80);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_LABEL = new Font("Segoe UI", Font.PLAIN, 14);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 14);

    // --- Componentes ---
    private final TelaPrincipal telaPrincipal;
    private CameraPanel cameraPanel;
    private JTextField txtNomeCliente;
    private JTextField txtTelefoneCliente;
    private RoundedButton btnManual;
    private RoundedButton btnVeiculo;
    
    /**
     * Construtor da tela de entrada. Monta a interface gráfica, incluindo
     * o painel da câmera e o formulário de dados do cliente.
     */
    public TelaEntradaVeiculo(TelaPrincipal telaPrincipal) {
        this.telaPrincipal = telaPrincipal;
        setLayout(new GridBagLayout());
        setBackground(COLOR_BACKGROUND);
        JPanel painelCentralEstilizado = createStyledCentralPanel();
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(30, 30, 30, 30);
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        add(painelCentralEstilizado, gbc);
    }
    
    /**
     * Inicia o processo de registro de veículo por imagem.
     * Captura a imagem, envia para a API de reconhecimento, valida a placa e,
     * por fim, registra a entrada no sistema. Todo o processo é assíncrono.
     */
    private void onCadastrarVeiculo() {
        if (cameraPanel.captureImage() == null) {
            DialogoCustomizado.mostrarMensagemErro(
                (Frame) SwingUtilities.getWindowAncestor(this),
                "Erro de Câmera",
                "Não foi possível capturar a imagem da placa."
            );
            return;
        }

        String nome = txtNomeCliente.getText();
        String telefone = txtTelefoneCliente.getText();
        
        // Desabilita os botões para evitar cliques múltiplos durante o processamento.
        setButtonsEnabled(false);
        btnVeiculo.setText("Processando...");

        SwingWorker<String, Void> worker = new SwingWorker<>() {
            /**
             * Executa em background: captura a imagem, chama a API de reconhecimento,
             * valida o formato da placa e registra a entrada no back-end.
             */
            @Override
            protected String doInBackground() throws ApiException {
                BufferedImage imagemOriginal = cameraPanel.captureImage();
                String placaReconhecida = ApiClient.reconhecerPlacaComPlateRecognizer(imagemOriginal);
                
                if (placaReconhecida == null || placaReconhecida.isBlank()) {
                    throw new ApiException("Nenhuma placa foi reconhecida pela API.");
                }
                
                String placaLimpa = placaReconhecida.trim().toUpperCase();
                
                if (!placaLimpa.matches("[A-Z]{3}[0-9]{4}") && !placaLimpa.matches("[A-Z]{3}[0-9][A-Z][0-9]{2}")) {
                    throw new ApiException("A placa reconhecida ('" + placaLimpa + "') tem um formato inválido.");
                }
                
                ApiClient.registrarEntradaCamera(placaLimpa, nome, telefone);
                return placaLimpa;
            }

            /**
             * Executado na thread do Swing após o fim da tarefa.
             * Atualiza a UI com o resultado (sucesso ou erro) e navega para outra tela.
             */
            @Override
            protected void done() {
                try {
                    String placaRegistrada = get();
                    DialogoCustomizado.mostrarMensagemSucesso(
                        (Frame) SwingUtilities.getWindowAncestor(TelaEntradaVeiculo.this),
                        "Sucesso",
                        "Entrada do veículo " + placaRegistrada + " registrada com sucesso!"
                    );
                    stopCamera(); // Libera o recurso da câmera
                    telaPrincipal.trocarPainelCentral(new TelaGerenciarVeiculos(telaPrincipal));
                
                } catch (Exception e) {
                    Throwable cause = e.getCause(); 
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() : 
                            "Ocorreu um erro inesperado.";
                    
                    DialogoCustomizado.mostrarMensagemErro(
                        (Frame) SwingUtilities.getWindowAncestor(TelaEntradaVeiculo.this),
                        "Erro",
                        "Falha ao registrar entrada:\n" + errorMessage
                    );
                } finally {
                    // Garante que os botões sejam reativados, independente de sucesso ou falha.
                    setButtonsEnabled(true);
                    btnVeiculo.setText("✔ Registrar por Imagem");
                }
            }
        };
        worker.execute();
    }
    
    /**
     * Habilita ou desabilita os principais botões de ação da tela.
     */
    private void setButtonsEnabled(boolean enabled) {
        btnManual.setEnabled(enabled);
        btnVeiculo.setEnabled(enabled);
    }

    /**
     * Interrompe a execução da câmera de forma segura. Essencial para ser chamado
     * ao fechar ou navegar para fora desta tela, liberando o hardware.
     */
    public void stopCamera() {
        if (cameraPanel != null) {
            cameraPanel.stopCamera();
        }
    }

    private JPanel createStyledCentralPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
                        RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(COLOR_SHADOW);
                g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 20, 20);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
            }
        };
        panel.setBackground(COLOR_PANEL);
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(25, 25, 25, 25));
        panel.add(createTitlePanel(), BorderLayout.NORTH);
        panel.add(createContentPanel(), BorderLayout.CENTER);
        panel.add(createButtonsPanel(), BorderLayout.SOUTH);
        return panel;
    }
    private JPanel createTitlePanel() {
        JPanel panelTitulo = new JPanel(new BorderLayout());
        panelTitulo.setOpaque(false);
        JLabel lblTitulo = new JLabel("📸 Registrar Entrada de Veículo");
        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        panelTitulo.add(lblTitulo, BorderLayout.WEST);
        JButton btnFechar = createIconButton("X", "Fechar");
        btnFechar.addActionListener(e -> {
            stopCamera();
            telaPrincipal.mostrarPainelInicial();
        });
        panelTitulo.add(btnFechar, BorderLayout.EAST);
        return panelTitulo;
    }
    private JPanel createContentPanel() {
        cameraPanel = new CameraPanel();
        JPanel formPanel = createFormPanel();
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, 
                cameraPanel, formPanel);
        splitPane.setOpaque(false);
        splitPane.setBorder(null);
        splitPane.setResizeWeight(0.70);
        splitPane.setDividerSize(6);
        splitPane.setEnabled(false);
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setOpaque(false);
        contentPanel.add(splitPane, BorderLayout.CENTER);
        return contentPanel;
    }
    private JPanel createFormPanel() {
        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));
        JLabel lblNome = new JLabel("Nome do Cliente");
        lblNome.setForeground(COLOR_TEXT_PRIMARY);
        lblNome.setFont(FONT_LABEL);
        lblNome.setAlignmentX(Component.LEFT_ALIGNMENT);
        txtNomeCliente = new StyledTextField();
        txtNomeCliente.setAlignmentX(Component.LEFT_ALIGNMENT);
        txtNomeCliente.setMaximumSize(new Dimension(Integer.MAX_VALUE, 
                txtNomeCliente.getPreferredSize().height + 10));
        JLabel lblTelefone = new JLabel("Telefone");
        lblTelefone.setForeground(COLOR_TEXT_PRIMARY);
        lblTelefone.setFont(FONT_LABEL);
        lblTelefone.setAlignmentX(Component.LEFT_ALIGNMENT);
        txtTelefoneCliente = new StyledTextField();
        txtTelefoneCliente.setAlignmentX(Component.LEFT_ALIGNMENT);
        txtTelefoneCliente.setMaximumSize(new Dimension(Integer.MAX_VALUE, 
                txtTelefoneCliente.getPreferredSize().height + 10));
        panel.add(lblNome);
        panel.add(Box.createRigidArea(new Dimension(0, 8)));
        panel.add(txtNomeCliente);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(lblTelefone);
        panel.add(Box.createRigidArea(new Dimension(0, 8)));
        panel.add(txtTelefoneCliente);
        panel.add(Box.createVerticalGlue());
        return panel;
    }
    private JPanel createButtonsPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panel.setOpaque(false);
        btnManual = new RoundedButton("Cadastrar Manualmente");
        btnManual.addActionListener(e -> {
            stopCamera();
            telaPrincipal.trocarPainelCentral(new TelaRegistroManual(telaPrincipal));
        });
        btnVeiculo = new RoundedButton("✔ Registrar por Imagem");
        btnVeiculo.setBackground(COLOR_ORANGE_ACCENT);
        btnVeiculo.addActionListener(e -> onCadastrarVeiculo());
        panel.add(btnManual);
        panel.add(btnVeiculo);
        return panel;
    }
    private JButton createIconButton(String icon, String tooltip) {
        JButton button = new JButton(icon);
        button.setFont(new Font("Segoe UI Symbol", Font.BOLD, 16));
        button.setForeground(COLOR_TEXT_PRIMARY);
        button.setToolTipText(tooltip);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setContentAreaFilled(false);
        button.setBorder(null);
        button.setFocusPainted(false);
        return button;
    }
    private class StyledTextField extends JTextField {
        public StyledTextField() {
            super(20);
            setBackground(COLOR_INPUT_BG);
            setForeground(COLOR_TEXT_PRIMARY);
            setCaretColor(COLOR_TEXT_PRIMARY);
            setBorder(BorderFactory.createCompoundBorder(BorderFactory.
                    createLineBorder(COLOR_PANEL.brighter()), new EmptyBorder(8, 10, 8, 10)));
            setFont(new Font("Segoe UI", Font.PLAIN, 16));
        }
    }
    private class RoundedButton extends JButton {
        private Color defaultBg;
        private Color hoverBg;
        public RoundedButton(String text) {
            super(text);
            setFont(FONT_BUTTON);
            setForeground(Color.WHITE);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setFocusPainted(false);
            setBorder(new EmptyBorder(12, 25, 12, 25));
            setContentAreaFilled(false);
            this.defaultBg = COLOR_INPUT_BG;
            this.hoverBg = defaultBg.brighter();
            setBackground(defaultBg);
            addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    if (isEnabled()) {
                        setBackground(hoverBg);
                    }
                }
                public void mouseExited(java.awt.event.MouseEvent evt) {
                    setBackground(defaultBg);
                }
            });
        }
        @Override
        public void setBackground(Color bg) {
            if (bg != hoverBg) {
                this.defaultBg = bg;
                this.hoverBg = bg.brighter();
            }
            super.setBackground(bg);
        }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            if (getModel().isPressed()) {
                g2.setColor(getBackground().darker());
            }
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
            super.paintComponent(g2);
            g2.dispose();
        }
    }

    /**
     * Um painel dedicado a gerenciar e exibir o feed da webcam.
     * Ele opera em uma thread separada para não bloquear a interface gráfica do Swing.
     */
    private class CameraPanel extends JPanel {
        private Webcam webcam;
        private volatile boolean running = true;
        private BufferedImage currentImage;
        private String statusMessage = "Iniciando câmera...";

        /**
         * Construtor do painel da câmera. Inicia uma nova thread para
         * encontrar a webcam, abrir o feed e atualizar a imagem continuamente.
         */
        public CameraPanel() {
            setBackground(Color.BLACK);
            setBorder(BorderFactory.createLineBorder(COLOR_PANEL.brighter(), 2));
            new Thread(() -> {
                try {
                    Webcam webcamSelecionada = Webcam.getDefault();
                    if (webcamSelecionada == null) {
                        statusMessage = "Nenhuma câmera encontrada";
                        repaint();
                        return;
                    }
                    this.webcam = webcamSelecionada;
                    webcam.setViewSize(WebcamResolution.VGA.getSize());
                    webcam.open();
                    // Loop principal que captura frames da câmera
                    while (running) {
                        currentImage = webcam.getImage();
                        repaint(); // Pede para o painel se redesenhar com a nova imagem
                        try {
                            Thread.sleep(30); // Controla a taxa de frames
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt(); 
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    statusMessage = "Erro ao iniciar câmera";
                    repaint();
                } finally {
                    if (webcam != null && webcam.isOpen()) {
                        webcam.close(); // Garante que a câmera seja liberada
                    }
                }
            }).start();
        }

        /**
         * Sobrescrito para desenhar a imagem atual da câmera no painel.
         * Se a câmera não estiver funcionando, exibe uma mensagem de status.
         */
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setColor(Color.BLACK);
            g2d.fillRect(0, 0, getWidth(), getHeight());
            if (currentImage != null) {
                g2d.drawImage(currentImage, 0, 0, getWidth(), getHeight(), null);
            } else {
                g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2d.setColor(COLOR_TEXT_PRIMARY);
                g2d.setFont(new Font("Segoe UI", Font.BOLD, 14));
                FontMetrics fm = g2d.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(statusMessage)) / 2;
                int y = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
                g2d.drawString(statusMessage, x, y);
            }
            g2d.dispose();
        }

        /**
         * Sinaliza para a thread da câmera que ela deve parar de executar e liberar o dispositivo.
         */
        public void stopCamera() {
            running = false;
        }

        /**
         * Retorna a última imagem capturada pela câmera.
         * @return A imagem mais recente como um BufferedImage.
         */
        public BufferedImage captureImage() {
            return currentImage;
        }
    }
}