package com.estacioneMais.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Entidade JPA que representa a configuração do total de vagas
 * disponíveis no estacionamento.
 * <p>
 * Esta tabela armazena o registro que define a capacidade
 * máxima do pátio (o número total de vagas).
 */
@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "vagas_disp")
public class VagasDisp {

    /**
     * Identificador único (chave primária) da configuração de vagas.
     * Gerado automaticamente pelo banco de dados (IDENTITY).
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * O número total de vagas que o estacionamento possui.
     * Este valor é usado como base para calcular as vagas disponíveis
     * (Total - Ocupadas).
     */
    @Column(name = "total_vagas", nullable = false)
    private int totalVagas;
}