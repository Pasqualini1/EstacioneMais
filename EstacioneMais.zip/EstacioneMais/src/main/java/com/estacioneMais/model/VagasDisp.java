package com.estacioneMais.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
// Diz ao Hibernate para criar uma tabela chamada "vagas_disp"
@Table(name = "vagas_disp")
public class VagasDisp {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "total_vagas", nullable = false)
    private int totalVagas;
}