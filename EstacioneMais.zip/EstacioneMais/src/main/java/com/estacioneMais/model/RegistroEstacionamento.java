package com.estacioneMais.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDateTime;

/*
 * Entidade JPA que representa um registro de estacionamento no banco de dados.
 * Cada instância desta classe corresponde a uma linha na tabela "registro_estacionamento".
 * Ela armazena o histórico de entrada e saída de um veículo específico.
 *
 * As anotações do Lombok (@Getter, @Setter, @NoArgsConstructor) são usadas para
 * gerar automaticamente os métodos básicos, reduzindo a verbosidade do código.
 */
@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "registro_estacionamento")
public class RegistroEstacionamento {

    /*
     * Identificador único (chave primária) do registro.
     * A estratégia GenerationType.IDENTITY indica que o próprio banco de dados
     * se encarregará de gerar e auto-incrementar este valor.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /*
     * Armazena a data e a hora exatas em que o veículo entrou no estacionamento.
     * O campo é mapeado para a coluna "horario_entrada" e não pode ser nulo.
     */
    @Column(name = "horario_entrada", nullable = false)
    private LocalDateTime horarioEntrada;

    /*
     * Armazena a data e a hora exatas em que o veículo saiu do estacionamento.
     * Este campo pode ser nulo, indicando que o veículo ainda está no pátio.
     */
    @Column(name = "horario_saida")
    private LocalDateTime horarioSaida;

    /*
     * Define o relacionamento com a entidade Veiculo.
     * A anotação @ManyToOne indica que muitos registros de estacionamento podem
     * estar associados a um único veículo.
     * O 'fetch = FetchType.LAZY' é uma otimização que faz com que os dados do veículo
     * associado só sejam carregados do banco de dados quando forem realmente necessários.
     * A @JoinColumn especifica que a chave estrangeira na tabela "registro_estacionamento"
     * se chamará "veiculo_id".
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "veiculo_id", nullable = false)
    private Veiculo veiculo;
}