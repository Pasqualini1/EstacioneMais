package com.estacioneMais.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Entidade JPA que representa um registro individual de estadia no estacionamento.
 * <p>
 * Cada instância desta classe corresponde a uma "visita" de um veículo,
 * armazenando quando ele entrou, quando saiu e o valor cobrado.
 * É o coração do histórico e dos relatórios.
 */
@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "registro_estacionamento")
public class RegistroEstacionamento {

    /**
     * Identificador único (chave primária) do registro de estacionamento.
     * Gerado automaticamente pelo banco de dados (IDENTITY).
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Data e hora exata em que o veículo entrou no estacionamento.
     * Campo obrigatório.
     */
    @Column(name = "horario_entrada", nullable = false)
    private LocalDateTime horarioEntrada;

    /**
     * Data e hora exata em que o veículo saiu do estacionamento.
     * Este campo permanece nulo enquanto o veículo estiver no pátio (ativo).
     */
    @Column(name = "horario_saida")
    private LocalDateTime horarioSaida;

    /**
     * Valor total final calculado e cobrado pela estadia.
     * Este campo é preenchido no momento do registro da saída.
     */
    @Column(name = "valor_total")
    private BigDecimal valorTotal;

    /**
     * Associação (Many-to-One) com a entidade Veiculo.
     * Indica qual veículo está associado a este registro de estacionamento.
     * O 'FetchType.LAZY' otimiza a performance, carregando o veículo
     * do banco de dados apenas quando ele for explicitamente solicitado.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "veiculo_id", nullable = false)
    private Veiculo veiculo;
}