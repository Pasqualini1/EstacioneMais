package com.estacioneMais.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.ArrayList;
import java.util.List;

/*
 * Entidade JPA que representa um veículo no sistema.
 * Esta classe mapeia a tabela "veiculo" no banco de dados e armazena as
 * informações cadastrais de cada veículo, como placa, modelo e dados do cliente.
 *
 * As anotações do Lombok (@Getter, @Setter, @NoArgsConstructor) são usadas para
 * gerar automaticamente os métodos de acesso e um construtor padrão, simplificando o código.
 */
@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "veiculo")
public class Veiculo {

    /*
     * Identificador único (chave primária) do veículo.
     * Gerado automaticamente pelo banco de dados (auto-incremento).
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /*
     * Placa do veículo. É o identificador de negócio principal.
     * A anotação @Column define que a placa não pode ser nula e deve ser única
     * no banco de dados, evitando o cadastro de veículos duplicados.
     */
    @Column(name = "placa", nullable = false, unique = true)
    private String placa;

    /*
     * Modelo do veículo (ex: "Fiat Uno", "Honda Civic"). Campo opcional.
     */
    @Column(name = "modelo")
    private String modelo;

    /*
     * Cor do veículo. Campo opcional.
     */
    @Column(name = "cor")
    private String cor;

    /*
     * Ano de fabricação do veículo. Campo opcional.
     */
    @Column(name = "ano")
    private Integer ano;

    /*
     * Nome do cliente ou proprietário do veículo. Campo obrigatório.
     */
    @Column(name = "nome_cliente", nullable = false)
    private String nomeCliente;

    /*
     * Telefone de contato do cliente. Campo opcional.
     */
    @Column(name = "telefone_cliente")
    private String telefoneCliente;

    /*
     * Lista de todos os registros de estacionamento associados a este veículo.
     * A anotação @OneToMany estabelece um relacionamento "um-para-muitos": um veículo
     * pode ter muitos registros de estacionamento.
     * - mappedBy = "veiculo": Indica que a entidade RegistroEstacionamento é a "dona"
     * deste relacionamento (ela possui a chave estrangeira 'veiculo_id').
     * - cascade = CascadeType.ALL: Faz com que as operações (salvar, deletar, etc.)
     * realizadas no Veiculo sejam propagadas para seus registros associados.
     * - orphanRemoval = true: Garante que se um registro for removido desta lista,
     * ele também será removido do banco de dados.
     */
    @OneToMany(mappedBy = "veiculo", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<RegistroEstacionamento> registros = new ArrayList<>();
}