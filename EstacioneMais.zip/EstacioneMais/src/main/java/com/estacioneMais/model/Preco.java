package com.estacioneMais.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;

/**
 * Entidade JPA que representa a regra de precificação do estacionamento.
 * <p>
 * Esta tabela armazena o valor da cobrança (ex: R$ 5,00) e a fração de
 * tempo correspondente (ex: 30 minutos) que são usados como base
 * para o cálculo total da estadia.
 */
@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "preco")
public class Preco {

    /**
     * Identificador único (chave primária) da regra de preço.
     * Gerado automaticamente pelo banco de dados (IDENTITY).
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * O valor (ex: 5.00) a ser cobrado por cada fração de tempo.
     */
    @Column(name = "preco_valor", nullable = false)
    private BigDecimal precoValor;

    /**
     * A quantidade de minutos (ex: 30) que compõe a fração de cobrança.
     */
    @Column(name = "preco_minutos", nullable = false)
    private int precoMinutos;
}