package com.estacioneMais.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO (Data Transfer Object) para representar o status de um único veículo
 * que está atualmente no pátio.
 * <p>
 * Usado para exibir informações resumidas (como no modal de status)
 * de um veículo ativo, incluindo o tempo decorrido e o valor atual.
 *
 * @param placa             Placa do veículo.
 * @param nomeCliente       Nome do cliente associado.
 * @param telefoneCliente   Telefone do cliente.
 * @param modelo            Modelo do veículo.
 * @param cor               Cor do veículo.
 * @param horarioEntrada    Data e hora exata da entrada.
 * @param tempoEstacionado  Tempo formatado da estadia (ex: "2h 30m").
 * @param valorAtual        Valor calculado da estadia até o momento atual.
 */
public record VeiculoStatusDTO(
        String placa,
        String nomeCliente,
        String telefoneCliente,
        String modelo,
        String cor,
        LocalDateTime horarioEntrada,
        String tempoEstacionado,
        BigDecimal valorAtual
) {}