package com.estacioneMais.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

/*
 * DTO (Data Transfer Object) específico para registrar a entrada manual de um veículo.
 *
 * Este record é usado para capturar e validar os dados enviados no corpo de uma
 * requisição POST para o endpoint de entrada. Ele contém apenas os campos essenciais
 * para o registro inicial e utiliza anotações de validação (Bean Validation) para
 * garantir que os dados recebidos sejam válidos antes de serem processados pela
 * camada de serviço.
 *
 * @param placa            A placa do veículo. É um campo obrigatório (@NotBlank) e deve
 * seguir o padrão de placas brasileiras, tanto o antigo quanto
 * o Mercosul (@Pattern).
 * @param nomeCliente      O nome do cliente/motorista. É um campo obrigatório (@NotBlank).
 * @param telefoneCliente  O telefone de contato do cliente. Este campo é opcional.
 */
public record VeiculoEntradaManualDTO(
        @NotBlank(message = "A placa é obrigatória")
        @Pattern(regexp = "[A-Z]{3}-?[0-9][A-Z0-9][0-9]{2}", message = "Formato de placa inválido")
        String placa,

        @NotBlank(message = "O nome do cliente é obrigatório")
        String nomeCliente,

        String telefoneCliente
) {}