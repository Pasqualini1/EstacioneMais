package com.estacioneMais.dto;

import java.time.LocalDateTime;
import java.math.BigDecimal;

/*
 * DTO (Data Transfer Object) que representa os dados completos de um veículo
 * e seu registro de estacionamento.
 *
 * Utilizado como um "pacote" de dados para transferir informações de forma estruturada
 * entre as camadas da aplicação, como da camada de Serviço (Service) para a de
 * Controle (Controller), que o envia como resposta da API.
 *
 * A utilização de 'record' no Java moderno torna a criação de DTOs mais concisa,
 * garantindo que os dados sejam imutáveis (não podem ser alterados após a criação).
 *
 * @param nomeCliente      Nome do cliente associado ao veículo.
 * @param telefoneCliente  Telefone de contato do cliente.
 * @param placa            Placa do veículo (identificador principal).
 * @param modelo           Modelo do veículo.
 * @param cor              Cor do veículo.
 * @param ano              Ano de fabricação do veículo.
 * @param horarioEntrada   Data e hora em que o veículo entrou no estacionamento.
 * @param horarioSaida     Data e hora em que o veículo saiu do estacionamento (pode ser nulo).
 * @param valorTotal       Valor total calculado pelo período de estacionamento.
 */
public record VeiculoDTO(
        String nomeCliente,
        String telefoneCliente,
        String placa,
        String modelo,
        String cor,
        Integer ano,
        LocalDateTime horarioEntrada,
        LocalDateTime horarioSaida,
        // --- CORREÇÃO APLICADA AQUI ---
        // Renomeado de "valorPago" para "valorTotal" para consistência.
        BigDecimal valorTotal
) {}