package com.estacioneMais.dto;

import java.util.List;

/**
 * DTO principal para a tela de "Status do Pátio".
 * Contém os contadores de vagas e a lista de veículos ativos.
 */
public record StatusPatioDTO(
        int totalVagas,
        int vagasOcupadas,
        int vagasDisponiveis,
        List<VeiculoStatusDTO> veiculosNoPatio
) {
}