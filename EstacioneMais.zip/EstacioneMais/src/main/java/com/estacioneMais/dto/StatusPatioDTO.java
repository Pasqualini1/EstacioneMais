package com.estacioneMais.dto;

import java.util.List;

/**
 * DTO (Data Transfer Object) para a tela de "Status do Pátio".
 * Agrega os contadores de vagas (total, ocupadas, disponíveis) e a lista
 * dos veículos que estão atualmente no pátio.
 *
 * @param totalVagas        O número total de vagas configurado no sistema.
 * @param vagasOcupadas     O número de vagas atualmente ocupadas.
 * @param vagasDisponiveis  O número de vagas livres (Total - Ocupadas).
 * @param veiculosNoPatio   A lista de veículos que estão no pátio (ativos).
 */
public record StatusPatioDTO(
        int totalVagas,
        int vagasOcupadas,
        int vagasDisponiveis,
        List<VeiculoStatusDTO> veiculosNoPatio
) {}