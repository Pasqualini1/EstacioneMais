package com.estacioneMais.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Filtro de segurança customizado que intercepta todas as requisições
 * para validar uma Chave de API (API Key).
 * <p>
 * Este filtro (que atua como um "porteiro") é executado uma vez
 * (OncePerRequestFilter) para cada requisição, verificando a
 * presença e validade de um 'header' HTTP específico (X-API-KEY).
 */
@Component
public class ApiKeyAuthFilter extends OncePerRequestFilter {

    /**
     * Injeta o valor da chave de API secreta (a "senha mestre")
     * definida no arquivo 'application.properties' (na propriedade 'api.secret.key').
     */
    @Value("${api.secret.key}")
    private String systemApiKey;

    /**
     * Método principal do filtro, executado para cada requisição HTTP.
     * <p>
     * Ele extrai o 'header' "X-API-KEY" da requisição e o compara com a
     * 'systemApiKey' esperada. Se a chave for válida, ele informa ao
     * Spring Security que a requisição está autenticada. Se for
     * inválida ou ausente, ele bloqueia a requisição com um erro 401
     * (Não Autorizado).
     *
     * @param request     O objeto da requisição HTTP (de onde lemos o header).
     * @param response    O objeto da resposta HTTP (onde escrevemos o erro 401).
     * @param filterChain O objeto que nos permite "passar a requisição
     * adiante" para o próximo filtro ou para o Controller.
     * @throws ServletException Lançada se ocorrer um erro no servlet.
     * @throws IOException      Lançada se ocorrer um erro de I/O (ex: ao escrever
     * a resposta de erro).
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {

        // Procura o cabeçalho "X-API-KEY" na requisição
        String requestApiKey = request.getHeader("X-API-KEY");

        // Se o cabeçalho não existir ou a chave for diferente da esperada, bloqueia.
        if (requestApiKey == null || !requestApiKey.equals(systemApiKey)) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED); // Erro 401
            response.getWriter().write("Chave de API inválida ou ausente");
            return; // Para a execução aqui, não deixando a requisição prosseguir
        }

        // Se a chave estiver CORRETA:
        // Informa ao Spring Security que o usuário está "logado" (autenticado)
        // para o contexto desta requisição.
        var authorities = new ArrayList<SimpleGrantedAuthority>();
        authorities.add(new SimpleGrantedAuthority("ROLE_USER")); // Dá uma permissão genérica

        var authentication = new UsernamePasswordAuthenticationToken(
                "api-user", // Um nome de usuário genérico para o "dono" da API Key
                null,
                authorities
        );
        SecurityContextHolder.getContext().setAuthentication(authentication);

        // Deixa a requisição continuar seu fluxo normal (ir para o Controller)
        filterChain.doFilter(request, response);
    }
}