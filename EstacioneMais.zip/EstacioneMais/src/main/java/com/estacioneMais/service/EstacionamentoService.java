package com.estacioneMais.service;

import com.estacioneMais.dto.VeiculoDTO;
import com.estacioneMais.dto.VeiculoEntradaManualDTO;
import com.estacioneMais.exception.ResourceNotFoundException;
import com.estacioneMais.model.Preco;
import com.estacioneMais.model.RegistroEstacionamento;
import com.estacioneMais.model.Veiculo;
import com.estacioneMais.repository.RegistroEstacionamentoRepository;
import com.estacioneMais.repository.VeiculoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EstacionamentoService {
    private final VeiculoRepository veiculoRepository;
    private final RegistroEstacionamentoRepository registroRepository;
    private final ApiPlacaFipeService consultaExternaService;
    // --- CORREÇÃO DE NOME: Variável renomeada para consistência ---
    private final PrecoService precoService;

    public EstacionamentoService(
            VeiculoRepository veiculoRepository,
            RegistroEstacionamentoRepository registroRepository,
            ApiPlacaFipeService consultaExternaService,
            // --- CORREÇÃO DE NOME: Injeção de dependência ajustada ---
            PrecoService precoService) {
        this.veiculoRepository = veiculoRepository;
        this.registroRepository = registroRepository;
        this.consultaExternaService = consultaExternaService;
        this.precoService = precoService;
    }

    /**
     * Calcula o valor da saída sem persistir (salvar) os dados.
     * Usado para pré-visualizar o valor para o operador.
     */
    @Transactional(readOnly = true)
    public VeiculoDTO calcularSaida(String placa) {
        RegistroEstacionamento registro = registroRepository.
                findByVeiculoPlacaAndHorarioSaidaIsNull(placa)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Veículo com a placa " + placa + " não está atualmente no pátio."));

        LocalDateTime horarioSaida = LocalDateTime.now();
        BigDecimal valorCalculado = calcularValorTotal(registro.getHorarioEntrada(), horarioSaida);

        Veiculo v = registro.getVeiculo();
        return new VeiculoDTO(
                v.getNomeCliente(), v.getTelefoneCliente(), v.getPlaca(), v.getModelo(),
                v.getCor(), v.getAno(), registro.getHorarioEntrada(), horarioSaida,
                valorCalculado
        );
    }

    /**
     * Registra a saída de um veículo e salva as informações no banco de dados.
     */
    @Transactional
    public VeiculoDTO registrarSaida(String placa) {
        RegistroEstacionamento registro = registroRepository.
                findByVeiculoPlacaAndHorarioSaidaIsNull(placa)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Veículo com a placa " + placa + " não está atualmente no pátio."));

        LocalDateTime horarioSaida = LocalDateTime.now();
        BigDecimal valorCalculado = calcularValorTotal(registro.getHorarioEntrada(), horarioSaida);

        registro.setHorarioSaida(horarioSaida);
        registro.setValorTotal(valorCalculado);
        RegistroEstacionamento registroSalvo = registroRepository.save(registro);

        return mapearRegistroParaDTO(registroSalvo);
    }

    /**
     * Lógica de cálculo de valor que usa o PrecoService para buscar as regras de preço.
     */
    private BigDecimal calcularValorTotal(LocalDateTime horarioEntrada, LocalDateTime horarioSaida) {
        // --- CORREÇÃO DE NOME: Chamada de método e variáveis ajustadas ---
        Preco preco = precoService.getPreco();
        long minutosEstacionado = Duration.between(horarioEntrada, horarioSaida).toMinutes();

        if (minutosEstacionado <= 0) {
            return BigDecimal.ZERO;
        }

        if (preco.getPrecoMinutos() <= 0) {
            throw new IllegalStateException("A 'quantidade de minutos' na configuração de preço deve ser maior que zero.");
        }

        double numeroDeIntervalos = Math.ceil((double) minutosEstacionado / preco.getPrecoMinutos());

        return preco.getPrecoValor().multiply(new BigDecimal(numeroDeIntervalos));
    }

    @Transactional
    public void registrarEntrada(VeiculoEntradaManualDTO dadosEntrada) {
        String placaLimpa = dadosEntrada.placa().toUpperCase().replace("-", "");
        registroRepository.findByVeiculoPlacaAndHorarioSaidaIsNull(placaLimpa)
                .ifPresent(r -> {
                    throw new IllegalStateException("ERRO: Este veículo já se encontra no pátio.");
                });
        Veiculo veiculo = veiculoRepository.findFirstByPlaca(placaLimpa).orElseGet(() -> {
            Veiculo novoVeiculo = new Veiculo();
            novoVeiculo.setPlaca(placaLimpa);
            return novoVeiculo;
        });
        if (veiculo.getId() == null && (dadosEntrada.nomeCliente() == null ||
                dadosEntrada.nomeCliente().isBlank())) {
            throw new IllegalArgumentException(
                    "O nome do cliente é obrigatório para o primeiro registro de um veículo.");
        }
        VeiculoDTO veiculoExterno = consultaExternaService.consultarPlaca(placaLimpa);
        if (veiculoExterno != null) {
            veiculo.setModelo(veiculoExterno.modelo());
            veiculo.setCor(veiculoExterno.cor());
            veiculo.setAno(veiculoExterno.ano());
        }
        if (dadosEntrada.nomeCliente() != null && !dadosEntrada.nomeCliente().isBlank()) {
            veiculo.setNomeCliente(dadosEntrada.nomeCliente());
        }
        if (dadosEntrada.telefoneCliente() != null) {
            veiculo.setTelefoneCliente(dadosEntrada.telefoneCliente());
        }
        veiculoRepository.save(veiculo);
        RegistroEstacionamento novoRegistro = new RegistroEstacionamento();
        novoRegistro.setVeiculo(veiculo);
        novoRegistro.setHorarioEntrada(LocalDateTime.now());
        registroRepository.save(novoRegistro);
    }

    @Transactional(readOnly = true)
    public List<VeiculoDTO> listarVeiculosAtivos() {
        return registroRepository.
                findByHorarioSaidaIsNullOrderByHorarioEntradaDesc()
                .stream()
                .map(this::mapearRegistroParaDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<VeiculoDTO> listarHistoricoCompleto() {
        return registroRepository.buscarHistoricoCompletoComOrdenacao()
                .stream()
                .map(this::mapearRegistroParaDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<VeiculoDTO> gerarRelatorioPorPlaca(String placa) {
        List<RegistroEstacionamento> registros = registroRepository
                .buscarHistoricoPorPlacaComOrdenacao(placa);
        return registros.stream()
                .map(this::mapearRegistroParaDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<VeiculoDTO> buscarRegistrosPorPeriodo(
            LocalDateTime dataInicio, LocalDateTime dataFim) {
        return registroRepository.findByHorarioEntradaBetweenOrderByHorarioEntradaDesc(
                        dataInicio, dataFim).stream()
                .map(this::mapearRegistroParaDTO)
                .collect(Collectors.toList());
    }

    private VeiculoDTO mapearRegistroParaDTO(RegistroEstacionamento reg) {
        Veiculo v = reg.getVeiculo();
        return new VeiculoDTO(
                v.getNomeCliente(), v.getTelefoneCliente(), v.getPlaca(), v.getModelo(),
                v.getCor(), v.getAno(), reg.getHorarioEntrada(), reg.getHorarioSaida(),
                reg.getValorTotal()
        );
    }
}