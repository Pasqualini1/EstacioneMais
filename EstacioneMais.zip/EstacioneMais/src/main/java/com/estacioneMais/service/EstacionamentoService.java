package com.estacioneMais.service;

import com.estacioneMais.dto.VeiculoDTO;
import com.estacioneMais.dto.VeiculoEntradaManualDTO;
import com.estacioneMais.exception.ResourceNotFoundException;
import com.estacioneMais.model.RegistroEstacionamento;
import com.estacioneMais.model.Veiculo;
import com.estacioneMais.repository.RegistroEstacionamentoRepository;
import com.estacioneMais.repository.VeiculoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/*
 * Classe de serviço que contém a lógica de negócio principal para o sistema de estacionamento.
 *
 * Ela orquestra as operações entre os controllers e os repositórios, aplicando as regras
 * de negócio e garantindo a integridade dos dados através do gerenciamento de transações.
 */
@Service
public class EstacionamentoService {
    private final VeiculoRepository veiculoRepository;
    private final RegistroEstacionamentoRepository registroRepository;
    private final ApiPlacaFipeService consultaExternaService;

    /*
     * Construtor para injeção de dependências dos repositórios e de outros serviços.
     *
     * @param veiculoRepository Repositório para acesso aos dados de Veiculo.
     * @param registroRepository Repositório para acesso aos dados de RegistroEstacionamento.
     * @param consultaExternaService Serviço para buscar dados externos do veículo pela placa.
     */
    public EstacionamentoService(
            VeiculoRepository veiculoRepository,
            RegistroEstacionamentoRepository registroRepository,
            ApiPlacaFipeService consultaExternaService) {
        this.veiculoRepository = veiculoRepository;
        this.registroRepository = registroRepository;
        this.consultaExternaService = consultaExternaService;
    }

    /*
     * Registra a entrada de um veículo no estacionamento.
     * A anotação @Transactional garante que todas as operações com o banco de dados
     * neste método sejam executadas como uma única transação. Se ocorrer qualquer erro,
     * todas as alterações são desfeitas (rollback), mantendo a consistência dos dados.
     *
     * @param dadosEntrada DTO com os dados da entrada (placa, nome e telefone do cliente).
     */
    @Transactional
    public void registrarEntrada(VeiculoEntradaManualDTO dadosEntrada) {
        // 1. Limpa e valida a placa para um formato padrão.
        String placaLimpa = dadosEntrada.placa().toUpperCase().replace("-", "");

        // 2. Verifica se o veículo já tem uma entrada ativa.
        registroRepository.findByVeiculoPlacaAndHorarioSaidaIsNull(placaLimpa)
                .ifPresent(r -> {
            throw new IllegalStateException("ERRO: Este veículo já se encontra no pátio.");
        });

        // 3. Busca o veículo no banco de dados. Se não existir, prepara um novo objeto.
        Veiculo veiculo = veiculoRepository.findFirstByPlaca(placaLimpa).orElseGet(() -> {
            Veiculo novoVeiculo = new Veiculo();
            novoVeiculo.setPlaca(placaLimpa);
            return novoVeiculo;
        });

        // 4. Se for a primeira vez do veículo, o nome do cliente é obrigatório.
        if (veiculo.getId() == null && (dadosEntrada.nomeCliente() == null ||
                dadosEntrada.nomeCliente().isBlank())) {
            throw new IllegalArgumentException(
                    "O nome do cliente é obrigatório para o primeiro registro de um veículo.");
        }

        // 5. Tenta enriquecer os dados do veículo (modelo, cor, ano)
        // usando o serviço de consulta externa.
        VeiculoDTO veiculoExterno = consultaExternaService.consultarPlaca(placaLimpa);
        if (veiculoExterno != null) {
            veiculo.setModelo(veiculoExterno.modelo());
            veiculo.setCor(veiculoExterno.cor());
            veiculo.setAno(veiculoExterno.ano());
        }

        // 6. Atualiza os dados do cliente no cadastro do veículo.
        if (dadosEntrada.nomeCliente() != null && !dadosEntrada.nomeCliente().isBlank()) {
            veiculo.setNomeCliente(dadosEntrada.nomeCliente());
        }
        if (dadosEntrada.telefoneCliente() != null) {
            veiculo.setTelefoneCliente(dadosEntrada.telefoneCliente());
        }

        // 7. Salva o veículo (cria um novo ou atualiza um existente).
        veiculoRepository.save(veiculo);

        // 8. Cria e salva o novo registro de estacionamento, vinculando ao veículo.
        RegistroEstacionamento novoRegistro = new RegistroEstacionamento(); // LINHA CORRIGIDA
        novoRegistro.setVeiculo(veiculo);
        novoRegistro.setHorarioEntrada(LocalDateTime.now());
        registroRepository.save(novoRegistro);
    }

    /*
     * Registra a saída de um veículo que está no pátio.
     * A anotação @Transactional garante a atomicidade da operação.
     *
     * @param placa A placa do veículo que está saindo.
     * @throws ResourceNotFoundException se não houver um veículo com a placa informada no pátio.
     */
    @Transactional
    public void registrarSaida(String placa) {
        RegistroEstacionamento registro = registroRepository.
                findByVeiculoPlacaAndHorarioSaidaIsNull(placa)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Veículo com a placa " + placa + " não está atualmente no pátio."));

        registro.setHorarioSaida(LocalDateTime.now());
        registroRepository.save(registro);
    }

    /*
     * Lista todos os veículos que estão atualmente no estacionamento.
     * A anotação @Transactional(readOnly = true) otimiza a consulta, informando
     * ao banco de dados que esta é uma operação apenas de leitura.
     *
     * @return Uma lista de VeiculoDTO representando os veículos ativos.
     */
    @Transactional(readOnly = true)
    public List<VeiculoDTO> listarVeiculosAtivos() {
        return registroRepository.
                findByHorarioSaidaIsNullOrderByHorarioEntradaDesc()
                .stream()
                .map(this::mapearRegistroParaDTO)
                .collect(Collectors.toList());
    }

    /*
     * Retorna o histórico completo de movimentações, com ordenação customizada.
     *
     * @return Uma lista de VeiculoDTO com todos os registros.
     */
    @Transactional(readOnly = true)
    public List<VeiculoDTO> listarHistoricoCompleto() {
        return registroRepository.buscarHistoricoCompletoComOrdenacao()
                .stream()
                .map(this::mapearRegistroParaDTO)
                .collect(Collectors.toList());
    }

    /*
     * Gera um relatório de histórico de um veículo específico, buscando pela placa.
     *
     * @param placa A placa do veículo a ser consultado.
     * @return Uma lista de VeiculoDTO com todo o histórico do veículo.
     */
    @Transactional(readOnly = true)
    public List<VeiculoDTO> gerarRelatorioPorPlaca(String placa) {
        List<RegistroEstacionamento> registros = registroRepository
                .buscarHistoricoPorPlacaComOrdenacao(placa);
        return registros.stream()
                .map(this::mapearRegistroParaDTO)
                .collect(Collectors.toList());
    }

    /*
     * Busca todos os registros de estacionamento dentro de um período de tempo.
     *
     * @param dataInicio Data e hora de início da busca.
     * @param dataFim    Data e hora de fim da busca.
     * @return Uma lista de VeiculoDTO com os registros do período.
     */
    @Transactional(readOnly = true)
    public List<VeiculoDTO> buscarRegistrosPorPeriodo(
            LocalDateTime dataInicio, LocalDateTime dataFim) {
        return registroRepository.findByHorarioEntradaBetweenOrderByHorarioEntradaDesc(
                dataInicio, dataFim).stream()
                .map(this::mapearRegistroParaDTO)
                .collect(Collectors.toList());
    }

    /*
     * Método auxiliar privado para converter uma entidade {@link RegistroEstacionamento}
     * em um {@link VeiculoDTO}.
     * Este método centraliza a lógica de mapeamento, evitando duplicação de código.
     *
     * @param reg A entidade de registro a ser convertida.
     * @return O DTO correspondente, pronto para ser enviado pela API.
     */
    private VeiculoDTO mapearRegistroParaDTO(RegistroEstacionamento reg) {
        Veiculo v = reg.getVeiculo();
        return new VeiculoDTO(
                v.getNomeCliente(), v.getTelefoneCliente(), v.getPlaca(), v.getModelo(),
                v.getCor(), v.getAno(), reg.getHorarioEntrada(), reg.getHorarioSaida()
        );
    }
}