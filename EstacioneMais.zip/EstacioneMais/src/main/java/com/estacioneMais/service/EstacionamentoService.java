package com.estacioneMais.service;

import com.estacioneMais.dto.*;
import com.estacioneMais.exception.ResourceNotFoundException;
import com.estacioneMais.model.Preco;
import com.estacioneMais.model.RegistroEstacionamento;
import com.estacioneMais.model.Veiculo;
import com.estacioneMais.model.VagasDisp;
import com.estacioneMais.repository.RegistroEstacionamentoRepository;
import com.estacioneMais.repository.VeiculoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Classe de Serviço (Service) principal que orquestra a lógica de negócio
 * do sistema de estacionamento.
 * <p>
 * Responsável por lidar com entradas, saídas, cálculos de preço,
 * gerenciamento de status do pátio e geração de relatórios,
 * coordenando os diversos repositórios e outros serviços.
 */
@Service
public class EstacionamentoService {

    private final VeiculoRepository veiculoRepository;
    private final RegistroEstacionamentoRepository registroRepository;
    private final ApiPlacaFipeService consultaExternaService;
    private final PrecoService precoService;
    private final VagasDispService vagasDispService;

    /**
     * Construtor para injeção de dependência de todos os repositórios
     * e serviços necessários para a operação do EstacionamentoService.
     *
     * @param veiculoRepository      Repositório para acesso aos dados de Veiculo.
     * @param registroRepository     Repositório para acesso aos Registros de
     * Estacionamento.
     * @param consultaExternaService Serviço para consulta de dados de veículos
     * externamente (via scraping).
     * @param precoService           Serviço para obter as regras de precificação.
     * @param vagasDispService       Serviço para obter a configuração de total de vagas.
     */
    public EstacionamentoService(
            VeiculoRepository veiculoRepository,
            RegistroEstacionamentoRepository registroRepository,
            ApiPlacaFipeService consultaExternaService,
            PrecoService precoService,
            VagasDispService vagasDispService) {
        this.veiculoRepository = veiculoRepository;
        this.registroRepository = registroRepository;
        this.consultaExternaService = consultaExternaService;
        this.precoService = precoService;
        this.vagasDispService = vagasDispService;
    }

    /**
     * Busca todas as informações necessárias para a tela de "Status do Pátio".
     * Calcula o total de vagas, vagas ocupadas, disponíveis e uma lista
     * detalhada de cada veículo ativo, incluindo seu tempo de estadia e
     * o valor calculado até o momento.
     *
     * @return Um StatusPatioDTO contendo o resumo completo do pátio.
     */
    @Transactional(readOnly = true)
    public StatusPatioDTO getStatusPatio() {
        VagasDisp vagasConfig = vagasDispService.getVagas();
        int totalVagas = vagasConfig.getTotalVagas();

        List<RegistroEstacionamento> veiculosAtivos = registroRepository
                .findByHorarioSaidaIsNullOrderByHorarioEntradaDesc();

        LocalDateTime agora = LocalDateTime.now();

        List<VeiculoStatusDTO> veiculosDTOList = veiculosAtivos.stream().map(registro -> {
            Veiculo veiculo = registro.getVeiculo();
            BigDecimal valorAtual = calcularValorTotal(registro.getHorarioEntrada(), agora);
            Duration duracao = Duration.between(registro.getHorarioEntrada(), agora);
            String tempoEstacionado = formatarDuracao(duracao);

            return new VeiculoStatusDTO(
                    veiculo.getPlaca(),
                    veiculo.getNomeCliente(),
                    veiculo.getTelefoneCliente(),
                    veiculo.getModelo(),
                    veiculo.getCor(),
                    registro.getHorarioEntrada(),
                    tempoEstacionado,
                    valorAtual
            );
        }).collect(Collectors.toList());

        int vagasOcupadas = veiculosDTOList.size();
        int vagasDisponiveis = totalVagas - vagasOcupadas;

        return new StatusPatioDTO(
                totalVagas,
                vagasOcupadas,
                vagasDisponiveis,
                veiculosDTOList
        );
    }

    /**
     * Calcula o valor da saída de um veículo sem persistir (salvar) os dados.
     * Usado para pré-visualizar o valor para o operador antes de confirmar a saída.
     *
     * @param placa A placa do veículo.
     * @return Um VeiculoDTO com os dados do registro, incluindo a hora de saída
     * (simulada) e o valor total calculado.
     * @throws ResourceNotFoundException Se o veículo não for encontrado no pátio.
     */
    @Transactional(readOnly = true)
    public VeiculoDTO calcularSaida(String placa) {
        RegistroEstacionamento registro = registroRepository.
                findByVeiculoPlacaAndHorarioSaidaIsNull(placa)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Veículo com a placa " + placa + " não está atualmente no pátio."));

        LocalDateTime horarioSaida = LocalDateTime.now();
        BigDecimal valorCalculado = calcularValorTotal(registro.getHorarioEntrada(), horarioSaida);

        Veiculo v = registro.getVeiculo();
        return new VeiculoDTO(
                v.getNomeCliente(), v.getTelefoneCliente(), v.getPlaca(), v.getModelo(),
                v.getCor(), v.getAno(), registro.getHorarioEntrada(), horarioSaida,
                valorCalculado
        );
    }

    /**
     * Registra a saída efetiva de um veículo do pátio.
     * Calcula o valor final, define o horário de saída no registro e
     * persiste as alterações no banco de dados.
     *
     * @param placa A placa do veículo que está saindo.
     * @return Um VeiculoDTO com os dados finais do registro (com valor e
     * hora de saída).
     * @throws ResourceNotFoundException Se o veículo não for encontrado no pátio.
     */
    @Transactional
    public VeiculoDTO registrarSaida(String placa) {
        RegistroEstacionamento registro = registroRepository.
                findByVeiculoPlacaAndHorarioSaidaIsNull(placa)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Veículo com a placa " + placa + " não está atualmente no pátio."));

        LocalDateTime horarioSaida = LocalDateTime.now();
        BigDecimal valorCalculado = calcularValorTotal(registro.getHorarioEntrada(), horarioSaida);

        registro.setHorarioSaida(horarioSaida);
        registro.setValorTotal(valorCalculado);
        RegistroEstacionamento registroSalvo = registroRepository.save(registro);

        return mapearRegistroParaDTO(registroSalvo);
    }

    /**
     * Método auxiliar privado para calcular o valor total da estadia
     * com base no tempo e nas regras de preço.
     * <p>
     * Este método implementa um cálculo proporcional ao minuto, baseado na
     * regra de preço (ex: R$ 5,00 por 60 minutos).
     *
     * @param horarioEntrada Data e hora da entrada.
     * @param horarioSaida   Data e hora da saída (ou momento atual para cálculo).
     * @return O BigDecimal com o valor total calculado e arredondado
     * (2 casas decimais).
     */
    private BigDecimal calcularValorTotal(LocalDateTime horarioEntrada, LocalDateTime horarioSaida) {
        Preco preco = precoService.getPreco();
        long minutosEstacionado = Duration.between(horarioEntrada, horarioSaida).toMinutes();

        if (minutosEstacionado <= 0) {
            return BigDecimal.ZERO;
        }

        if (preco.getPrecoMinutos() <= 0) {
            throw new IllegalStateException(
                    "A 'quantidade de minutos' na configuração de preço deve ser maior que zero.");
        }

        BigDecimal valorIntervalo = preco.getPrecoValor();
        BigDecimal minutosIntervalo = new BigDecimal(preco.getPrecoMinutos());
        BigDecimal minutosEstacionadoBD = new BigDecimal(minutosEstacionado);

        BigDecimal valorPorMinuto = valorIntervalo.divide(
                minutosIntervalo, 4, java.math.RoundingMode.HALF_UP);

        BigDecimal valorTotal = valorPorMinuto.multiply(minutosEstacionadoBD);

        return valorTotal.setScale(2, java.math.RoundingMode.HALF_UP);
    }

    /**
     * Registra uma nova entrada de veículo no pátio.
     * <p>
     * Este método complexo:
     * 1. Verifica se o veículo já está no pátio.
     * 2. Localiza o veículo no banco de dados pela placa ou cria um novo.
     * 3. Valida se o nome do cliente foi fornecido para novos veículos.
     * 4. Chama o serviço externo (ApiPlacaFipeService) para buscar dados
     * (modelo, cor, ano).
     * 5. Atualiza os dados do veículo (cliente, telefone).
     * 6. Salva o veículo (novo ou atualizado).
     * 7. Cria e salva um novo RegistroEstacionamento com a hora de entrada atual.
     *
     * @param dadosEntrada DTO contendo placa, nome e telefone do cliente.
     * @throws IllegalStateException    Se o veículo já estiver no pátio.
     * @throws IllegalArgumentException Se for um veículo novo e o nome do
     * cliente não for fornecido.
     */
    @Transactional
    public void registrarEntrada(VeiculoEntradaManualDTO dadosEntrada) {
        String placaLimpa = dadosEntrada.placa().toUpperCase().replace("-", "");
        registroRepository.findByVeiculoPlacaAndHorarioSaidaIsNull(placaLimpa)
                .ifPresent(r -> {
                    throw new IllegalStateException("ERRO: Este veículo já se encontra no pátio.");
                });

        Veiculo veiculo = veiculoRepository.findFirstByPlaca(placaLimpa).orElseGet(() -> {
            Veiculo novoVeiculo = new Veiculo();
            novoVeiculo.setPlaca(placaLimpa);
            return novoVeiculo;
        });

        if (veiculo.getId() == null && (dadosEntrada.nomeCliente() == null ||
                dadosEntrada.nomeCliente().isBlank())) {
            throw new IllegalArgumentException(
                    "O nome do cliente é obrigatório para o primeiro registro de um veículo.");
        }

        VeiculoDTO veiculoExterno = consultaExternaService.consultarPlaca(placaLimpa);
        if (veiculoExterno != null) {
            veiculo.setModelo(veiculoExterno.modelo());
            veiculo.setCor(veiculoExterno.cor());
            veiculo.setAno(veiculoExterno.ano());
        }

        if (dadosEntrada.nomeCliente() != null && !dadosEntrada.nomeCliente().isBlank()) {
            veiculo.setNomeCliente(dadosEntrada.nomeCliente());
        }
        if (dadosEntrada.telefoneCliente() != null) {
            veiculo.setTelefoneCliente(dadosEntrada.telefoneCliente());
        }

        veiculoRepository.save(veiculo);

        RegistroEstacionamento novoRegistro = new RegistroEstacionamento();
        novoRegistro.setVeiculo(veiculo);
        novoRegistro.setHorarioEntrada(LocalDateTime.now());
        registroRepository.save(novoRegistro);
    }

    /**
     * Lista todos os veículos que estão atualmente no pátio (ativos).
     * Busca registros que não possuem horário de saída.
     *
     * @return Uma lista de VeiculoDTO dos veículos ativos, ordenados pela
     * entrada mais recente.
     */
    @Transactional(readOnly = true)
    public List<VeiculoDTO> listarVeiculosAtivos() {
        return registroRepository.
                findByHorarioSaidaIsNullOrderByHorarioEntradaDesc()
                .stream()
                .map(this::mapearRegistroParaDTO)
                .collect(Collectors.toList());
    }

    /**
     * Lista o histórico completo de todas as estadias finalizadas.
     * Busca registros que possuem horário de saída.
     *
     * @return Uma lista de VeiculoDTO de todo o histórico, ordenados pela
     * saída mais recente.
     */
    @Transactional(readOnly = true)
    public List<VeiculoDTO> listarHistoricoCompleto() {
        return registroRepository.buscarHistoricoCompletoComOrdenacao()
                .stream()
                .map(this::mapearRegistroParaDTO)
                .collect(Collectors.toList());
    }

    /**
     * Gera um relatório de histórico de estadias (finalizadas) para uma
     * placa específica.
     *
     * @param placa A placa do veículo a ser consultada.
     * @return Uma lista de VeiculoDTO com todas as estadias daquela placa.
     */
    @Transactional(readOnly = true)
    public List<VeiculoDTO> gerarRelatorioPorPlaca(String placa) {
        List<RegistroEstacionamento> registros = registroRepository
                .buscarHistoricoPorPlacaComOrdenacao(placa);
        return registros.stream()
                .map(this::mapearRegistroParaDTO)
                .collect(Collectors.toList());
    }

    /**
     * Busca todos os registros de estacionamento (entradas) que ocorreram
     * dentro de um período de datas específico.
     *
     * @param dataInicio Data e hora inicial do período.
     * @param dataFim    Data e hora final do período.
     * @return Uma lista de VeiculoDTO dos registros encontrados no período.
     */
    @Transactional(readOnly = true)
    public List<VeiculoDTO> buscarRegistrosPorPeriodo(
            LocalDateTime dataInicio, LocalDateTime dataFim) {
        return registroRepository.findByHorarioEntradaBetweenOrderByHorarioEntradaDesc(
                        dataInicio, dataFim).stream()
                .map(this::mapearRegistroParaDTO)
                .collect(Collectors.toList());
    }

    /**
     * Método auxiliar privado para converter (mapear) uma entidade
     * RegistroEstacionamento em um VeiculoDTO.
     *
     * @param reg A entidade RegistroEstacionamento vinda do banco de dados.
     * @return O DTO correspondente, pronto para ser enviado pela API.
     */
    private VeiculoDTO mapearRegistroParaDTO(RegistroEstacionamento reg) {
        Veiculo v = reg.getVeiculo();
        return new VeiculoDTO(
                v.getNomeCliente(), v.getTelefoneCliente(), v.getPlaca(), v.getModelo(),
                v.getCor(), v.getAno(), reg.getHorarioEntrada(), reg.getHorarioSaida(),
                reg.getValorTotal()
        );
    }

    /**
     * Método auxiliar (helper) para formatar uma Duração (Duration)
     * em uma string amigável (ex: "2h 15m" ou "30m").
     *
     * @param duracao O objeto Duration a ser formatado.
     * @return Uma string formatada representando o tempo.
     */
    private String formatarDuracao(Duration duracao) {
        if (duracao == null) {
            return "0m";
        }
        long totalMinutos = duracao.toMinutes();
        long horas = totalMinutos / 60;
        long minutos = totalMinutos % 60;

        if (horas > 0) {
            return String.format("%dh %dm", horas, minutos);
        } else {
            return String.format("%dm", minutos);
        }
    }
}