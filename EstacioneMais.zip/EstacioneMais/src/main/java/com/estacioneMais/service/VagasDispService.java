package com.estacioneMais.service;

import com.estacioneMais.dto.VagasDispDTO;
import com.estacioneMais.model.VagasDisp;
import com.estacioneMais.repository.VagasDispRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Classe de Serviço (Service) que gerencia a lógica de negócio
 * relacionada à configuração do total de vagas do estacionamento.
 * <p>
 * É responsável por buscar e atualizar o número total de vagas
 * que o pátio suporta, valor que é usado por outros serviços
 * para calcular as vagas disponíveis.
 */
@Service
public class VagasDispService {

    private final VagasDispRepository vagasDispRepository;

    /**
     * Construtor para injeção de dependência do VagasDispRepository.
     *
     * @param vagasDispRepository O repositório para acesso aos dados de VagasDisp.
     */
    public VagasDispService(VagasDispRepository vagasDispRepository) {
        this.vagasDispRepository = vagasDispRepository;
    }

    /**
     * Busca a configuração de vagas (a entidade VagasDisp) no banco de dados.
     * <p>
     * Se nenhuma configuração for encontrada (ex: primeiro uso do sistema),
     * este método cria, salva e retorna uma configuração padrão
     * (com 20 vagas). Garante que o sistema sempre tenha um
     * total de vagas para consultar.
     *
     * @return A entidade VagasDisp vigente (existente ou recém-criada).
     */
    @Transactional
    public VagasDisp getVagas() {
        return vagasDispRepository.findFirstByOrderByIdAsc()
                .orElseGet(() -> {
                    VagasDisp defaultVagas = new VagasDisp();
                    defaultVagas.setTotalVagas(20); // Valor padrão
                    return vagasDispRepository.save(defaultVagas);
                });
    }

    /**
     * Atualiza o total de vagas com o novo valor recebido do frontend.
     * <p>
     * Busca a configuração atual (usando getVagas()), atualiza o total
     * de vagas com base no DTO recebido e salva as alterações.
     *
     * @param dto O DTO (VagasDispDTO) contendo o novo total de vagas.
     * @return Um novo VagasDispDTO refletindo os dados que foram salvos
     * no banco, como confirmação.
     */
    @Transactional
    public VagasDispDTO atualizarVagas(VagasDispDTO dto) {
        VagasDisp vagasAtuais = getVagas();
        vagasAtuais.setTotalVagas(dto.totalVagas());
        VagasDisp vagasSalvas = vagasDispRepository.save(vagasAtuais);

        return new VagasDispDTO(vagasSalvas.getTotalVagas());
    }
}