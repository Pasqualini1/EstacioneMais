package com.estacioneMais.service;

import com.estacioneMais.dto.VeiculoDTO;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import java.time.Duration;

/*
 * Serviço responsável por consultar dados de um veículo a partir de sua placa.
 *
 * Como não há uma API pública disponível para consulta, este serviço utiliza a
 * técnica de Web Scraping. Ele automatiza um navegador web (Google Chrome) de forma
 * invisível ("headless") para acessar o site 'placafipe.com', extrai os dados
 * da página HTML resultante e os devolve de forma estruturada.
 */
@Service
public class ApiPlacaFipeService {

    private static final Logger logger = LoggerFactory.getLogger(ApiPlacaFipeService.class);
    private static final String BASE_URL = "https://placafipe.com/placa/";

    /*
     * Realiza a consulta de uma placa via Web Scraping.
     *
     * @param placa A placa do veículo a ser consultada.
     * @return Um VeiculoDTO preenchido com os dados encontrados (modelo, cor, ano),
     * ou null se a placa for inválida ou se a extração de dados falhar.
     */
    public VeiculoDTO consultarPlaca(String placa) {
        if (placa == null || placa.isBlank()) {
            return null;
        }

        // 1. Sanitização: Limpa a placa, removendo espaços, hífens e
        // convertendo para maiúsculas, garantindo um formato consistente.
        String placaSanitizada = placa.trim().toUpperCase().replaceAll("[^A-Z0-9]", "");
        logger.info("Consultando placa '{}' (sanitizada: '{}')", placa, placaSanitizada);

        if (placaSanitizada.length() != 7) {
            logger.warn("Placa '{}' tem formato inválido após limpeza.", placaSanitizada);
            return null;
        }

        // 2. Setup do Selenium: Configura e inicializa o WebDriver para o Chrome.
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless=new"); // Executa o navegador sem interface gráfica.
        options.addArguments("--no-sandbox");   // Opções para estabilidade em ambientes de servidor.
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments
                ("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
                        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36");

        WebDriver driver = new ChromeDriver(options);
        try {
            // 3. Navegação: O navegador automatizado acessa a URL de consulta.
            String url = BASE_URL + placaSanitizada;
            logger.info("Acessando URL: {}", url);
            driver.get(url);

            // 4. Espera Inteligente: Aguarda até 15 segundos para que a página carregue
            // dinamicamente e o título contenha a placa, confirmando que os dados corretos
            // foram carregados (muitos sites usam JavaScript para carregar dados).
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
            wait.until(d -> d.getTitle().toLowerCase().contains("placa "
                    + placaSanitizada.toLowerCase()));

            // 5. Extração com Jsoup: Após o Selenium carregar a página completa,
            // o Jsoup entra em ação para "ler" o HTML e extrair os dados desejados.
            String pageSource = driver.getPageSource();
            Document doc = Jsoup.parse(pageSource);

            Element fipeTable = doc.selectFirst(".fipeTablePriceDetail");
            if (fipeTable == null) {
                logger.error("Tabela de dados não encontrada no HTML. O layout do site pode ter mudado.");
                return null;
            }

            // 6. Parsing dos Dados: Extrai o texto de cada campo da tabela.
            String modelo = extrairTexto(fipeTable, "Modelo:");
            String cor = extrairTexto(fipeTable, "Cor:");
            String anoModeloStr = extrairTexto(fipeTable, "Ano Modelo:");

            if (modelo == null) return null;

            Integer ano = null;
            if (anoModeloStr != null) {
                try {
                    // Limpa o texto do ano para extrair apenas os números.
                    ano = Integer.parseInt(anoModeloStr.replaceAll("[^0-9]", ""));
                } catch (NumberFormatException e) {
                    logger.warn("Não foi possível converter o ano '{}' para número.", anoModeloStr);
                }
            }

            // 7. Retorno: Monta e retorna o DTO com os dados extraídos.
            return new VeiculoDTO(null, null,
                    placaSanitizada, modelo, cor, ano, null, null);

        } catch (Exception e) {
            logger.error("Falha no processo de scraping para a placa: {}.", placaSanitizada, e);
            return null;
        } finally {
            // 8. Limpeza: Garante que o processo do navegador seja
            // encerrado, liberando os recursos do sistema, mesmo que ocorra um erro.
            if (driver != null) {
                driver.quit();
            }
        }
    }

    /*
     * Método auxiliar para extrair o texto de uma célula de valor em uma tabela,
     * com base no texto da célula de rótulo (label) anterior a ela.
     *
     * @param container O elemento HTML (tabela) onde a busca será feita.
     * @param label O texto do rótulo a ser encontrado (ex: "Modelo:").
     * @return O texto da célula seguinte ao rótulo, ou null se não for encontrado.
     */
    private String extrairTexto(Element container, String label) {
        try {
            // Procura uma célula <td> que contenha o texto do label.
            Element celulaLabel = container.selectFirst("td:contains(" + label + ")");
            if (celulaLabel != null) {
                // Pega o próximo elemento "irmão", que deve ser a célula com o valor.
                Element celulaValor = celulaLabel.nextElementSibling();
                if (celulaValor != null) {
                    return celulaValor.text();
                }
            }
        } catch (Exception e) {
            logger.error("Erro ao extrair dado com o label: {}", label, e);
        }
        return null;
    }
}