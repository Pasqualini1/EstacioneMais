package com.estacioneMais.service;

import com.estacioneMais.dto.PrecoDTO;
import com.estacioneMais.model.Preco;
import com.estacioneMais.repository.PrecoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

/**
 * Classe de Serviço (Service) que gerencia a lógica de negócio
 * relacionada às regras de precificação do estacionamento.
 * <p>
 * É responsável por buscar e atualizar a configuração de preços
 * (ex: valor e fração de tempo) usada pelos outros serviços.
 */
@Service
public class PrecoService {

    private final PrecoRepository precoRepository;

    /**
     * Construtor para injeção de dependência do PrecoRepository.
     *
     * @param precoRepository O repositório para acesso aos dados de Preco.
     */
    public PrecoService(PrecoRepository precoRepository) {
        this.precoRepository = precoRepository;
    }

    /**
     * Busca a regra de precificação atual (a entidade Preco) no banco de dados.
     * <p>
     * Se nenhuma regra for encontrada (ex: primeiro uso do sistema),
     * este método cria, salva e retorna uma regra padrão
     * (Ex: R$ 5,00 a cada 60 minutos). Garante que o sistema
     * sempre tenha uma regra de preço para consultar.
     *
     * @return A entidade Preco vigente (existente ou recém-criada).
     */
    @Transactional
    public Preco getPreco() {
        return precoRepository.findFirstByOrderByIdAsc().orElseGet(() -> {
            Preco defaultPreco = new Preco();
            defaultPreco.setPrecoValor(new BigDecimal("5.00"));
            defaultPreco.setPrecoMinutos(60);
            return precoRepository.save(defaultPreco);
        });
    }

    /**
     * Atualiza a regra de precificação vigente com novos valores.
     * <p>
     * Busca a regra atual, atualiza seus campos (valor e minutos)
     * com base nos dados do DTO recebido, e salva as
     * alterações no banco de dados.
     *
     * @param dto O DTO (PrecoDTO) contendo os novos valores de preço e minutos.
     * @return Um novo PrecoDTO refletindo os dados que foram salvos no
     * banco, como confirmação.
     */
    @Transactional
    public PrecoDTO atualizarPreco(PrecoDTO dto) {
        Preco precoAtual = getPreco();
        precoAtual.setPrecoValor(dto.precoValor());
        precoAtual.setPrecoMinutos(dto.precoMinutos());
        Preco precoSalvo = precoRepository.save(precoAtual);

        return new PrecoDTO(precoSalvo.getPrecoValor(), precoSalvo.getPrecoMinutos());
    }
}