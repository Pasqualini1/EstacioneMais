package com.estacioneMais.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import java.time.LocalDateTime;
import java.util.Map;

/*
 * Classe global para tratamento de exceções na API.
 *
 * A anotação {@code @ControllerAdvice} transforma esta classe em um interceptador
 * que captura exceções lançadas por qualquer {@code @RestController} na aplicação.
 * Isso centraliza a lógica de tratamento de erros, garantindo que a API sempre
 * retorne respostas de erro em um formato JSON padronizado e amigável para o cliente.
 */
@ControllerAdvice
public class RestExceptionHandler {

    /*
     * Manipulador para a exceção {@code ResourceNotFoundException}.
     * Este método é acionado sempre que a exceção customizada {@code ResourceNotFoundException}
     * é lançada. Ele constrói uma resposta de erro JSON padronizada e retorna
     * o status HTTP 404 (Not Found).
     *
     * @param ex A exceção {@code ResourceNotFoundException} que foi capturada.
     * @return Um {@code ResponseEntity} contendo o corpo do erro e o status HTTP 404.
     */
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<Object> handleResourceNotFoundException(ResourceNotFoundException ex) {
        Map<String, Object> body = Map.of(
                "timestamp", LocalDateTime.now(),
                "status", HttpStatus.NOT_FOUND.value(),
                "error", "Não Encontrado",
                "message", ex.getMessage()
        );
        return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
    }

    /*
     * Manipulador para a exceção {@code IllegalArgumentException}.
     * Este método captura a exceção padrão do Java, que geralmente é usada para indicar
     * uma violação de regra de negócio (ex: tentar registrar a saída de um veículo
     * que não está no pátio). Ele cria uma resposta JSON e retorna o status
     * HTTP 400 (Bad Request).
     *
     * @param ex A exceção {@code IllegalArgumentException} que foi capturada.
     * @return Um {@code ResponseEntity} contendo o corpo do erro e o status HTTP 400.
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Object> handleIllegalArgumentException(IllegalArgumentException ex) {
        Map<String, Object> body = Map.of(
                "timestamp", LocalDateTime.now(),
                "status", HttpStatus.BAD_REQUEST.value(),
                "error", "Requisição Inválida",
                "message", ex.getMessage()
        );
        return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
    }
}