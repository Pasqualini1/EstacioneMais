package com.estacioneMais.controller;

import com.estacioneMais.dto.StatusPatioDTO;
import com.estacioneMais.dto.VeiculoDTO;
import com.estacioneMais.dto.VeiculoEntradaManualDTO;
import com.estacioneMais.service.EstacionamentoService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Controller (API) para gerenciar as operações principais do estacionamento.
 * Esta classe expõe os endpoints REST para interagir com a lógica de negócio
 * de entradas, saídas, status e relatórios do estacionamento.
 * Mapeia todas as requisições sob o caminho base "/estacionamento".
 */
@RestController
@RequestMapping("/estacionamento")
public class EstacionamentoController {

    private final EstacionamentoService estacionamentoService;

    /**
     * Construtor para injeção de dependência do EstacionamentoService.
     * O Spring injeta automaticamente a instância de EstacionamentoService
     * necessária para que o controller possa delegar as regras de negócio.
     *
     * @param estacionamentoService O serviço que contém a lógica de negócio.
     */
    public EstacionamentoController(EstacionamentoService estacionamentoService) {
        this.estacionamentoService = estacionamentoService;
    }

    /**
     * Endpoint GET para obter o status atual do pátio.
     * Fornece um resumo de quantas vagas estão ocupadas e quantas estão livres.
     *
     * @return ResponseEntity contendo o StatusPatioDTO com a contagem de vagas.
     */
    @GetMapping("/status-patio")
    public ResponseEntity<StatusPatioDTO> getStatusPatio() {
        StatusPatioDTO statusPatio = estacionamentoService.getStatusPatio();
        return ResponseEntity.ok(statusPatio);
    }

    /**
     * Endpoint GET para pré-visualizar o custo da saída de um veículo.
     * Calcula o valor da estadia com base na hora atual, mas não registra
     * a saída efetivamente.
     *
     * @param placa A placa do veículo a ser consultada.
     * @return ResponseEntity com o VeiculoDTO, incluindo o valor total calculado.
     */
    @GetMapping("/saida/preview/{placa}")
    public ResponseEntity<VeiculoDTO> previewSaida(@PathVariable String placa) {
        VeiculoDTO previewDTO = estacionamentoService.calcularSaida(placa);
        return ResponseEntity.ok(previewDTO);
    }

    /**
     * Endpoint POST para registrar efetivamente a saída de um veículo.
     * Finaliza a estadia do veículo, calcula o valor e marca o veículo
     * como "não ativo".
     *
     * @param placa A placa do veículo que está saindo.
     * @return ResponseEntity com o VeiculoDTO finalizado (com hora de saída e valor).
     */
    @PostMapping("/saida/{placa}")
    public ResponseEntity<VeiculoDTO> registrarSaida(@PathVariable String placa) {
        VeiculoDTO registroFinal = estacionamentoService.registrarSaida(placa);
        return ResponseEntity.ok(registroFinal);
    }

    /**
     * Endpoint POST para registrar manualmente a entrada de um veículo.
     * Usado para casos onde a entrada automática (ex: câmera) não é utilizada.
     *
     * @param entradaDTO DTO contendo a placa e a hora de entrada customizada.
     * @return ResponseEntity com uma mensagem de sucesso.
     */
    @PostMapping("/entrada")
    public ResponseEntity<String> registrarEntradaManual(
            @RequestBody VeiculoEntradaManualDTO entradaDTO) {
        estacionamentoService.registrarEntrada(entradaDTO);
        return ResponseEntity.ok("Entrada do veículo " +
                entradaDTO.placa().toUpperCase() + " registrada com sucesso.");
    }

    /**
     * Endpoint GET para listar todos os veículos atualmente no pátio.
     * Retorna apenas os veículos que entraram e ainda não registraram saída.
     *
     * @return ResponseEntity com a lista de VeiculoDTO dos veículos ativos.
     */
    @GetMapping("/ativos")
    public ResponseEntity<List<VeiculoDTO>> listarVeiculosAtivos() {
        return ResponseEntity.ok(estacionamentoService.listarVeiculosAtivos());
    }

    /**
     * Endpoint GET para listar o histórico completo de todas as estadias.
     * Retorna todos os veículos que já saíram do estacionamento (registros
     * finalizados).
     *
     * @return ResponseEntity com a lista de VeiculoDTO do histórico.
     */
    @GetMapping("/historico")
    public ResponseEntity<List<VeiculoDTO>> listarHistoricoCompleto() {
        return ResponseEntity.ok(estacionamentoService.listarHistoricoCompleto());
    }

    /**
     * Endpoint GET para buscar o histórico de estadias de uma placa específica.
     *
     * @param placa A placa do veículo a ser consultada.
     * @return ResponseEntity com a lista de estadias (DTOs) daquela placa.
     */
    @GetMapping("/historico/{placa}")
    public ResponseEntity<List<VeiculoDTO>> getHistoricoPorPlaca(@PathVariable String placa) {
        return ResponseEntity.ok(estacionamentoService.gerarRelatorioPorPlaca(placa));
    }

    /**
     * Endpoint GET para gerar um relatório de estadias finalizadas
     * dentro de um período específico.
     *
     * @param dataInicio Data e hora inicial do período (formato ISO.DATE_TIME).
     * @param dataFim    Data e hora final do período (formato ISO.DATE_TIME).
     * @return ResponseEntity com a lista de VeiculoDTOs no período especificado.
     */
    @GetMapping("/relatorio")
    public ResponseEntity<List<VeiculoDTO>> getRelatorioPorPeriodo(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime dataInicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime dataFim) {
        return ResponseEntity.ok(estacionamentoService.buscarRegistrosPorPeriodo(dataInicio, dataFim));
    }
}