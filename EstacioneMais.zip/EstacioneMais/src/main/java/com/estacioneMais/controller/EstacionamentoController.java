package com.estacioneMais.controller;

import com.estacioneMais.dto.VeiculoDTO;
import com.estacioneMais.dto.VeiculoEntradaManualDTO;
import com.estacioneMais.service.EstacionamentoService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/*
 * Controller responsável por expor os endpoints da API relacionados à gestão
 * do estacionamento. Esta classe recebe as requisições HTTP, delega as operações
 * de negócio para a camada de serviço (EstacionamentoService) e retorna as
 * respostas adequadas para o cliente (front-end).
 */
@RestController
@RequestMapping("/estacionamento")
public class EstacionamentoController {

    private final EstacionamentoService estacionamentoService;

    /*
     * Construtor da classe, responsável por injetar a dependência do EstacionamentoService.
     * A injeção de dependência via construtor é uma boa prática que garante que o controller
     * sempre terá uma instância válida do serviço para operar.
     *
     * @param estacionamentoService A instância do serviço de estacionamento gerenciada pelo Spring.
     */
    public EstacionamentoController(EstacionamentoService estacionamentoService) {
        this.estacionamentoService = estacionamentoService;
    }

    /*
     * Endpoint para registrar a entrada manual de um veículo no estacionamento.
     * Recebe os dados do veículo via corpo da requisição.
     *
     * @param entradaDTO DTO (Data Transfer Object) contendo a placa, modelo e cor do veículo.
     * @return Uma mensagem de sucesso confirmando o registro da entrada.
     */
    @PostMapping("/entrada")
    public ResponseEntity<String> registrarEntradaManual(
            @RequestBody VeiculoEntradaManualDTO entradaDTO) {
        estacionamentoService.registrarEntrada(entradaDTO);
        return ResponseEntity.ok("Entrada do veículo " +
                entradaDTO.placa().toUpperCase() + " registrada com sucesso.");
    }

    /*
     * Endpoint para registrar a saída de um veículo do estacionamento, com base na sua placa.
     * A placa é fornecida como parte da URL.
     *
     * @param placa A placa do veículo que está saindo.
     * @return Uma resposta HTTP 200 (OK) sem corpo, indicando que a operação foi bem-sucedida.
     */
    @PostMapping("/saida/{placa}")
    public ResponseEntity<Void> registrarSaida(@PathVariable String placa) {
        estacionamentoService.registrarSaida(placa);
        return ResponseEntity.ok().build();
    }

    /*
     * Endpoint que retorna uma lista de todos os veículos que estão atualmente no estacionamento.
     * (ou seja, veículos que registraram entrada mas ainda não registraram saída).
     *
     * @return Uma lista de VeiculoDTO representando os veículos ativos.
     */
    @GetMapping("/ativos")
    public ResponseEntity<List<VeiculoDTO>> listarVeiculosAtivos() {
        return ResponseEntity.ok(estacionamentoService.listarVeiculosAtivos());
    }

    /*
     * Endpoint que retorna o histórico completo de movimentação de veículos,
     * incluindo entradas e saídas já finalizadas.
     *
     * @return Uma lista de VeiculoDTO com todos os registros do estacionamento.
     */
    @GetMapping("/historico")
    public ResponseEntity<List<VeiculoDTO>> listarHistoricoCompleto() {
        return ResponseEntity.ok(estacionamentoService.listarHistoricoCompleto());
    }

    /*
     * Endpoint para consultar o histórico de todas as passagens de um veículo específico
     * pelo estacionamento, buscando pela placa.
     *
     * @param placa A placa do veículo a ser consultado.
     * @return Uma lista de VeiculoDTO com todo o histórico do veículo especificado.
     */
    @GetMapping("/historico/{placa}")
    public ResponseEntity<List<VeiculoDTO>> getHistoricoPorPlaca(@PathVariable String placa) {
        return ResponseEntity.ok(estacionamentoService.gerarRelatorioPorPlaca(placa));
    }

    /*
     * Endpoint para gerar um relatório de movimentação de veículos dentro de um
     * período de tempo específico.
     *
     * @param dataInicio Data e hora de início do período (formato ISO: yyyy-MM-ddTHH:mm:ss).
     * @param dataFim    Data e hora de fim do período (formato ISO: yyyy-MM-ddTHH:mm:ss).
     * @return Uma lista de VeiculoDTO com os registros encontrados no período informado.
     */
    @GetMapping("/relatorio")
    public ResponseEntity<List<VeiculoDTO>> getRelatorioPorPeriodo(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime dataInicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime dataFim) {
        return ResponseEntity.ok(estacionamentoService.buscarRegistrosPorPeriodo(dataInicio, dataFim));
    }
}