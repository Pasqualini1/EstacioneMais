package com.estacioneMais.controller;

import com.estacioneMais.dto.StatusPatioDTO; // Import do DTO
import com.estacioneMais.dto.VeiculoDTO;
import com.estacioneMais.dto.VeiculoEntradaManualDTO;
import com.estacioneMais.service.EstacionamentoService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/estacionamento")
public class EstacionamentoController {

    private final EstacionamentoService estacionamentoService;

    public EstacionamentoController(EstacionamentoService estacionamentoService) {
        this.estacionamentoService = estacionamentoService;
    }

    @GetMapping("/status-patio")
    public ResponseEntity<StatusPatioDTO> getStatusPatio() {
        StatusPatioDTO statusPatio = estacionamentoService.getStatusPatio();
        return ResponseEntity.ok(statusPatio);
    }

    @GetMapping("/saida/preview/{placa}")
    public ResponseEntity<VeiculoDTO> previewSaida(@PathVariable String placa) {
        VeiculoDTO previewDTO = estacionamentoService.calcularSaida(placa);
        return ResponseEntity.ok(previewDTO);
    }

    @PostMapping("/saida/{placa}")
    public ResponseEntity<VeiculoDTO> registrarSaida(@PathVariable String placa) {
        VeiculoDTO registroFinal = estacionamentoService.registrarSaida(placa);
        return ResponseEntity.ok(registroFinal);
    }

    @PostMapping("/entrada")
    public ResponseEntity<String> registrarEntradaManual(
            @RequestBody VeiculoEntradaManualDTO entradaDTO) {
        estacionamentoService.registrarEntrada(entradaDTO);
        return ResponseEntity.ok("Entrada do veículo " +
                entradaDTO.placa().toUpperCase() + " registrada com sucesso.");
    }

    @GetMapping("/ativos")
    public ResponseEntity<List<VeiculoDTO>> listarVeiculosAtivos() {
        return ResponseEntity.ok(estacionamentoService.listarVeiculosAtivos());
    }

    @GetMapping("/historico")
    public ResponseEntity<List<VeiculoDTO>> listarHistoricoCompleto() {
        return ResponseEntity.ok(estacionamentoService.listarHistoricoCompleto());
    }

    @GetMapping("/historico/{placa}")
    public ResponseEntity<List<VeiculoDTO>> getHistoricoPorPlaca(@PathVariable String placa) {
        return ResponseEntity.ok(estacionamentoService.gerarRelatorioPorPlaca(placa));
    }

    @GetMapping("/relatorio")
    public ResponseEntity<List<VeiculoDTO>> getRelatorioPorPeriodo(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime dataInicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime dataFim) {
        // --- CORREÇÃO APLICADA AQUI ---
        return ResponseEntity.ok(estacionamentoService.buscarRegistrosPorPeriodo(dataInicio, dataFim));
    }
}