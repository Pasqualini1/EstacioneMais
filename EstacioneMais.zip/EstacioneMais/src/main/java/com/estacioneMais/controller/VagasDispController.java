package com.estacioneMais.controller;

import com.estacioneMais.dto.VagasDispDTO;
import com.estacioneMais.model.VagasDisp;
import com.estacioneMais.service.VagasDispService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/vagas") // O endereço da API será http://localhost:8080/vagas
public class VagasDispController {

    private final VagasDispService vagasDispService;

    public VagasDispController(VagasDispService vagasDispService) {
        this.vagasDispService = vagasDispService;
    }

    /**
     * Endpoint para buscar a configuração atual de vagas.
     */
    @GetMapping
    public ResponseEntity<VagasDispDTO> getVagas() {
        VagasDisp vagasEntidade = vagasDispService.getVagas();

        // Converte a entidade para DTO antes de enviar
        VagasDispDTO dtoDeResposta = new VagasDispDTO(vagasEntidade.getTotalVagas());

        return ResponseEntity.ok(dtoDeResposta);
    }

    /**
     * Endpoint para atualizar o total de vagas.
     */
    @PutMapping
    public ResponseEntity<VagasDispDTO> atualizarVagas(@RequestBody VagasDispDTO dto) {
        VagasDispDTO dtoAtualizado = vagasDispService.atualizarVagas(dto);
        return ResponseEntity.ok(dtoAtualizado);
    }
}