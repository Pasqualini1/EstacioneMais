package com.estacioneMais.controller;

import com.estacioneMais.dto.VagasDispDTO;
import com.estacioneMais.model.VagasDisp;
import com.estacioneMais.service.VagasDispService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Controller (API) para gerenciar a configuração do total de vagas
 * disponíveis no estacionamento.
 * Expõe endpoints REST para consultar e atualizar o número total de vagas.
 * Mapeia as requisições sob o caminho base "/vagas".
 */
@RestController
@RequestMapping("/vagas")
public class VagasDispController {

    private final VagasDispService vagasDispService;

    /**
     * Construtor para injeção de dependência do VagasDispService.
     *
     * @param vagasDispService O serviço que gerencia a lógica de negócio das vagas.
     */
    public VagasDispController(VagasDispService vagasDispService) {
        this.vagasDispService = vagasDispService;
    }

    /**
     * Endpoint GET para buscar a configuração atual de vagas.
     * Retorna um DTO com o número total de vagas cadastradas no sistema.
     *
     * @return ResponseEntity contendo o VagasDispDTO com o total de vagas.
     */
    @GetMapping
    public ResponseEntity<VagasDispDTO> getVagas() {
        VagasDisp vagasEntidade = vagasDispService.getVagas();
        VagasDispDTO dtoDeResposta = new VagasDispDTO(vagasEntidade.getTotalVagas());
        return ResponseEntity.ok(dtoDeResposta);
    }

    /**
     * Endpoint PUT para atualizar o número total de vagas do estacionamento.
     * Recebe um DTO com o novo valor total.
     *
     * @param dto O DTO contendo o novo total de vagas.
     * @return ResponseEntity com o DTO atualizado, como confirmação.
     */
    @PutMapping
    public ResponseEntity<VagasDispDTO> atualizarVagas(@RequestBody VagasDispDTO dto) {
        VagasDispDTO dtoAtualizado = vagasDispService.atualizarVagas(dto);
        return ResponseEntity.ok(dtoAtualizado);
    }
}