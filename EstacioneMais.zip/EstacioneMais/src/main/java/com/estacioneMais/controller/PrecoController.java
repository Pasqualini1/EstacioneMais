package com.estacioneMais.controller;

import com.estacioneMais.dto.PrecoDTO;
import com.estacioneMais.model.Preco;
import com.estacioneMais.service.PrecoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Controller (API) para gerenciar as regras de precificação do estacionamento.
 * Expõe endpoints REST para consultar e atualizar os valores e a
 * fracionalidade da cobrança (ex: R$ 5,00 a cada 30 minutos).
 * Mapeia as requisições sob o caminho base "/preco".
 */
@RestController
@RequestMapping("/preco")
public class PrecoController {

    private final PrecoService precoService;

    /**
     * Construtor para injeção de dependência do PrecoService.
     *
     * @param precoService O serviço que gerencia a lógica de negócio dos preços.
     */
    public PrecoController(PrecoService precoService) {
        this.precoService = precoService;
    }

    /**
     * Endpoint GET para buscar as regras de preço vigentes.
     * Retorna um DTO com o valor e os minutos da fração de cobrança.
     *
     * @return ResponseEntity contendo o PrecoDTO com os dados atuais.
     */
    @GetMapping
    public ResponseEntity<PrecoDTO> getPreco() {
        Preco precoEntidade = precoService.getPreco();

        // Converte a entidade para DTO antes de enviar
        PrecoDTO dtoDeResposta = new PrecoDTO(
                precoEntidade.getPrecoValor(),
                precoEntidade.getPrecoMinutos()
        );

        return ResponseEntity.ok(dtoDeResposta);
    }

    /**
     * Endpoint PUT para atualizar as regras de preço.
     * Recebe um DTO do frontend e o utiliza para atualizar os valores
     * no banco de dados.
     *
     * @param dto O DTO contendo os novos valores (precoValor e precoMinutos).
     * @return ResponseEntity com o DTO atualizado, como confirmação.
     */
    @PutMapping
    public ResponseEntity<PrecoDTO> atualizarPreco(@RequestBody PrecoDTO dto) {
        PrecoDTO dtoAtualizado = precoService.atualizarPreco(dto);
        return ResponseEntity.ok(dtoAtualizado);
    }
}