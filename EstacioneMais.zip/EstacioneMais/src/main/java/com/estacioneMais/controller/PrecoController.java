package com.estacioneMais.controller;

import com.estacioneMais.dto.PrecoDTO;
import com.estacioneMais.model.Preco;
import com.estacioneMais.service.PrecoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
// --- MUDANÇA CRÍTICA: O endereço da API agora é /preco ---
@RequestMapping("/preco")
public class PrecoController {

    // --- CORREÇÃO DE NOME: Variável e construtor ajustados ---
    private final PrecoService precoService;

    public PrecoController(PrecoService precoService) {
        this.precoService = precoService;
    }

    /**
     * Busca as regras de preço e as retorna como um DTO.
     * O JSON enviado ao frontend terá sempre a estrutura correta.
     */
    @GetMapping
    // --- CORREÇÃO DE NOME: Método renomeado ---
    public ResponseEntity<PrecoDTO> getPreco() {
        // --- CORREÇÃO DE NOME: Chamadas de método ajustadas ---
        Preco precoEntidade = precoService.getPreco();

        // Converte a entidade para DTO antes de enviar
        PrecoDTO dtoDeResposta = new PrecoDTO(
                precoEntidade.getPrecoValor(),
                precoEntidade.getPrecoMinutos()
        );

        return ResponseEntity.ok(dtoDeResposta);
    }

    /**
     * Recebe um DTO do frontend e o usa para atualizar as regras de preço.
     * Retorna o DTO atualizado como confirmação.
     */
    @PutMapping
    // --- CORREÇÃO DE NOME: Método renomeado ---
    public ResponseEntity<PrecoDTO> atualizarPreco(@RequestBody PrecoDTO dto) {
        // --- CORREÇÃO DE NOME: Chamada de método ajustada ---
        PrecoDTO dtoAtualizado = precoService.atualizarPreco(dto);
        return ResponseEntity.ok(dtoAtualizado);
    }
}