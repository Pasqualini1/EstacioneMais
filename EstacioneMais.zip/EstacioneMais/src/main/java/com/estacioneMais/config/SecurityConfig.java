package com.estacioneMais.config;

import com.estacioneMais.security.ApiKeyAuthFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * Classe de configuração principal do Spring Security.
 * Habilita a segurança web e define a cadeia de filtros (SecurityFilterChain)
 * que protege a aplicação, integrando o filtro customizado de API Key.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final ApiKeyAuthFilter apiKeyAuthFilter;

    /**
     * Construtor que realiza a injeção de dependência do filtro de
     * autenticação (ApiKeyAuthFilter).
     *
     * @param apiKeyAuthFilter O filtro customizado para validação da API Key.
     */
    public SecurityConfig(ApiKeyAuthFilter apiKeyAuthFilter) {
        this.apiKeyAuthFilter = apiKeyAuthFilter;
    }

    /**
     * Define e configura a cadeia de filtros de segurança (SecurityFilterChain).
     * Este método configura a política de segurança da API, definindo que
     * ela é 'stateless' (não usa sessões), desabilita o CSRF (desnecessário
     * para APIs stateless) e exige autenticação para todas as requisições,
     * adicionando o filtro de API Key no processo.
     *
     * @param http O objeto HttpSecurity para construir a cadeia de filtros.
     * @return O objeto SecurityFilterChain construído.
     * @throws Exception Lançada caso ocorra erro na configuração.
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .sessionManagement(session ->
                        session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        .anyRequest().authenticated()
                )
                .addFilterBefore(apiKeyAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}