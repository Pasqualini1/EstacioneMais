package com.estacioneMais.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/*
 * Classe de configuração para o CORS (Cross-Origin Resource Sharing).
 * Esta classe define as regras globais que permitem que aplicações front-end
 * de origens específicas (domínios) possam fazer requisições para esta API,
 * garantindo a comunicação segura entre o back-end e o front-end.
 */
@Configuration
public class CorsConfig implements WebMvcConfigurer {

    /*
     * Personaliza as configurações de CORS para toda a aplicação.
     * Este método define que todos os endpoints ("/**") da API aceitarão requisições
     * da origem "http://localhost:8080" (o front-end em desenvolvimento). Ele também
     * libera os principais métodos HTTP (GET, POST, PUT, DELETE), permite o envio de
     * todos os cabeçalhos e autoriza o uso de credenciais para autenticação.
     *
     * @param registry O registro do CORS, que armazena as configurações.
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("http://localhost:8080")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);
    }
}