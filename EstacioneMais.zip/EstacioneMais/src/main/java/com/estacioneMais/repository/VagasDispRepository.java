package com.estacioneMais.repository;

import com.estacioneMais.model.VagasDisp;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

/**
 * Repositório Spring Data JPA para a entidade VagasDisp.
 * <p>
 * Esta interface gerencia o acesso aos dados (operações CRUD)
 * para a tabela de configuração de vagas (VagasDisp), permitindo
 * consultar e atualizar o total de vagas do estacionamento.
 */
public interface VagasDispRepository extends JpaRepository<VagasDisp, Long> {

    /**
     * Busca a primeira (e, por convenção, única) entidade de VagasDisp
     * salva no banco.
     * <p>
     * O sistema é projetado para ter apenas uma linha nesta tabela,
     * contendo o total de vagas do pátio.
     *
     * @return um Optional contendo a entidade VagasDisp (se existir), ou um
     * Optional vazio.
     */
    Optional<VagasDisp> findFirstByOrderByIdAsc();
}