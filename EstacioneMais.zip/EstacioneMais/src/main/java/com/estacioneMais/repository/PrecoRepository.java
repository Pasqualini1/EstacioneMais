package com.estacioneMais.repository;

import com.estacioneMais.model.Preco;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PrecoRepository extends JpaRepository<Preco, Long> {
    // Método para pegar a primeira (e única) configuração da tabela
    Optional<Preco> findFirstByOrderByIdAsc();
}