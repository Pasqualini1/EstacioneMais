package com.estacioneMais.repository;

import com.estacioneMais.model.Preco;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repositório Spring Data JPA para a entidade Preco.
 * <p>
 * Esta interface gerencia o acesso aos dados (operações CRUD)
 * para a tabela de configuração de preços (Preco), abstraindo
 * a complexidade das consultas SQL.
 */
@Repository
public interface PrecoRepository extends JpaRepository<Preco, Long> {

    /**
     * Busca a primeira (e, por convenção, única) regra de preço
     * cadastrada no banco de dados.
     * <p>
     * O sistema é projetado para ter apenas uma linha de configuração de
     * preço. Este método garante que sempre recuperamos a primeira
     * entrada disponível, ordenada pelo ID.
     *
     * @return um Optional contendo a entidade Preco (se existir), ou um
     * Optional vazio se a tabela estiver vazia.
     */
    Optional<Preco> findFirstByOrderByIdAsc();
}