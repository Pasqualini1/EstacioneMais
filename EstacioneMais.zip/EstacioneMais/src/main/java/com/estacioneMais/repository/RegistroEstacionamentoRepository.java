package com.estacioneMais.repository;

import com.estacioneMais.model.RegistroEstacionamento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/*
 * Interface de Repositório para a entidade {@link RegistroEstacionamento}.
 *
 * Ao estender {@code JpaRepository}, o Spring Data JPA automaticamente fornece
 * a implementação para as operações básicas de CRUD (Create, Read, Update, Delete),
 * eliminando a necessidade de escrever código boilerplate para acesso a dados.
 * Esta interface também define métodos de consulta customizados para as necessidades
 * específicas da aplicação.
 */
@Repository
public interface RegistroEstacionamentoRepository extends
        JpaRepository<RegistroEstacionamento, Long> {

    /*
     * Busca um registro de estacionamento ativo (sem horário de saída) para uma placa específica.
     * O Spring Data JPA cria a query automaticamente a partir do nome do método.
     *
     * @param placa A placa do veículo.
     * @return Um {@code Optional} contendo o registro, se encontrado.
     */
    Optional<RegistroEstacionamento> findByVeiculoPlacaAndHorarioSaidaIsNull(String placa);

    /*
     * Retorna uma lista de todos os registros de estacionamento ativos (sem horário de saída).
     * Os resultados são ordenados pela data de entrada, do mais recente para o mais antigo.
     *
     * @return A lista de registros ativos.
     */
    List<RegistroEstacionamento> findByHorarioSaidaIsNullOrderByHorarioEntradaDesc();

    /*
     * Busca registros de estacionamento cuja entrada ocorreu dentro de um período específico.
     * Usado para a funcionalidade de relatório por período.
     *
     * @param dataInicio A data e hora de início do período.
     * @param dataFim    A data e hora de fim do período.
     * @return Uma lista de registros encontrados no intervalo.
     */
    List<RegistroEstacionamento>
    findByHorarioEntradaBetweenOrderByHorarioEntradaDesc
    (LocalDateTime dataInicio, LocalDateTime dataFim);

    /*
     * Busca o histórico completo de registros com uma ordenação customizada.
     * A anotação @Query permite escrever uma consulta em JPQL (Java Persistence Query Language).
     * A ordenação prioriza os veículos ainda estacionados (horarioSaida IS NULL) no topo,
     * e depois ordena os demais pelo horário de saída e entrada, dos mais recentes para os mais antigos.
     *
     * @return Uma lista ordenada de todos os registros de estacionamento.
     */
    @Query("SELECT r FROM RegistroEstacionamento r " +
            "ORDER BY CASE WHEN r.horarioSaida IS NULL THEN 0 ELSE 1 END ASC, " +
            "r.horarioSaida DESC, r.horarioEntrada DESC")
    List<RegistroEstacionamento> buscarHistoricoCompletoComOrdenacao();

    /*
     * Busca o histórico de registros de uma placa específica, permitindo busca parcial.
     * Utiliza a mesma lógica de ordenação customizada do método anterior, mas filtrando
     * pela placa do veículo. A anotação @Param vincula o argumento do método ao
     * parâmetro na query JPQL.
     *
     * @param placa O termo de busca para a placa do veículo.
     * @return Uma lista ordenada dos registros correspondentes ao filtro de placa.
     */
    @Query("SELECT r FROM RegistroEstacionamento r WHERE r.veiculo.placa LIKE %:placa% " +
            "ORDER BY CASE WHEN r.horarioSaida IS NULL THEN 0 ELSE 1 END ASC, " +
            "r.horarioSaida DESC, r.horarioEntrada DESC")
    List<RegistroEstacionamento> buscarHistoricoPorPlacaComOrdenacao(@Param("placa") String placa);
}